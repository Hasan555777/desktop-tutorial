// src/pages/Welcome/components/TestimonialsSection.jsx

import React from 'react';
import styles from './TestimonialsSection.module.css';

const testimonials = [
  {
    name: 'রাহুল আহমেদ',
    role: 'ফ্রিল্যান্সার',
    text: 'WorkTrustbd আমার ক্যারিয়ারের জন্য গেম-চেঞ্জার হয়ে উঠেছে। এসক্রো সিস্টেম আমাকে আত্মবিশ্বাস দেয় যে আমি আমার কাজের জন্য নিশ্চিত পেমেন্ট পাব। এখানকার ভেরিফিকেশন প্রক্রিয়া খুবই কঠোর, যা ক্লায়েন্টদের মধ্যেও আস্থা তৈরি করে। আমি এখানে এসে আমার আয় দ্বিগুণ করতে পেরেছি।'
  },
  {
    name: 'সাদিয়া রহমান',
    role: 'ক্লায়েন্ট',
    text: 'আমি WorkTrustbd-এর মাধ্যমে একাধিক ফ্রিল্যান্সার নিয়োগ করেছি। ভেরিফিকেশন প্রক্রিয়া নিশ্চিত করে যে আমি প্রকৃত পেশাদারদের সাথে কাজ করছি। সবচেয়ে ভালো লাগার বিষয় হলো এখানে প্রতিটি কাজের অগ্রগতি আমি সহজেই ট্র্যাক করতে পারি। পেমেন্ট সিস্টেমও খুব নিরাপদ এবং স্বচ্ছ।'
  },
  {
    name: 'কামাল হোসেন',
    role: 'ব্যবসায়ী',
    text: 'প্ল্যাটফর্মটি অত্যন্ত ইউজার-ফ্রেন্ডলি। আমি কীভাবে প্রকল্পের মাইলস্টোন ট্র্যাক করতে পারি এবং নিরাপদ পেমেন্ট করতে পারি তা খুব ভালো লাগে। এসক্রো সিস্টেমের কারণে আমি কোনও ঝুঁকি ছাড়াই বড় প্রকল্পের কাজ দিতে পারি। এছাড়া অ্যাডমিনদের দ্রুত সাড়া পাওয়া যায়, যা খুবই পেশাদারি।'
  },
  {
    name: 'মেহেদী হাসান',
    role: 'ওয়েব ডেভেলপার',
    text: 'বাংলাদেশের ফ্রিল্যান্সারদের জন্য WorkTrustbd একটি আশীর্বাদ। এখানকার কমিউনিটি খুবই সহায়ক। আমি নিয়মিত নতুন প্রকল্প পাচ্ছি এবং ক্লায়েন্টদের সাথে সম্পর্ক খুবই পেশাদারি। সবচেয়ে ভালো দিক হলো এখানে কোনও জালিয়াতি নেই, সবকিছু খুবই স্বচ্ছ ও নিরাপদ।'
  },
  {
    name: 'নুসরাত জাহান',
    role: 'ডিজিটাল মার্কেটার',
    text: 'WorkTrustbd আমাকে আমার দক্ষতা প্রদর্শনের একটি দুর্দান্ত প্ল্যাটফর্ম দিয়েছে। এখানে ক্লায়েন্টরা আপনার কাজের গুণমান দেখে আত্মবিশ্বাসী হয়। পেমেন্ট গেটওয়ে খুবই সহজ এবং দ্রুত। আমি ইতিমধ্যে ১০টির বেশি প্রকল্প সফলভাবে সম্পন্ন করেছি এবং সব ক্লায়েন্টই সন্তুষ্ট।'
  },
  {
    name: 'আব্দুল্লাহ আল মামুন',
    role: 'গ্রাফিক ডিজাইনার',
    text: 'অনেক প্ল্যাটফর্ম ব্যবহার করেছি কিন্তু WorkTrustbd-এর মতো নিরাপদ ও বিশ্বস্ত প্ল্যাটফর্ম পাইনি। এখানে ডিজাইন কাজের যথাযথ মূল্যায়ন হয়। ক্লায়েন্টরা আপনার কাজের মান বুঝতে পারে এবং সেই অনুযায়ী পেমেন্ট দেয়। ডিসপিউট সিস্টেমও খুব ন্যায্য, যা আমার কাছে সবচেয়ে গুরুত্বপূর্ণ।'
  }
];

const TestimonialsSection = () => {
  return (
    <section className={styles.testimonialsSection}>
      <div className={styles.sectionHeader}>
        <h2>আমাদের ইউজাররা যা বলেন</h2>
        <p>বাস্তব মানুষের কাছ থেকে বাস্তব অভিজ্ঞতা</p>
      </div>
      <div className={styles.testimonialsGrid}>
        {testimonials.map((testimonial, index) => (
          <div key={index} className={styles.testimonialCard}>
            <p className={styles.testimonialText}>"{testimonial.text}"</p>
            <div className={styles.testimonialAuthor}>
              <div className={styles.testimonialAvatar}>
                {testimonial.name.charAt(0)}
              </div>
              <div>
                <div className={styles.testimonialName}>{testimonial.name}</div>
                <div className={styles.testimonialRole}>{testimonial.role}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default TestimonialsSection;