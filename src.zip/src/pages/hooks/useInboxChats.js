import { useState, useEffect, useRef } from 'react';
import { 
  collection, query, where, orderBy, onSnapshot, 
  doc, setDoc, updateDoc, getDocs, writeBatch, deleteDoc, getDoc
} from 'firebase/firestore';
import { db } from '../../firebase';
import { createNewChatObject, createNormalizedChatObject } from '../inboxHelpers';

export const useInboxChats = (currentUser, currentMode, selectedChat, setSelectedChat, fetchUserProfile, chatContext) => {
  const [chats, setChats] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isInitialLoad, setIsInitialLoad] = useState(true);
  const [isDataReady, setIsDataReady] = useState(false);
  const unsubscribeRef = useRef(null);
  const isMounted = useRef(true);

  // ============================================================
  // ✅ ডেটা লোড হওয়া পর্যন্ত loading state
  // ============================================================
  useEffect(() => {
    isMounted.current = true;
    return () => {
      isMounted.current = false;
      if (unsubscribeRef.current) {
        unsubscribeRef.current();
      }
    };
  }, []);

  // ============================================================
  // ✅ ডিলিট চ্যাট
  // ============================================================
  const handleDeleteChat = async (chat) => {
    if (chat.isActiveDeal) {
      alert('⚠️ Cannot delete chat with an active deal!');
      return;
    }
    if (chat.isBlocked) {
      alert('⚠️ Cannot delete chat while user is blocked. Unblock first.');
      return;
    }
    if (!window.confirm('⚠️ Are you sure you want to delete this conversation permanently?')) {
      return;
    }
    
    try {
      const messagesRef = collection(db, 'chats', chat.id, 'messages');
      const messagesSnapshot = await getDocs(messagesRef);
      
      if (!messagesSnapshot.empty) {
        const batch = writeBatch(db);
        messagesSnapshot.docs.forEach(doc => batch.delete(doc.ref));
        await batch.commit();
      }
      
      await deleteDoc(doc(db, 'chats', chat.id));
      
      if (isMounted.current) {
        setChats(prev => prev.filter(c => c.id !== chat.id));
        if (selectedChat?.id === chat.id) {
          setSelectedChat(null);
          localStorage.removeItem('activeChat');
        }
      }
      alert('✅ Conversation deleted successfully!');
    } catch (error) {
      console.error("❌ Delete error:", error);
      alert('Failed to delete conversation: ' + error.message);
    }
  };

  // ============================================================
  // ✅ ব্লক/আনব্লক
  // ============================================================
  const handleBlockUser = async (chat, getDisplayName) => {
    if (chat.isActiveDeal) {
      alert('⚠️ Cannot block user with an active deal!');
      return;
    }
    
    const userName = getDisplayName(chat);
    if (!window.confirm(`⚠️ Are you sure you want to block ${userName}?`)) {
      return;
    }
    
    try {
      const chatRef = doc(db, 'chats', chat.id);
      await updateDoc(chatRef, {
        blockedBy: currentUser?.uid,
        blockedAt: new Date(),
        isBlocked: true,
        blockedUserName: userName,
        blockedUserEmail: currentUser?.email || ''
      });
      
      if (isMounted.current) {
        setChats(prev => prev.map(c => {
          if (c.id === chat.id) {
            return { ...c, isBlocked: true, blockedBy: currentUser?.uid };
          }
          return c;
        }));
        
        if (selectedChat?.id === chat.id) {
          setSelectedChat(prev => ({ ...prev, isBlocked: true, blockedBy: currentUser?.uid }));
        }
      }
      alert(`✅ ${userName} has been blocked!`);
    } catch (error) {
      console.error("❌ Block error:", error);
      alert('Failed to block user: ' + error.message);
    }
  };

  const handleUnblockUser = async (chat, getDisplayName) => {
    const userName = getDisplayName(chat);
    if (!window.confirm(`⚠️ Are you sure you want to unblock ${userName}?`)) {
      return;
    }
    
    try {
      const chatRef = doc(db, 'chats', chat.id);
      await updateDoc(chatRef, {
        blockedBy: null,
        blockedAt: null,
        isBlocked: false,
        blockedUserName: null,
        blockedUserEmail: null
      });
      
      if (isMounted.current) {
        setChats(prev => prev.map(c => {
          if (c.id === chat.id) {
            return { ...c, isBlocked: false, blockedBy: null };
          }
          return c;
        }));
        
        if (selectedChat?.id === chat.id) {
          setSelectedChat(prev => ({ ...prev, isBlocked: false, blockedBy: null }));
        }
      }
      alert(`✅ ${userName} has been unblocked!`);
    } catch (error) {
      console.error("❌ Unblock error:", error);
      alert('Failed to unblock user: ' + error.message);
    }
  };

  // ============================================================
  // ✅ চ্যাট সিলেক্ট - নরমালাইজড ডেটা সহ
  // ============================================================
  const handleSelectChat = async (chat) => {
    // ✅ নরমালাইজড চ্যাট অবজেক্ট তৈরি করুন
    const normalizedChat = createNormalizedChatObject(chat, currentUser);
    
    if (!normalizedChat) {
      console.error("❌ Failed to normalize chat data");
      return;
    }
    
    // ✅ ইউজার প্রোফাইল ফেচ করুন প্রথমে
    const otherId = normalizedChat.otherPartyId;
    if (otherId) {
      await fetchUserProfile(otherId);
    }
    
    if (isMounted.current) {
      setSelectedChat(normalizedChat);
      
      localStorage.setItem('activeChat', JSON.stringify({
        id: chat.id,
        otherPartyName: normalizedChat.otherPartyName,
        otherPartyPhoto: normalizedChat.otherPartyPhoto,
        fullData: normalizedChat
      }));
    }
    
    // আনরিড কাউন্ট রিসেট
    const userUnread = chat.unreadCount?.[currentUser?.uid] || 0;
    if (userUnread > 0) {
      try {
        const chatRef = doc(db, 'chats', chat.id);
        if (chat.unreadCount && typeof chat.unreadCount === 'object') {
          const newUnreadCount = { ...chat.unreadCount };
          newUnreadCount[currentUser.uid] = 0;
          await updateDoc(chatRef, { unreadCount: newUnreadCount });
        } else {
          await updateDoc(chatRef, { unreadCount: 0 });
        }
        
        if (isMounted.current) {
          setChats(prev => prev.map(c => {
            if (c.id === chat.id) {
              const newUnreadCount = c.unreadCount && typeof c.unreadCount === 'object'
                ? { ...c.unreadCount, [currentUser.uid]: 0 }
                : 0;
              return { ...c, unreadCount: newUnreadCount, isUnread: false };
            }
            return c;
          }));
        }
      } catch (error) {
        console.error("Error resetting unread count:", error);
      }
    }
  };

  // ============================================================
  // ✅ ফায়ারবেস কুয়েরি - ডেটা লোড হওয়া পর্যন্ত wait
  // ============================================================
// useInboxChats.js - শুধু প্রোফাইল ফেচ অংশ আপডেট করুন

// ============================================================
// ✅ ফায়ারবেস কুয়েরি - প্রোফাইল ফেচ সহ
// ============================================================
useEffect(() => {
  if (!currentUser?.uid) {
    setLoading(false);
    setIsDataReady(false);
    return;
  }

  setLoading(true);
  setIsDataReady(false);

  const chatsRef = collection(db, 'chats');
  const q = query(
    chatsRef,
    where('participants', 'array-contains', currentUser.uid),
    orderBy('updatedAt', 'desc')
  );

  if (unsubscribeRef.current) {
    unsubscribeRef.current();
  }

  unsubscribeRef.current = onSnapshot(q, 
    async (snapshot) => {
      if (!isMounted.current) return;

      try {
        const fetchedChats = snapshot.docs.map(doc => {
          const data = doc.data();
          
          // ✅ অন্য পক্ষের আইডি সঠিকভাবে বের করুন
          let otherId = data.participants?.find(p => p !== currentUser.uid);
          if (!otherId) {
            if (data.buyerId === currentUser.uid) {
              otherId = data.sellerId;
            } else if (data.sellerId === currentUser.uid) {
              otherId = data.buyerId;
            } else {
              otherId = data.otherPartyId || data.userId || data.ownerId;
            }
          }
          
          const isCurrentUserBuyer = data.buyerId === currentUser.uid;
          
          let userUnread = 0;
          if (data.unreadCount && typeof data.unreadCount === 'object') {
            userUnread = data.unreadCount[currentUser.uid] || 0;
          } else if (typeof data.unreadCount === 'number') {
            userUnread = data.unreadCount;
          }
          
          // ✅ অন্য পক্ষের নাম সঠিকভাবে বের করুন
          let otherPartyName = data.otherPartyName;
          if (!otherPartyName) {
            if (isCurrentUserBuyer) {
              otherPartyName = data.sellerName || 'Seller';
            } else {
              otherPartyName = data.buyerName || 'Buyer';
            }
          }
          
          // ✅ অন্য পক্ষের ফটো সঠিকভাবে বের করুন
          let otherPartyPhoto = data.otherPartyPhoto;
          if (!otherPartyPhoto) {
            if (isCurrentUserBuyer) {
              otherPartyPhoto = data.sellerPhoto || null;
            } else {
              otherPartyPhoto = data.buyerPhoto || null;
            }
          }
          
          return {
            id: doc.id,
            ...data,
            otherPartyId: otherId,
            otherPartyName: otherPartyName || 'User',
            otherPartyPhoto: otherPartyPhoto || null,
            initial: (otherPartyName || 'U').charAt(0).toUpperCase(),
            gradient: "linear-gradient(135deg, #f59e0b, #d97706)",
            isUnread: userUnread > 0,
            userUnreadCount: userUnread,
            isActiveDeal: data.status === 'active',
            isOnline: data.isOnline || false,
            time: data.updatedAt?.toDate?.()?.toLocaleTimeString() || 'Just now',
            preview: data.lastMessage || 'Start conversation',
            tag: data.postTitle || 'Chat',
            isBlocked: data.isBlocked === true && data.blockedBy === currentUser?.uid,
            blockedBy: data.blockedBy || null
          };
        });

        // ✅ মোড অনুযায়ী ফিল্টার
        let filteredByMode = fetchedChats;
        if (currentMode === 'buyer') {
          filteredByMode = fetchedChats.filter(c => c.buyerId === currentUser.uid);
        } else if (currentMode === 'seller') {
          filteredByMode = fetchedChats.filter(c => c.sellerId === currentUser.uid);
        }
        
        filteredByMode.sort((a, b) => {
          const timeA = a.updatedAt?.toDate?.() || new Date(0);
          const timeB = b.updatedAt?.toDate?.() || new Date(0);
          return timeB - timeA;
        });
        
        if (isMounted.current) {
          setChats(filteredByMode);
          setLoading(false);
          setIsInitialLoad(false);
          setIsDataReady(true);
        }

        // ✅ ✅ ✅ ইউজার প্রোফাইল ফেচ - সব ইউজারের জন্য
        const uniqueUserIds = new Set();
        filteredByMode.forEach(chat => {
          if (chat.otherPartyId) {
            uniqueUserIds.add(chat.otherPartyId);
          }
          // ✅ buyer এবং seller আইডিও যোগ করুন
          if (chat.buyerId) uniqueUserIds.add(chat.buyerId);
          if (chat.sellerId) uniqueUserIds.add(chat.sellerId);
        });
        
        // ✅ সকল ইউজারের প্রোফাইল ফেচ করুন
        const fetchPromises = Array.from(uniqueUserIds).map(userId => {
          if (userId && userId !== currentUser.uid) {
            return fetchUserProfile(userId);
          }
          return Promise.resolve(null);
        });
        
        await Promise.all(fetchPromises);
        
        console.log("✅ Profiles fetched for users:", Array.from(uniqueUserIds));
        
      } catch (error) {
        console.error("Error processing chats:", error);
        if (isMounted.current) {
          setLoading(false);
          setIsDataReady(false);
        }
      }
    },
    (error) => {
      console.error("Error loading chats:", error);
      if (isMounted.current) {
        setLoading(false);
        setIsDataReady(false);
      }
    }
  );

  return () => {
    if (unsubscribeRef.current) {
      unsubscribeRef.current();
      unsubscribeRef.current = null;
    }
  };
}, [currentUser?.uid, currentMode, fetchUserProfile]); // ✅ fetchUserProfile dependency যোগ করুন


  // ============================================================
  // ✅ নতুন চ্যাট তৈরি - ডেটা রেডি হলে
  // ============================================================
  useEffect(() => {
    if (!chatContext || !currentUser?.uid || !isDataReady) return;
    
    const chatId = chatContext.id || chatContext.postId;
    if (!chatId) return;
    
    const existingChat = chats.find(c => c.id === chatId);
    
    if (!existingChat) {
      const newChat = createNewChatObject(chatContext, currentUser);
      const chatRef = doc(db, 'chats', chatId);
      setDoc(chatRef, newChat).catch(console.error);
      
      if (isMounted.current) {
        setChats(prev => {
          // ✅ ডুপ্লিকেট চেক
          const exists = prev.some(c => c.id === chatId);
          if (exists) return prev;
          return [newChat, ...prev];
        });
        setSelectedChat(newChat);
      }
    } else {
      // ✅ ডেটা রেডি হলে সিলেক্ট করুন
      if (isMounted.current && !selectedChat) {
        handleSelectChat(existingChat);
      }
    }
  }, [chatContext, currentUser, isDataReady]);

  // ============================================================
  // ✅ লোকাল স্টোরেজ রিস্টোর - ডেটা রেডি হলে
  // ============================================================
  useEffect(() => {
    if (!isInitialLoad && isDataReady && !selectedChat && chats.length > 0) {
      const savedChat = localStorage.getItem('activeChat');
      if (savedChat) {
        try {
          const parsedChat = JSON.parse(savedChat);
          const foundChat = chats.find(c => c.id === parsedChat.id);
          if (foundChat) {
            handleSelectChat(foundChat);
          } else {
            localStorage.removeItem('activeChat');
          }
        } catch (e) {
          localStorage.removeItem('activeChat');
        }
      }
    }
  }, [chats, isInitialLoad, isDataReady]);

  return {
    chats,
    setChats,
    loading,
    isInitialLoad,
    isDataReady,
    handleDeleteChat,
    handleBlockUser,
    handleUnblockUser,
    handleSelectChat,
    setSelectedChat
  };
};