import { useState, useEffect } from 'react';
import { db } from '../../firebase';
import { 
  collection, addDoc, query, orderBy, onSnapshot, 
  serverTimestamp, deleteDoc, doc, updateDoc, getDoc, increment 
} from 'firebase/firestore';

export const useChatMessages = (chatId, currentUser) => {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!chatId || typeof chatId !== 'string') {
      setLoading(false);
      return;
    }

    const messagesRef = collection(db, 'chats', chatId, 'messages');
    const q = query(messagesRef, orderBy('createdAt', 'asc'));

    const unsubscribe = onSnapshot(q, 
      (snapshot) => {
        setMessages(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
        setLoading(false);
      }, 
      (error) => {
        console.error("Firebase listener error: ", error);
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, [chatId]);

  const sendMessage = async (text, imageUrl, isBlocked, blockedBy, chatContext, safeChatId) => {
    if ((!text.trim() && !imageUrl) || !safeChatId || !currentUser?.uid) return;
    if (isBlocked || (blockedBy && blockedBy !== currentUser.uid)) {
      alert(isBlocked ? 'You have blocked this user.' : 'You have been blocked by this user.');
      return;
    }

    try {
      const messageData = {
        text: imageUrl ? "📷 Shared an image" : text.trim(),
        imageUrl: imageUrl || null,
        senderId: currentUser.uid,
        senderName: currentUser.displayName || currentUser.email || 'User',
        senderPhoto: currentUser.photoURL || '',
        createdAt: serverTimestamp(),
      };
      
      await addDoc(collection(db, 'chats', safeChatId, 'messages'), messageData);

      const chatRef = doc(db, 'chats', safeChatId);
      const chatSnap = await getDoc(chatRef);
      
      if (chatSnap.exists()) {
        const currentData = chatSnap.data();
        const participants = currentData.participants || [];
        const receiverId = participants.find(p => p !== currentUser.uid);

        if (receiverId) {
          await updateDoc(chatRef, {
            lastMessage: imageUrl ? "📷 Shared an image" : text.trim(),
            updatedAt: serverTimestamp(),
            [`unreadCount.${receiverId}`]: increment(1),
            [`unreadCount.${currentUser.uid}`]: 0
          });
        }
      }
      return true;
    } catch (error) {
      console.error("Error sending message:", error);
      alert("Failed to send message.");
      return false;
    }
  };

  const deleteMessage = async (messageId) => {
    if (!chatId || !messageId) return;
    try {
      await deleteDoc(doc(db, 'chats', chatId, 'messages', messageId));
    } catch (error) {
      console.error("Delete error:", error);
      alert('Failed to delete message.');
    }
  };

  const editMessage = async (messageId, newText) => {
    if (!chatId || !messageId || !newText.trim()) return;
    try {
      const messageRef = doc(db, 'chats', chatId, 'messages', messageId);
      await updateDoc(messageRef, {
        text: newText.trim(),
        edited: true,
        editedAt: serverTimestamp()
      });
    } catch (error) {
      console.error("Edit error:", error);
      alert('Failed to edit message.');
    }
  };

  return { messages, loading, sendMessage, deleteMessage, editMessage };
};