import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth, db } from '../firebase';
import { 
  collection, 
  query, 
  where, 
  orderBy, 
  onSnapshot,
  doc,
  getDoc
} from 'firebase/firestore';
import './PaymentHistory.css';

const PaymentHistory = () => {
  const navigate = useNavigate();
  const user = auth.currentUser;
  
  const [loading, setLoading] = useState(true);
  const [payments, setPayments] = useState([]);
  const [filterType, setFilterType] = useState('all');
  const [stats, setStats] = useState({
    totalDeposit: 0,
    totalWithdraw: 0,
    totalSend: 0,
    totalTransactions: 0
  });

  // ============================================================
  // ✅ পেমেন্ট হিস্টোরি লোড করা - রিয়েল-টাইম
  // ============================================================
  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    const transactionsRef = collection(db, 'transactions');
    const q = query(
      transactionsRef,
      where('userId', '==', user.uid),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedPayments = snapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          date: data.createdAt?.toDate?.() || new Date(),
          formattedDate: formatDate(data.createdAt?.toDate?.()),
          type: data.type || 'deposit',
          amount: data.amount || 0,
          status: data.status || 'pending'
        };
      });
      
      setPayments(fetchedPayments);
      calculateStats(fetchedPayments);
      setLoading(false);
    }, (error) => {
      console.error("Error loading payment history:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user, navigate]);

  // ============================================================
  // ✅ স্ট্যাটাস ক্যালকুলেশন
  // ============================================================
  const calculateStats = (txns) => {
    const totalDeposit = txns
      .filter(t => t.type === 'deposit' && t.status === 'completed')
      .reduce((sum, t) => sum + (t.amount || 0), 0);
    
    const totalWithdraw = txns
      .filter(t => t.type === 'withdraw' && t.status === 'completed')
      .reduce((sum, t) => sum + (t.amount || 0), 0);
    
    const totalSend = txns
      .filter(t => t.type === 'send' && t.status === 'completed')
      .reduce((sum, t) => sum + (t.amount || 0), 0);
    
    setStats({
      totalDeposit,
      totalWithdraw,
      totalSend,
      totalTransactions: txns.length
    });
  };

  // ============================================================
  // ✅ ফিল্টারিং
  // ============================================================
  const getFilteredPayments = () => {
    if (filterType === 'all') return payments;
    return payments.filter(p => p.type === filterType);
  };

  // ============================================================
  // ✅ ডেট ফরম্যাট
  // ============================================================
  const formatDate = (date) => {
    if (!date) return 'Just now';
    const now = new Date();
    const diff = now - date;
    
    if (diff < 60000) return 'Just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)} minutes ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)} hours ago`;
    if (diff < 604800000) return `${Math.floor(diff / 86400000)} days ago`;
    
    return date.toLocaleDateString('bn-BD', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  // ============================================================
  // ✅ ফরম্যাট টাকা
  // ============================================================
  const formatMoney = (amount) => {
    return new Intl.NumberFormat('bn-BD', {
      style: 'currency',
      currency: 'BDT',
      minimumFractionDigits: 0
    }).format(amount || 0);
  };

  // ============================================================
  // ✅ টাইপ আইকন ও কালার
  // ============================================================
  const getTypeConfig = (type) => {
    const configs = {
      'deposit': { 
        icon: 'fa-solid fa-arrow-down', 
        color: '#10b981', 
        bg: 'rgba(16, 185, 129, 0.1)',
        label: 'Deposit' 
      },
      'withdraw': { 
        icon: 'fa-solid fa-arrow-up', 
        color: '#f59e0b', 
        bg: 'rgba(245, 158, 11, 0.1)',
        label: 'Withdraw' 
      },
      'send': { 
        icon: 'fa-solid fa-paper-plane', 
        color: '#3b82f6', 
        bg: 'rgba(59, 130, 246, 0.1)',
        label: 'Send Money' 
      },
      'credit': { 
        icon: 'fa-solid fa-circle-dollar', 
        color: '#10b981', 
        bg: 'rgba(16, 185, 129, 0.1)',
        label: 'Received' 
      },
      'debit': { 
        icon: 'fa-solid fa-circle-dollar', 
        color: '#ef4444', 
        bg: 'rgba(239, 68, 68, 0.1)',
        label: 'Paid' 
      }
    };
    return configs[type] || configs['deposit'];
  };

  const getStatusConfig = (status) => {
    const configs = {
      'completed': { color: '#10b981', icon: 'fa-solid fa-check-circle', label: 'Completed' },
      'pending': { color: '#f59e0b', icon: 'fa-solid fa-clock', label: 'Pending' },
      'failed': { color: '#ef4444', icon: 'fa-solid fa-times-circle', label: 'Failed' },
      'processing': { color: '#3b82f6', icon: 'fa-solid fa-spinner fa-spin', label: 'Processing' }
    };
    return configs[status] || configs['pending'];
  };

  const filteredPayments = getFilteredPayments();

  // ============================================================
  // ✅ লোডিং স্টেট
  // ============================================================
  if (loading) {
    return (
      <div className="paymenthistory-loading">
        <div className="loading-spinner"></div>
        <p>Loading payment history...</p>
      </div>
    );
  }

  // ============================================================
  // ✅ রেন্ডার
  // ============================================================
  return (
    <div className="paymenthistory-container">
      <div className="paymenthistory-card">
        
        {/* হেডার */}
        <div className="paymenthistory-header">
          <button className="back-btn" onClick={() => navigate(-1)}>
            <i className="fa-solid fa-arrow-left"></i> Back
          </button>
          <h2><i className="fa-solid fa-receipt"></i> Payment History</h2>
        </div>

        {/* স্ট্যাটাস বার */}
        <div className="stats-bar">
          <div className="stat-item">
            <span className="stat-label">Total Deposits</span>
            <span className="stat-value positive">{formatMoney(stats.totalDeposit)}</span>
          </div>
          <div className="stat-divider"></div>
          <div className="stat-item">
            <span className="stat-label">Total Withdrawals</span>
            <span className="stat-value negative">{formatMoney(stats.totalWithdraw)}</span>
          </div>
          <div className="stat-divider"></div>
          <div className="stat-item">
            <span className="stat-label">Total Sent</span>
            <span className="stat-value">{formatMoney(stats.totalSend)}</span>
          </div>
        </div>

        {/* ফিল্টার */}
        <div className="filter-section">
          <button 
            className={`filter-btn ${filterType === 'all' ? 'active' : ''}`}
            onClick={() => setFilterType('all')}
          >
            All ({payments.length})
          </button>
          <button 
            className={`filter-btn ${filterType === 'deposit' ? 'active' : ''}`}
            onClick={() => setFilterType('deposit')}
          >
            <i className="fa-solid fa-arrow-down"></i> Deposits
          </button>
          <button 
            className={`filter-btn ${filterType === 'withdraw' ? 'active' : ''}`}
            onClick={() => setFilterType('withdraw')}
          >
            <i className="fa-solid fa-arrow-up"></i> Withdrawals
          </button>
          <button 
            className={`filter-btn ${filterType === 'send' ? 'active' : ''}`}
            onClick={() => setFilterType('send')}
          >
            <i className="fa-solid fa-paper-plane"></i> Sent
          </button>
        </div>

        {/* পেমেন্ট লিস্ট */}
        <div className="history-list">
          {filteredPayments.length === 0 ? (
            <div className="empty-history">
              <i className="fa-solid fa-receipt"></i>
              <h3>No Payment History</h3>
              <p>
                {filterType === 'all' 
                  ? 'You have no transactions yet.' 
                  : `No ${filterType} transactions found.`}
              </p>
              <button className="browse-btn" onClick={() => navigate('/wallet')}>
                <i className="fa-solid fa-wallet"></i> Go to Wallet
              </button>
            </div>
          ) : (
            filteredPayments.map((payment) => {
              const typeConfig = getTypeConfig(payment.type);
              const statusConfig = getStatusConfig(payment.status);
              
              return (
                <div key={payment.id} className={`history-item ${payment.status}`}>
                  <div className="history-icon" style={{ background: typeConfig.bg, color: typeConfig.color }}>
                    <i className={typeConfig.icon}></i>
                  </div>
                  
                  <div className="history-details">
                    <h4>{typeConfig.label}</h4>
                    <p>{payment.formattedDate}</p>
                    {payment.reference && (
                      <small className="reference">Ref: {payment.reference}</small>
                    )}
                  </div>
                  
                  <div className="history-right">
                    <div className={`history-amount ${payment.type}`}>
                      {payment.type === 'deposit' || payment.type === 'credit' ? '+' : '-'} 
                      {formatMoney(payment.amount)}
                    </div>
                    
                    <div className={`history-status ${payment.status}`}>
                      <i className={statusConfig.icon}></i>
                      <span>{statusConfig.label}</span>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* ফুটার */}
        {payments.length > 0 && (
          <div className="history-footer">
            <span>Showing {filteredPayments.length} of {payments.length} transactions</span>
          </div>
        )}

      </div>
    </div>
  );
};

export default PaymentHistory;