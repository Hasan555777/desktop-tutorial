import React, { useState, useRef } from 'react';
import { collection, addDoc, doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';
import './PostJobBox.css';

function PostJobBox({ onClose, setActiveTab, onSilentPost, currentUser }) {
  const [jobTitle, setJobTitle] = useState('');
  // const [category, setCategory] = useState('web');
  const [description, setDescription] = useState('');
  const [budget, setBudget] = useState('');
  const [deadline, setDeadline] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  const isSubmitting = useRef(false);
  const lastSubmitTime = useRef(0);



  // ============================================================
  // ✅ ফর্ম ভ্যালিডেশন
  // ============================================================
  const validateForm = () => {
    if (!jobTitle.trim()) {
      setError('Please enter a job title');
      return false;
    }
    if (jobTitle.trim().length < 5) {
      setError('Job title must be at least 5 characters');
      return false;
    }
    if (!description.trim()) {
      setError('Please enter a job description');
      return false;
    }
    if (description.trim().length < 20) {
      setError('Description must be at least 20 characters');
      return false;
    }
    if (!budget || Number(budget) < 100) {
      setError('Budget must be at least 100 BDT');
      return false;
    }
    if (Number(budget) > 1000000) {
      setError('Budget cannot exceed 1,000,000 BDT');
      return false;
    }
    if (!deadline || Number(deadline) < 1) {
      setError('Deadline must be at least 1 day');
      return false;
    }
    if (Number(deadline) > 365) {
      setError('Deadline cannot exceed 365 days');
      return false;
    }
    return true;
  };

  // ============================================================
  // ✅ ফর্ম সাবমিট
  // ============================================================
  const handlePublishJob = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    
    // ❌ Error রিসেট
    setError('');
    
    // 🔥 খুব দ্রুত সাবমিট চেক
    const now = Date.now();
    if (now - lastSubmitTime.current < 2000) {
      console.log("⏳ Too fast, ignoring duplicate request");
      return;
    }
    
    if (isSubmitting.current || loading) {
      console.log("⏳ Already submitting");
      return;
    }
    
    if (!currentUser) {
      setError("Please login to post a job!");
      return;
    }
    
    // ✅ ফর্ম ভ্যালিডেশন
    if (!validateForm()) {
      return;
    }
    
    // লক
    isSubmitting.current = true;
    setLoading(true);
    lastSubmitTime.current = now;
    
    // ইউনিক আইডি তৈরি করুন
    const uniqueId = `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const jobData = {
      type: 'hire',
      mode: 'buyer',
      title: jobTitle.trim(),
      // category: category,
      description: description.trim(),
      budget: Number(budget),
      deadline: Number(deadline),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      status: 'active',
      userId: currentUser.uid,
      buyerId: currentUser.uid,
      sellerId: null,
      clientName: currentUser.displayName || currentUser.email?.split('@')[0] || "Job Poster",
      clientPhoto: currentUser.photoURL || null,
      clientEmail: currentUser.email,
      verified: false,
      proposals: 0,
      images: [],
      _uniqueId: uniqueId
    };

    try {
      console.log("📤 Publishing job with unique ID:", uniqueId);
      
      const postRef = doc(db, 'posts', uniqueId);
      await setDoc(postRef, jobData);
      
      console.log("✅ Job posted with ID:", uniqueId);
      
      // UI রিসেট
      setJobTitle('');
      setCategory('web');
      setDescription('');
      setBudget('');
      setDeadline('');
      setError('');
      
      // 🔥 onSilentPost কল করবেন না (ডুপ্লিকেট প্রতিরোধ)
      // if (onSilentPost) onSilentPost({ ...jobData, id: uniqueId });
      
      alert('✅ Job Post Published Successfully!');
      
      if (setActiveTab) setActiveTab('dashboard');
      if (onClose) onClose();
      
    } catch (error) {
      console.error("❌ Error:", error);
      setError('Failed to publish job: ' + error.message);
    } finally {
      setLoading(false);
      setTimeout(() => {
        isSubmitting.current = false;
      }, 1000);
    }
  };

  // ============================================================
  // ✅ ফর্ম রিসেট
  // ============================================================
  const handleReset = () => {
    if (!loading) {
      // setJobTitle('');
      setCategory('web');
      setDescription('');
      setBudget('');
      setDeadline('');
      setError('');
    }
  };

  // ============================================================
  // ✅ রেন্ডার
  // ============================================================
  return (
    <div className="global-modal-overlay" onClick={onClose}>
      <div className="post-add-box" onClick={(e) => e.stopPropagation()}>
        
        {/* হেডার */}
        <div className="pbox-header">
          <h3>
            <i className="fa-solid fa-briefcase" style={{ color: '#fbbf24' }}></i> 
            Post a New Job
          </h3>
          <button type="button" className="pbox-close-btn" onClick={onClose}>
            <i className="fa-solid fa-xmark"></i>
          </button>
        </div>

        <form onSubmit={handlePublishJob}>
          <div className="pbox-body-form">
            
            {/* Error মেসেজ */}
            {error && (
              <div className="pbox-error">
                <i className="fa-solid fa-exclamation-circle"></i>
                {error}
              </div>
            )}

            {/* Job Title */}
            <div className="pb-group">
              <label>
                Job Title <span className="required-star">*</span>
              </label>
              <input 
                type="text" 
                value={jobTitle} 
                onChange={(e) => setJobTitle(e.target.value)} 
                placeholder="e.g., Need a React Developer" 
                maxLength="100"
                required 
                disabled={loading}
              />
              <small className="char-count">{jobTitle.length}/100</small>
            </div>

            {/* Category
            <div className="pb-group">
              <label>Category <span className="required-star">*</span></label>
              <select value={category} onChange={(e) => setCategory(e.target.value)} disabled={loading}>
                {categories.map((cat) => (
                  <option key={cat.value} value={cat.value}>
                    {cat.label}
                  </option>
                ))}
              </select>
            </div> */}

            {/* Budget & Deadline */}
            <div className="pb-row-twin">
              <div className="pb-group">
                <label>Budget (BDT) <span className="required-star">*</span></label>
                <input 
                  type="number" 
                  value={budget} 
                  onChange={(e) => setBudget(e.target.value)} 
                  placeholder="e.g., 5000" 
                  min="100" 
                  max="1000000"
                  required 
                  disabled={loading}
                />
                <small>Min: 100 BDT • Max: 1,000,000 BDT</small>
              </div>
              <div className="pb-group">
                <label>Deadline (Days) <span className="required-star">*</span></label>
                <input 
                  type="number" 
                  value={deadline} 
                  onChange={(e) => setDeadline(e.target.value)} 
                  placeholder="e.g., 7" 
                  min="1" 
                  max="365"
                  required 
                  disabled={loading}
                />
                <small>Min: 1 day • Max: 365 days</small>
              </div>
            </div>

            {/* Description */}
            <div className="pb-group">
              <label>Job Description <span className="required-star">*</span></label>
              <textarea 
                value={description} 
                onChange={(e) => setDescription(e.target.value)} 
                rows="5" 
                placeholder="Detailed description of the job..." 
                maxLength="5000"
                required 
                disabled={loading}
              />
              <small className="char-count">{description.length}/5000</small>
            </div>

          </div>

          {/* ফুটার */}
          <div className="pbox-footer">
            <button 
              type="button" 
              className="pbox-btn pb-btn-close" 
              onClick={onClose}
              disabled={loading}
            >
              Cancel
            </button>
            <button 
              type="reset" 
              className="pbox-btn pb-btn-reset" 
              onClick={handleReset}
              disabled={loading}
            >
              <i className="fa-solid fa-rotate"></i> Reset
            </button>
            <button 
              type="submit" 
              className="pbox-btn pb-btn-publish" 
              disabled={loading}
            >
              {loading ? (
                <>
                  <i className="fa-solid fa-spinner fa-spin"></i> Publishing...
                </>
              ) : (
                <>
                  <i className="fa-solid fa-paper-plane"></i> Publish Job
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default PostJobBox;