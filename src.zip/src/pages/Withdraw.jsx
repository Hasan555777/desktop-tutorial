import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth, db } from '../firebase';
import { 
  doc, getDoc, updateDoc, collection, addDoc, 
  query, where, onSnapshot, orderBy, serverTimestamp 
} from 'firebase/firestore';
import './Withdraw.css';

const Withdraw = () => {
  const navigate = useNavigate();
  const user = auth.currentUser;
  
  // ========== স্টেট ==========
  const [loading, setLoading] = useState(true);
  const [walletData, setWalletData] = useState({
    balance: 0,
    totalEarned: 0,
    totalWithdrawn: 0,
    pendingWithdraw: 0
  });
  const [withdrawals, setWithdrawals] = useState([]);
  const [showWithdrawForm, setShowWithdrawForm] = useState(true);
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('bKash');
  const [mobileNumber, setMobileNumber] = useState('');
  const [accountHolder, setAccountHolder] = useState('');
  const [bankName, setBankName] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedWithdrawal, setSelectedWithdrawal] = useState(null);

  // ========== ওয়ালেট এবং উইথড্র লোড করা ==========
  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    // ওয়ালেট ডাটা লোড
    const loadWallet = async () => {
      const walletRef = doc(db, 'wallets', user.uid);
      const walletSnap = await getDoc(walletRef);
      
      if (walletSnap.exists()) {
        setWalletData(walletSnap.data());
      } else {
        setWalletData({
          balance: 0,
          totalEarned: 0,
          totalWithdrawn: 0,
          pendingWithdraw: 0
        });
      }
    };

    // উইথড্র লিস্ট লোড
    const withdrawalsRef = collection(db, 'withdrawals');
    const q = query(
      withdrawalsRef,
      where('userId', '==', user.uid),
      orderBy('requestedAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedWithdrawals = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        formattedDate: doc.data().requestedAt?.toDate?.() || new Date()
      }));
      setWithdrawals(fetchedWithdrawals);
      setLoading(false);
    });

    loadWallet();
    return () => unsubscribe();
  }, [user, navigate]);

  // ========== উইথড্র রিকোয়েস্ট সাবমিট ==========
  const handleSubmitWithdraw = async (e) => {
    e.preventDefault();
    
    // ভ্যালিডেশন
    if (!withdrawAmount || withdrawAmount <= 0) {
      alert('Please enter a valid amount!');
      return;
    }

    if (withdrawAmount < 100) {
      alert('Minimum withdrawal amount is ৳100');
      return;
    }

    if (withdrawAmount > walletData.balance) {
      alert('Insufficient balance!');
      return;
    }

    if (!mobileNumber || mobileNumber.length < 11) {
      alert('Please enter a valid mobile number!');
      return;
    }

    setIsSubmitting(true);

    try {
      // উইথড্র রিকোয়েস্ট তৈরি
      const withdrawRef = collection(db, 'withdrawals');
      const withdrawData = {
        userId: user.uid,
        amount: Number(withdrawAmount),
        status: 'pending',
        paymentMethod: paymentMethod,
        mobileNumber: mobileNumber,
        ...(paymentMethod === 'bank' && {
          accountHolder: accountHolder,
          bankName: bankName,
          accountNumber: accountNumber
        }),
        requestedAt: serverTimestamp(),
        createdAt: serverTimestamp()
      };

      const docRef = await addDoc(withdrawRef, withdrawData);

      // ওয়ালেট আপডেট
      const walletRef = doc(db, 'wallets', user.uid);
      await updateDoc(walletRef, {
        balance: walletData.balance - Number(withdrawAmount),
        pendingWithdraw: (walletData.pendingWithdraw || 0) + Number(withdrawAmount),
        updatedAt: new Date().toISOString()
      });

      // ট্রানজেকশন রেকর্ড
      const transactionRef = collection(db, 'transactions');
      await addDoc(transactionRef, {
        userId: user.uid,
        amount: Number(withdrawAmount),
        type: 'withdraw',
        status: 'pending',
        title: 'Withdrawal Request',
        description: `Withdrawal request via ${paymentMethod}`,
        reference: docRef.id,
        paymentMethod: paymentMethod,
        createdAt: serverTimestamp()
      });

      // লোকাল স্টেট আপডেট
      setWalletData(prev => ({
        ...prev,
        balance: prev.balance - Number(withdrawAmount),
        pendingWithdraw: (prev.pendingWithdraw || 0) + Number(withdrawAmount)
      }));

      alert('✅ Withdrawal request submitted successfully!');
      
      // ফর্ম রিসেট
      setWithdrawAmount('');
      setMobileNumber('');
      setAccountHolder('');
      setBankName('');
      setAccountNumber('');
      setShowWithdrawForm(false);
      
      // 2 সেকেন্ড পর ফর্ম দেখানো শুরু
      setTimeout(() => setShowWithdrawForm(true), 2000);
      
    } catch (error) {
      console.error("Error submitting withdrawal:", error);
      alert('Failed to submit withdrawal request. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // ========== উইথড্র ডিটেইলস দেখানো ==========
  const showWithdrawDetails = (withdrawal) => {
    setSelectedWithdrawal(withdrawal);
  };

  // ========== ফরম্যাট টাকা ==========
  const formatMoney = (amount) => {
    return new Intl.NumberFormat('bn-BD', {
      style: 'currency',
      currency: 'BDT',
      minimumFractionDigits: 0
    }).format(amount || 0);
  };

  // ========== ডেট ফরম্যাট ==========
  const formatDate = (date) => {
    if (!date) return 'N/A';
    return new Date(date).toLocaleDateString('bn-BD', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // ========== স্ট্যাটাস ব্যাজ ক্লাস ==========
  const getStatusClass = (status) => {
    switch(status) {
      case 'completed': return 'status-completed';
      case 'pending': return 'status-pending';
      case 'processing': return 'status-processing';
      case 'rejected': return 'status-rejected';
      default: return 'status-pending';
    }
  };

  const getStatusIcon = (status) => {
    switch(status) {
      case 'completed': return 'fa-solid fa-check-circle';
      case 'pending': return 'fa-solid fa-clock';
      case 'processing': return 'fa-solid fa-spinner fa-spin';
      case 'rejected': return 'fa-solid fa-times-circle';
      default: return 'fa-solid fa-clock';
    }
  };

  if (loading) {
    return (
      <div className="withdraw-loading">
        <div className="loading-spinner"></div>
        <p>Loading withdrawal info...</p>
      </div>
    );
  }

  return (
    <div className="withdraw-container">
      <div className="withdraw-wrapper">
        
        {/* হেডার */}
        <div className="withdraw-header">
          <button className="back-btn" onClick={() => navigate(-1)}>
            <i className="fa-solid fa-arrow-left"></i> Back
          </button>
          <h1><i className="fa-solid fa-money-bill-transfer"></i> Withdraw Funds</h1>
        </div>

        {/* ব্যালেন্স কার্ড */}
        <div className="balance-summary">
          <div className="balance-card">
            <div className="balance-icon">
              <i className="fa-solid fa-wallet"></i>
            </div>
            <div className="balance-info">
              <span className="balance-label">Available Balance</span>
              <span className="balance-amount">{formatMoney(walletData.balance)}</span>
            </div>
          </div>
          <div className="pending-card">
            <div className="pending-icon">
              <i className="fa-solid fa-clock"></i>
            </div>
            <div className="pending-info">
              <span className="pending-label">Pending Withdrawal</span>
              <span className="pending-amount">{formatMoney(walletData.pendingWithdraw)}</span>
            </div>
          </div>
        </div>

        {/* উইথড্র ফর্ম */}
        {showWithdrawForm && (
          <div className="withdraw-form-card">
            <h3><i className="fa-solid fa-plus-circle"></i> New Withdrawal Request</h3>
            
            <form onSubmit={handleSubmitWithdraw}>
              <div className="form-group">
                <label>Amount (BDT)</label>
                <div className="input-with-icon">
                  <i className="fa-solid fa-taka"></i>
                  <input 
                    type="number" 
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(e.target.value)}
                    placeholder="Enter amount"
                    min="100"
                    max={walletData.balance}
                    required
                  />
                </div>
                <small>Minimum withdrawal: ৳100 | Maximum: {formatMoney(walletData.balance)}</small>
              </div>

              <div className="form-group">
                <label>Payment Method</label>
                <div className="method-options">
                  <label className={`method-option ${paymentMethod === 'bKash' ? 'active' : ''}`}>
                    <input 
                      type="radio" 
                      value="bKash" 
                      checked={paymentMethod === 'bKash'} 
                      onChange={(e) => setPaymentMethod(e.target.value)}
                    />
                    <i className="fa-brands fa-btc"></i>
                    <span>bKash</span>
                  </label>
                  <label className={`method-option ${paymentMethod === 'Nagad' ? 'active' : ''}`}>
                    <input 
                      type="radio" 
                      value="Nagad" 
                      checked={paymentMethod === 'Nagad'} 
                      onChange={(e) => setPaymentMethod(e.target.value)}
                    />
                    <i className="fa-solid fa-n"></i>
                    <span>Nagad</span>
                  </label>
                  <label className={`method-option ${paymentMethod === 'Rocket' ? 'active' : ''}`}>
                    <input 
                      type="radio" 
                      value="Rocket" 
                      checked={paymentMethod === 'Rocket'} 
                      onChange={(e) => setPaymentMethod(e.target.value)}
                    />
                    <i className="fa-solid fa-rocket"></i>
                    <span>Rocket</span>
                  </label>
                  <label className={`method-option ${paymentMethod === 'bank' ? 'active' : ''}`}>
                    <input 
                      type="radio" 
                      value="bank" 
                      checked={paymentMethod === 'bank'} 
                      onChange={(e) => setPaymentMethod(e.target.value)}
                    />
                    <i className="fa-solid fa-building-columns"></i>
                    <span>Bank</span>
                  </label>
                </div>
              </div>

              <div className="form-group">
                <label>Mobile Number</label>
                <div className="input-with-icon">
                  <i className="fa-solid fa-phone"></i>
                  <input 
                    type="tel" 
                    value={mobileNumber}
                    onChange={(e) => setMobileNumber(e.target.value)}
                    placeholder="01XXXXXXXXX"
                    maxLength="11"
                    required
                  />
                </div>
                <small>Enter your {paymentMethod === 'bank' ? 'bank registered' : paymentMethod} mobile number</small>
              </div>

              {paymentMethod === 'bank' && (
                <>
                  <div className="form-group">
                    <label>Account Holder Name</label>
                    <div className="input-with-icon">
                      <i className="fa-solid fa-user"></i>
                      <input 
                        type="text" 
                        value={accountHolder}
                        onChange={(e) => setAccountHolder(e.target.value)}
                        placeholder="Full name as per bank account"
                        required
                      />
                    </div>
                  </div>
                  <div className="form-group">
                    <label>Bank Name</label>
                    <div className="input-with-icon">
                      <i className="fa-solid fa-building-columns"></i>
                      <input 
                        type="text" 
                        value={bankName}
                        onChange={(e) => setBankName(e.target.value)}
                        placeholder="e.g., Dutch-Bangla Bank, bKash"
                        required
                      />
                    </div>
                  </div>
                  <div className="form-group">
                    <label>Account Number</label>
                    <div className="input-with-icon">
                      <i className="fa-solid fa-hashtag"></i>
                      <input 
                        type="text" 
                        value={accountNumber}
                        onChange={(e) => setAccountNumber(e.target.value)}
                        placeholder="Your bank account number"
                        required
                      />
                    </div>
                  </div>
                </>
              )}

              <div className="fee-info">
                <i className="fa-solid fa-circle-info"></i>
                <div>
                  <strong>Withdrawal Fee: 0%</strong>
                  <p>No hidden charges. You'll receive the full amount.</p>
                </div>
              </div>

              <button 
                type="submit" 
                className="submit-btn"
                disabled={isSubmitting || withdrawAmount > walletData.balance || withdrawAmount < 100}
              >
                {isSubmitting ? (
                  <>
                    <i className="fa-solid fa-spinner fa-spin"></i> Processing...
                  </>
                ) : (
                  <>
                    <i className="fa-solid fa-paper-plane"></i> Submit Withdrawal Request
                  </>
                )}
              </button>
            </form>
          </div>
        )}

        {/* উইথড্র হিস্টোরি */}
        <div className="withdraw-history">
          <h3><i className="fa-solid fa-clock-rotate-left"></i> Withdrawal History</h3>
          
          {withdrawals.length === 0 ? (
            <div className="no-history">
              <i className="fa-solid fa-receipt"></i>
              <p>No withdrawal requests yet</p>
              <small>Your withdrawal history will appear here</small>
            </div>
          ) : (
            <div className="history-list">
              {withdrawals.map((withdrawal) => (
                <div 
                  key={withdrawal.id} 
                  className={`history-item ${getStatusClass(withdrawal.status)}`}
                  onClick={() => showWithdrawDetails(withdrawal)}
                >
                  <div className="history-icon">
                    <i className={getStatusIcon(withdrawal.status)}></i>
                  </div>
                  <div className="history-details">
                    <div className="history-header">
                      <span className="history-amount">{formatMoney(withdrawal.amount)}</span>
                      <span className={`history-status ${getStatusClass(withdrawal.status)}`}>
                        {withdrawal.status === 'completed' && 'Completed'}
                        {withdrawal.status === 'pending' && 'Pending'}
                        {withdrawal.status === 'processing' && 'Processing'}
                        {withdrawal.status === 'rejected' && 'Rejected'}
                      </span>
                    </div>
                    <div className="history-meta">
                      <span><i className="fa-solid fa-credit-card"></i> {withdrawal.paymentMethod}</span>
                      <span><i className="fa-solid fa-phone"></i> {withdrawal.mobileNumber}</span>
                      <span><i className="fa-regular fa-calendar"></i> {formatDate(withdrawal.requestedAt?.toDate?.())}</span>
                    </div>
                  </div>
                  <i className="fa-solid fa-chevron-right"></i>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* ডিটেইলস মোডাল */}
        {selectedWithdrawal && (
          <div className="modal-overlay" onClick={() => setSelectedWithdrawal(null)}>
            <div className="details-modal" onClick={(e) => e.stopPropagation()}>
              <div className="modal-header">
                <h3><i className="fa-solid fa-receipt"></i> Withdrawal Details</h3>
                <button className="close-btn" onClick={() => setSelectedWithdrawal(null)}>
                  <i className="fa-solid fa-xmark"></i>
                </button>
              </div>
              <div className="modal-body">
                <div className="detail-row">
                  <span>Amount:</span>
                  <strong>{formatMoney(selectedWithdrawal.amount)}</strong>
                </div>
                <div className="detail-row">
                  <span>Status:</span>
                  <span className={`status-badge ${getStatusClass(selectedWithdrawal.status)}`}>
                    {selectedWithdrawal.status}
                  </span>
                </div>
                <div className="detail-row">
                  <span>Payment Method:</span>
                  <span>{selectedWithdrawal.paymentMethod}</span>
                </div>
                <div className="detail-row">
                  <span>Mobile Number:</span>
                  <span>{selectedWithdrawal.mobileNumber}</span>
                </div>
                {selectedWithdrawal.accountHolder && (
                  <div className="detail-row">
                    <span>Account Holder:</span>
                    <span>{selectedWithdrawal.accountHolder}</span>
                  </div>
                )}
                {selectedWithdrawal.bankName && (
                  <div className="detail-row">
                    <span>Bank Name:</span>
                    <span>{selectedWithdrawal.bankName}</span>
                  </div>
                )}
                {selectedWithdrawal.accountNumber && (
                  <div className="detail-row">
                    <span>Account Number:</span>
                    <span>{selectedWithdrawal.accountNumber}</span>
                  </div>
                )}
                <div className="detail-row">
                  <span>Requested:</span>
                  <span>{formatDate(selectedWithdrawal.requestedAt?.toDate?.())}</span>
                </div>
                {selectedWithdrawal.processedAt && (
                  <div className="detail-row">
                    <span>Processed:</span>
                    <span>{formatDate(selectedWithdrawal.processedAt?.toDate?.())}</span>
                  </div>
                )}
                {selectedWithdrawal.transactionId && (
                  <div className="detail-row">
                    <span>Transaction ID:</span>
                    <span className="tx-id">{selectedWithdrawal.transactionId}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};

export default Withdraw;