// src/pages/Wallet.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth, db } from '../firebase';
import { 
  doc, getDoc, setDoc, updateDoc, collection, query, where, 
  onSnapshot, orderBy, addDoc, serverTimestamp, 
  runTransaction, Timestamp
} from 'firebase/firestore';
import './Wallet.css';
import WalletActions from './WalletActions';
import { generateWalletId } from '../utils/idGenerator';


const Wallet = () => {
  const navigate = useNavigate();
  const user = auth.currentUser;
  
  // ✅ স্টেট
  const [loading, setLoading] = useState(true);
  const [walletData, setWalletData] = useState({
    balance: 0,
    totalEarned: 0,
    totalWithdrawn: 0,
    pendingWithdraw: 0
  });
  const [transactions, setTransactions] = useState([]);
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawMethod, setWithdrawMethod] = useState('bKash');
  const [mobileNumber, setMobileNumber] = useState('');
  const [withdrawLoading, setWithdrawLoading] = useState(false);
  const [withdrawError, setWithdrawError] = useState('');
  const [quickAmounts] = useState([100, 200, 500, 1000, 2000]);

  // ============================================================
  // ✅ ১. রিয়েল-টাইম ওয়ালেট লিসেনার
  // ============================================================
  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    // 🔥 ওয়ালেট ডকুমেন্ট তৈরি করুন
    const initWallet = async () => {
      try {
        const walletRef = doc(db, 'wallets', user.uid);
        const walletSnap = await getDoc(walletRef);
        
        if (!walletSnap.exists()) {
          const newWallet = {
            balance: 0,
            totalEarned: 0,
            totalWithdrawn: 0,
            pendingWithdraw: 0,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp()
          };
          await setDoc(walletRef, newWallet);
          console.log('✅ New wallet created for user:', user.uid);
        }
      } catch (error) {
        console.error('❌ Error initializing wallet:', error);
      }
    };
    initWallet();


    // Wallet.jsx
import { generateWalletId } from '../utils/idGenerator';

const Wallet = () => {
  const { userData } = useAuth();
  
  return (
    <div className="wallet-container">
      <div className="wallet-header">
        <h3>💳 আমার ওয়ালেট</h3>
        <div className="wallet-id">
          <span>🆔 ওয়ালেট আইডি:</span>
          <strong>{userData?.walletId || 'Loading...'}</strong>
          <button onClick={() => navigator.clipboard.writeText(userData?.walletId)}>
            📋 কপি
          </button>
        </div>
      </div>
      <div className="wallet-balance">
        <h2>৳ {userData?.balance || 0}</h2>
        <p>বর্তমান ব্যালেন্স</p>
      </div>
    </div>
  );
};

    // 🔥 রিয়েল-টাইম ওয়ালেট লিসেনার
    const walletRef = doc(db, 'wallets', user.uid);
    const unsubscribeWallet = onSnapshot(walletRef, (doc) => {
      if (doc.exists()) {
        const data = doc.data();
        setWalletData({
          balance: data.balance || 0,
          totalEarned: data.totalEarned || 0,
          totalWithdrawn: data.totalWithdrawn || 0,
          pendingWithdraw: data.pendingWithdraw || 0
        });
        console.log('💰 Wallet updated:', data.balance);
      }
      setLoading(false);
    }, (error) => {
      console.error("❌ Wallet listener error:", error);
      setLoading(false);
    });

    // 🔥 রিয়েল-টাইম ট্রানজেকশন লিসেনার
    const transactionsRef = collection(db, 'transactions');
    const q = query(
      transactionsRef,
      where('userId', '==', user.uid),
      orderBy('createdAt', 'desc'),
      orderBy('id', 'desc') // ✅ সমান ক্রমের জন্য
    );

    const unsubscribeTransactions = onSnapshot(q, (snapshot) => {
      const fetchedTransactions = snapshot.docs.map(doc => {
        const data = doc.data();
        let date = 'Just now';
        
        if (data.createdAt) {
          if (data.createdAt instanceof Timestamp) {
            date = data.createdAt.toDate().toLocaleDateString('en-BD', {
              day: '2-digit',
              month: 'short',
              year: 'numeric',
              hour: '2-digit',
              minute: '2-digit'
            });
          } else if (data.createdAt?.toDate) {
            date = data.createdAt.toDate().toLocaleDateString('en-BD', {
              day: '2-digit',
              month: 'short',
              year: 'numeric',
              hour: '2-digit',
              minute: '2-digit'
            });
          }
        }
        
        return {
          id: doc.id,
          ...data,
          date: date
        };
      });
      
      setTransactions(fetchedTransactions);
    }, (error) => {
      console.error("❌ Transactions listener error:", error);
    });

    // ✅ ক্লিনআপ
    return () => {
      unsubscribeWallet();
      unsubscribeTransactions();
    };
  }, [user, navigate]);

  // ============================================================
  // ✅ ২. উইথড্র - Firestore Transaction
  // ============================================================
  const handleWithdraw = async () => {
    // ✅ ভ্যালিডেশন
    const errors = [];
    const amount = Number(withdrawAmount);
    
    if (!withdrawAmount || amount <= 0) {
      errors.push('Please enter a valid amount!');
    }
    
    if (amount < 100) {
      errors.push('Minimum withdrawal amount is 100 BDT!');
    }
    
    if (amount > walletData.balance) {
      errors.push(`Insufficient balance! Available: ৳${walletData.balance}`);
    }
    
    if (!mobileNumber || mobileNumber.length < 11) {
      errors.push('Please enter a valid mobile number (11 digits)!');
    }
    
    if (!/^01[3-9]\d{8}$/.test(mobileNumber.trim())) {
      errors.push('Please enter a valid Bangladesh mobile number!');
    }
    
    if (errors.length > 0) {
      setWithdrawError(errors[0]);
      return;
    }
    
    setWithdrawError('');
    setWithdrawLoading(true);

    try {
      const walletRef = doc(db, 'wallets', user.uid);
      const amountNum = Number(withdrawAmount);
      const timestamp = serverTimestamp();

      await runTransaction(db, async (transaction) => {
        const walletDoc = await transaction.get(walletRef);
        
        if (!walletDoc.exists()) {
          throw new Error('Wallet does not exist!');
        }

        const currentBalance = walletDoc.data().balance || 0;

        if (currentBalance < amountNum) {
          throw new Error(`Insufficient balance! Available: ৳${currentBalance}`);
        }

        // ✅ ১. ওয়ালেট আপডেট
        transaction.update(walletRef, {
          balance: currentBalance - amountNum,
          pendingWithdraw: (walletDoc.data().pendingWithdraw || 0) + amountNum,
          totalWithdrawn: (walletDoc.data().totalWithdrawn || 0) + amountNum,
          updatedAt: timestamp
        });

        // ✅ ২. উইথড্র রেকর্ড
        const withdrawRef = doc(collection(db, 'withdrawals'));
        transaction.set(withdrawRef, {
          userId: user.uid,
          userEmail: user.email,
          userName: user.displayName || user.email?.split('@')[0] || 'User',
          amount: amountNum,
          status: 'pending',
          paymentMethod: withdrawMethod,
          mobileNumber: mobileNumber.trim(),
          requestedAt: timestamp,
          createdAt: timestamp,
          withdrawalId: `WD-${Date.now()}`,
          userUid: user.uid
        });

        // ✅ ৩. ট্রানজেকশন হিস্টোরি
        const txRef = doc(collection(db, 'transactions'));
        transaction.set(txRef, {
          userId: user.uid,
          userEmail: user.email,
          amount: amountNum,
          type: 'withdraw',
          status: 'pending',
          title: `Withdrawal via ${withdrawMethod}`,
          reference: `WD-${Date.now()}`,
          createdAt: timestamp,
          updatedAt: timestamp,
          source: 'withdraw_form',
          paymentMethod: withdrawMethod,
          mobileNumber: mobileNumber.trim()
        });
      });

      // ✅ সাফল্য
      alert(`✅ Withdrawal request submitted successfully!\n\n` +
            `💰 Amount: ৳${amountNum}\n` +
            `🏦 Method: ${withdrawMethod}\n` +
            `📱 Mobile: ${mobileNumber}\n\n` +
            `⏳ Please wait 5-10 minutes for processing.`);

      // ✅ ফর্ম ক্লিয়ার
      setShowWithdrawModal(false);
      setWithdrawAmount('');
      setMobileNumber('');
      setWithdrawMethod('bKash');
      
    } catch (error) {
      console.error("❌ Transaction failed:", error);
      setWithdrawError(error.message || 'Failed to submit withdrawal request.');
    } finally {
      setWithdrawLoading(false);
    }
  };

  // ============================================================
  // ✅ ৩. হ্যান্ডেল প্রি-সেট অ্যামাউন্ট ক্লিক
  // ============================================================
  const handleQuickAmountClick = (amount) => {
    setWithdrawAmount(String(amount));
    setWithdrawError('');
  };

  // ============================================================
  // ✅ ৪. রিফ্রেশ ফাংশন
  // ============================================================
  const handleRefresh = () => {
    // onSnapshot ইতিমধ্যেই রিয়েল-টাইম
    alert('🔄 Balance is already real-time! No refresh needed.');
  };

  // ========== ইউটিলিটি ফাংশন ==========
  const formatMoney = (amount) => {
    return new Intl.NumberFormat('bn-BD', {
      style: 'currency',
      currency: 'BDT',
      minimumFractionDigits: 0
    }).format(amount);
  };

  const getTransactionIcon = (type) => {
    const icons = {
      'credit': 'fa-solid fa-arrow-down',
      'debit': 'fa-solid fa-arrow-up',
      'withdraw': 'fa-solid fa-money-bill-transfer',
      'deposit': 'fa-solid fa-circle-dollar',
      'earning': 'fa-solid fa-chart-simple',
      'bonus': 'fa-solid fa-gift'
    };
    return icons[type] || 'fa-solid fa-circle-dollar';
  };

  const getTransactionColor = (type) => {
    const colors = {
      'credit': '#10b981',
      'debit': '#ef4444',
      'withdraw': '#f59e0b',
      'deposit': '#14b8a6',
      'earning': '#8b5cf6',
      'bonus': '#ec4899'
    };
    return colors[type] || '#14b8a6';
  };

  const getStatusConfig = (status) => {
    const configs = {
      'completed': { color: '#10b981', icon: 'fa-check-circle', text: 'Completed' },
      'pending': { color: '#f59e0b', icon: 'fa-clock', text: 'Pending' },
      'failed': { color: '#ef4444', icon: 'fa-times-circle', text: 'Failed' },
      'processing': { color: '#3b82f6', icon: 'fa-spinner fa-spin', text: 'Processing' },
      'cancelled': { color: '#6b7280', icon: 'fa-ban', text: 'Cancelled' }
    };
    return configs[status] || configs['pending'];
  };

  // ============================================================
  // ✅ লোডিং স্টেট
  // ============================================================
  if (loading) {
    return (
      <div className="wallet-loading">
        <div className="loading-spinner"></div>
        <p>Loading wallet...</p>
      </div>
    );
  }

  // ============================================================
  // ✅ রেন্ডার
  // ============================================================
  return (
    <div className="wallet-container">
      
      {/* ========== ১. ওয়ালেট অ্যাকশন মডিউল ========== */}
      <WalletActions 
        walletBalance={walletData.balance} 
        onRefresh={handleRefresh}
      />

      {/* ========== ২. ব্যালেন্স কার্ড ========== */}
      <div className="balance-card">
        <div className="balance-header">
          <h3>
            <i className="fa-solid fa-chart-line"></i> Balance Summary
            <span className="realtime-badge">
              <i className="fa-solid fa-circle" style={{ color: '#10b981', fontSize: '8px' }}></i> Live
            </span>
          </h3>
          <button className="refresh-btn" onClick={handleRefresh} title="Real-time updates active">
            <i className="fa-solid fa-rotate-right"></i>
          </button>
        </div>
        
        <div className="balance-amount">{formatMoney(walletData.balance)}</div>
        
        <div className="balance-stats">
          <div className="stat-item">
            <span className="stat-label">Total Earned</span>
            <span className="stat-value" style={{ color: '#10b981' }}>
              {formatMoney(walletData.totalEarned)}
            </span>
          </div>
          <div className="stat-item">
            <span className="stat-label">Total Withdrawn</span>
            <span className="stat-value" style={{ color: '#f59e0b' }}>
              {formatMoney(walletData.totalWithdrawn)}
            </span>
          </div>
          <div className="stat-item">
            <span className="stat-label">Pending</span>
            <span className="stat-value" style={{ color: '#3b82f6' }}>
              {formatMoney(walletData.pendingWithdraw)}
            </span>
          </div>
        </div>

        <button 
          className="withdraw-btn" 
          onClick={() => setShowWithdrawModal(true)}
          disabled={walletData.balance < 100}
        >
          <i className="fa-solid fa-money-bill-wave"></i> 
          {walletData.balance < 100 ? 'Minimum ৳100 required' : 'Withdraw Now'}
        </button>
      </div>

      {/* ========== ৩. ট্রানজেকশন লিস্ট ========== */}
      <div className="transactions-section">
        <div className="section-header">
          <h3><i className="fa-solid fa-clock-rotate-left"></i> Recent Transactions</h3>
          <button className="view-all-btn" onClick={() => navigate('/transactions')}>
            View All <i className="fa-solid fa-arrow-right"></i>
          </button>
        </div>

        <div className="transactions-list">
          {transactions.length === 0 ? (
            <div className="no-transactions">
              <i className="fa-solid fa-receipt"></i>
              <p>No transactions yet</p>
              <small>Your transaction history will appear here</small>
            </div>
          ) : (
            transactions.slice(0, 10).map((tx) => {
              const statusConfig = getStatusConfig(tx.status);
              const color = getTransactionColor(tx.type);
              const icon = getTransactionIcon(tx.type);

              return (
                <div key={tx.id} className="transaction-item">
                  {/* আইকন */}
                  <div className="tx-icon" style={{ background: `${color}15` }}>
                    <i className={icon} style={{ color: color }}></i>
                  </div>

                  {/* ডিটেইলস */}
                  <div className="tx-details">
                    <h4>{tx.title || (tx.type === 'credit' ? 'Payment Received' : 'Payment Sent')}</h4>
                    <p className="tx-date">{tx.date || 'Just now'}</p>
                    {tx.reference && (
                      <small className="tx-reference">{tx.reference}</small>
                    )}
                  </div>

                  {/* অ্যামাউন্ট ও স্ট্যাটাস */}
                  <div className="tx-right">
                    <div className={`tx-amount ${tx.type}`}>
                      {tx.type === 'credit' || tx.type === 'deposit' || tx.type === 'earning' ? '+' : '-'} 
                      {formatMoney(tx.amount)}
                    </div>
                    
                    <div className="tx-status-badge" style={{ 
                      color: statusConfig.color, 
                      background: `${statusConfig.color}15` 
                    }}>
                      <i className={`fa-solid ${statusConfig.icon}`}></i>
                      <span>{statusConfig.text}</span>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* ========== ৪. উইথড্র মোডাল ========== */}
      {showWithdrawModal && (
        <div className="modal-overlay" onClick={() => setShowWithdrawModal(false)}>
          <div className="withdraw-modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3><i className="fa-solid fa-money-bill-transfer"></i> Withdraw Funds</h3>
              <button className="close-btn" onClick={() => {
                setShowWithdrawModal(false);
                setWithdrawError('');
              }}>
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>

            <div className="modal-body">
              {/* এভেইলেবল ব্যালেন্স */}
              <div className="available-balance">
                <span>Available Balance:</span>
                <strong>{formatMoney(walletData.balance)}</strong>
              </div>

              {/* ✅ কুইক অ্যামাউন্ট বাটন */}
              <div className="quick-amounts">
                <label>Quick Amount</label>
                <div className="quick-amount-buttons">
                  {quickAmounts.map((amount) => (
                    <button
                      key={amount}
                      className={`quick-amount-btn ${Number(withdrawAmount) === amount ? 'active' : ''}`}
                      onClick={() => handleQuickAmountClick(amount)}
                      disabled={amount > walletData.balance}
                    >
                      ৳{amount}
                    </button>
                  ))}
                </div>
              </div>

              {/* অ্যামাউন্ট ইনপুট */}
              <div className="form-group">
                <label>Amount (BDT)</label>
                <input 
                  type="number" 
                  value={withdrawAmount}
                  onChange={(e) => {
                    setWithdrawAmount(e.target.value);
                    setWithdrawError('');
                  }}
                  placeholder="Enter amount"
                  min="100"
                  max={walletData.balance}
                  className={withdrawError ? 'error' : ''}
                />
                <div className="form-hint">
                  <small>Minimum: ৳100 • Maximum: ৳{walletData.balance}</small>
                </div>
              </div>

              {/* পেমেন্ট মেথড */}
              <div className="form-group">
                <label>Payment Method</label>
                <div className="method-options">
                  {['bKash', 'Nagad', 'Rocket'].map((method) => (
                    <label 
                      key={method}
                      className={`method-option ${withdrawMethod === method ? 'active' : ''}`}
                    >
                      <input 
                        type="radio" 
                        value={method} 
                        checked={withdrawMethod === method} 
                        onChange={(e) => setWithdrawMethod(e.target.value)}
                      />
                      {method === 'bKash' && <i className="fa-brands fa-btc"></i>}
                      {method === 'Nagad' && <i className="fa-solid fa-n"></i>}
                      {method === 'Rocket' && <i className="fa-solid fa-rocket"></i>}
                      {method}
                    </label>
                  ))}
                </div>
              </div>

              {/* মোবাইল নম্বর */}
              <div className="form-group">
                <label>Mobile Number</label>
                <input 
                  type="tel" 
                  value={mobileNumber}
                  onChange={(e) => {
                    const value = e.target.value.replace(/\D/g, '');
                    setMobileNumber(value);
                    setWithdrawError('');
                  }}
                  placeholder="01XXXXXXXXX"
                  maxLength="11"
                  className={withdrawError ? 'error' : ''}
                />
                <div className="form-hint">
                  <small><i className="fa-solid fa-info-circle"></i> Enter the number where you'll receive money</small>
                </div>
              </div>

              {/* ✅ এরর মেসেজ */}
              {withdrawError && (
                <div className="error-message">
                  <i className="fa-solid fa-exclamation-circle"></i>
                  <span>{withdrawError}</span>
                </div>
              )}

              {/* ফি ইনফো */}
              <div className="fee-info">
                <i className="fa-solid fa-circle-info"></i>
                <span>Withdrawal fee: <strong>0%</strong> (Free)</span>
                <span className="fee-separator">•</span>
                <span>Processing time: 5-10 minutes</span>
              </div>
            </div>

            <div className="modal-footer">
              <button 
                className="cancel-btn" 
                onClick={() => {
                  setShowWithdrawModal(false);
                  setWithdrawError('');
                }}
              >
                Cancel
              </button>
              <button 
                className="confirm-btn" 
                onClick={handleWithdraw}
                disabled={
                  withdrawLoading || 
                  !withdrawAmount || 
                  Number(withdrawAmount) < 100 || 
                  Number(withdrawAmount) > walletData.balance ||
                  mobileNumber.length < 11
                }
              >
                {withdrawLoading ? (
                  <>
                    <i className="fa-solid fa-spinner fa-spin"></i> Processing...
                  </>
                ) : (
                  <>
                    <i className="fa-solid fa-check"></i> Confirm Withdrawal
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

export default Wallet;