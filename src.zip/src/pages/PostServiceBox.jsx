import React, { useState, useRef } from 'react';
import { collection, doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';
import './PostServiceBox.css';

function PostServiceBox({ onClose, setActiveTab, onSilentPost, currentUser }) {
  const [serviceTitle, setServiceTitle] = useState('');
  // const [category, setCategory] = useState('web');
  const [deliveryTime, setDeliveryTime] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [error, setError] = useState('');
  
  const [selectedImages, setSelectedImages] = useState([]);
  const [imagePreviews, setImagePreviews] = useState([]);
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef(null);
  
  const isSubmitting = useRef(false);
  const lastSubmitTime = useRef(0);

  const CLOUD_NAME = "drwex6tmf";
  const UPLOAD_PRESET = "workhub_preset";

  // ============================================================
  // ✅ ক্যাটাগরি অপশন
  // ============================================================
  // const categories = [
  //   { value: 'web', label: 'Web Development' },
  //   { value: 'app', label: 'App Development' },
  //   { value: 'design', label: 'UI/UX Design' },
  //   { value: 'graphics', label: 'Graphics Design' },
  //   { value: 'marketing', label: 'Digital Marketing' },
  //   { value: 'writing', label: 'Content Writing' },
  //   { value: 'seo', label: 'SEO & SEM' },
  //   { value: 'data', label: 'Data Entry' },
  //   { value: 'video', label: 'Video Editing' },
  //   { value: 'others', label: 'Others' }
  // ];

  // ============================================================
  // ✅ Cloudinary আপলোড
  // ============================================================
  const uploadToCloudinary = async (file) => {
    const formData = new FormData();
    formData.append("file", file);
    formData.append("upload_preset", UPLOAD_PRESET);
    try {
      const res = await fetch(`https://api.cloudinary.com/v1_1/${CLOUD_NAME}/image/upload`, { 
        method: "POST", 
        body: formData 
      });
      const data = await res.json();
      return data.secure_url;
    } catch (error) {
      console.error("Upload Error:", error);
      return null;
    }
  };

  // ============================================================
  // ✅ ইমেজ হ্যান্ডলার
  // ============================================================
  const handleImageChange = (e) => {
    setError('');
    const files = Array.from(e.target.files);
    
    if (selectedImages.length + files.length > 2) {
      setError("⚠️ You can upload maximum 2 images!");
      if (fileInputRef.current) fileInputRef.current.value = ''; 
      return;
    }

    const newFiles = [];
    const newPreviews = [];

    files.forEach(file => {
      if (file.size > 5 * 1024 * 1024) {
        setError(`${file.name} is larger than 5MB!`);
        return;
      }
      if (!file.type.startsWith('image/')) {
        setError(`${file.name} is not an image!`);
        return;
      }
      newFiles.push(file);
      newPreviews.push(URL.createObjectURL(file));
    });

    setSelectedImages(prev => [...prev, ...newFiles]);
    setImagePreviews(prev => [...prev, ...newPreviews]);

    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleRemoveImage = (index) => {
    setSelectedImages(prev => prev.filter((_, i) => i !== index));
    setImagePreviews(prev => prev.filter((_, i) => i !== index));
  };

  // ============================================================
  // ✅ ফর্ম ভ্যালিডেশন
  // ============================================================
  const validateForm = () => {
    if (!serviceTitle.trim()) {
      setError('Please enter a service title');
      return false;
    }
    if (serviceTitle.trim().length < 5) {
      setError('Service title must be at least 5 characters');
      return false;
    }
    if (!description.trim()) {
      setError('Please enter a service description');
      return false;
    }
    if (description.trim().length < 20) {
      setError('Description must be at least 20 characters');
      return false;
    }
    if (!price || Number(price) < 100) {
      setError('Price must be at least 100 BDT');
      return false;
    }
    if (Number(price) > 1000000) {
      setError('Price cannot exceed 1,000,000 BDT');
      return false;
    }
    if (!deliveryTime || Number(deliveryTime) < 1) {
      setError('Delivery time must be at least 1 day');
      return false;
    }
    if (Number(deliveryTime) > 365) {
      setError('Delivery time cannot exceed 365 days');
      return false;
    }
    if (selectedImages.length === 0) {
      setError('Please upload at least 1 image');
      return false;
    }
    return true;
  };

  // ============================================================
  // ✅ ফর্ম সাবমিট
  // ============================================================
  const handlePublishService = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    
    setError('');
    
    const now = Date.now();
    if (now - lastSubmitTime.current < 2000) {
      console.log("⏳ Too fast, ignoring duplicate request");
      return;
    }
    
    if (isSubmitting.current || loading) {
      console.log("⏳ Already submitting");
      return;
    }
    
    if (!currentUser) {
      setError("Please login to post a service!");
      return;
    }
    
    if (!validateForm()) {
      return;
    }

    isSubmitting.current = true;
    setLoading(true);
    lastSubmitTime.current = now;

    try {
      // ইমেজ আপলোড
      const uploadedImageUrls = [];
      for (let file of selectedImages) {
        const url = await uploadToCloudinary(file);
        if (url) {
          uploadedImageUrls.push(url);
        }
      }

      if (uploadedImageUrls.length === 0) {
        setError("Failed to upload images. Please try again.");
        return;
      }

      // ইউনিক আইডি
      const uniqueId = `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      const serviceData = {
        type: 'service',
        mode: 'freelancer',
        title: serviceTitle.trim(),
        // category: category,
        description: description.trim(),
        price: Number(price),
        deliveryDays: Number(deliveryTime),
        images: uploadedImageUrls,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        userId: currentUser.uid,
        buyerId: null,
        sellerId: currentUser.uid,
        clientName: currentUser.displayName || currentUser.email?.split('@')[0] || "Service Provider",
        clientPhoto: currentUser.photoURL || null,
        clientEmail: currentUser.email,
        verified: false,
        status: 'active',
        proposals: 0,
        _uniqueId: uniqueId
      };

      console.log("📤 Publishing Service with unique ID:", uniqueId);
      
      const postRef = doc(db, 'posts', uniqueId);
      await setDoc(postRef, serviceData);
      
      console.log("✅ Service posted with ID:", uniqueId);

      alert('🚀 Service Published Successfully!');
      resetForm();
      
      if (setActiveTab) setActiveTab('dashboard');
      if (onClose) onClose();
      
    } catch (error) {
      console.error("❌ Upload Error:", error);
      setError('Failed to post service: ' + error.message);
    } finally {
      setLoading(false);
      setTimeout(() => {
        isSubmitting.current = false;
      }, 1000);
    }
  };

  // ============================================================
  // ✅ ফর্ম রিসেট
  // ============================================================
  const resetForm = () => {
    setServiceTitle('');
    setCategory('web');
    setDeliveryTime('');
    setDescription('');
    setPrice('');
    setSelectedImages([]);
    setImagePreviews([]);
    setError('');
  };

  const isButtonDisabled = selectedImages.length === 0 || loading;

  // ============================================================
  // ✅ রেন্ডার
  // ============================================================
  return (
    <div className="global-modal-overlay" onClick={onClose}>
      <div className="post-add-box" onClick={(e) => e.stopPropagation()}>
        
        <div className="pbox-header">
          <h3>
            <i className="fa-solid fa-laptop-code" style={{ color: '#fbbf24' }}></i> 
            Create a New Service Gig
          </h3>
          <button type="button" className="pbox-close-btn" onClick={onClose}>
            <i className="fa-solid fa-xmark"></i>
          </button>
        </div>

        <form onSubmit={handlePublishService}>
          <div className="pbox-body-form">
            
            {/* Error */}
            {error && (
              <div className="pbox-error">
                <i className="fa-solid fa-exclamation-circle"></i>
                {error}
              </div>
            )}

            {/* Service Title */}
            <div className="pb-group">
              <label>
                Service Title <span className="required-star">*</span>
              </label>
              <input 
                type="text" 
                value={serviceTitle}
                onChange={(e) => setServiceTitle(e.target.value)}
                placeholder="e.g., I will build a responsive React Website" 
                maxLength="100"
                required 
                disabled={loading}
              />
              <small className="char-count">{serviceTitle.length}/100</small>
            </div>

            {/* Category
            <div className="pb-group">
              <label>Category <span className="required-star">*</span></label>
              <select 
                value={category} 
                onChange={(e) => setCategory(e.target.value)} 
                disabled={loading}
              >
                {categories.map((cat) => (
                  <option key={cat.value} value={cat.value}>
                    {cat.label}
                  </option>
                ))}
              </select>
            </div> */}

            {/* Description */}
            <div className="pb-group">
              <label>Service Description <span className="required-star">*</span></label>
              <textarea 
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Detailed description of your service..."
                rows="4"
                maxLength="5000"
                required
                disabled={loading}
              />
              <small className="char-count">{description.length}/5000</small>
            </div>

            {/* Images */}
            <div className="pb-group">
              <label>
                Service Images <span className="required-star">*</span>
                <span className="image-hint">(Maximum 2 images)</span>
              </label>
              <input 
                type="file" 
                accept="image/*" 
                style={{ display: 'none' }} 
                ref={fileInputRef}
                onChange={handleImageChange}
                multiple 
                disabled={loading}
              />

              {selectedImages.length < 2 ? (
                <div 
                  className="upload-drop-zone" 
                  onClick={() => !loading && fileInputRef.current.click()}
                  onDragOver={(e) => { e.preventDefault(); e.currentTarget.classList.add('drag-over'); }}
                  onDragLeave={(e) => e.currentTarget.classList.remove('drag-over')}
                  onDrop={(e) => {
                    e.preventDefault();
                    e.currentTarget.classList.remove('drag-over');
                    const files = Array.from(e.dataTransfer.files);
                    if (files.length > 0) {
                      const inputEvent = { target: { files: files } };
                      handleImageChange(inputEvent);
                    }
                  }}
                >
                  <i className="fa-solid fa-cloud-arrow-up"></i>
                  <p>Click or drag to upload images</p>
                  <span>{selectedImages.length}/2 used • JPG, PNG (Max 5MB)</span>
                </div>
              ) : (
                <div className="upload-drop-zone-disabled">
                  <p>
                    <i className="fa-solid fa-circle-check" style={{ color: '#438e82' }}></i> 
                    2 images uploaded (Maximum reached)
                  </p>
                </div>
              )}

              {imagePreviews.length > 0 && (
                <div className="multi-preview-grid">
                  {imagePreviews.map((previewUrl, index) => (
                    <div key={index} className="upload-preview-container">
                      <img src={previewUrl} alt={`Preview ${index}`} className="uploaded-live-img" />
                      <button 
                        type="button" 
                        className="remove-img-btn" 
                        onClick={() => handleRemoveImage(index)}
                        disabled={loading}
                      >
                        <i className="fa-solid fa-trash-can"></i>
                      </button>
                      <span className="image-order-badge">{index + 1}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Price & Delivery */}
            <div className="pb-row-twin">
              <div className="pb-group">
                <label>Price (BDT) <span className="required-star">*</span></label>
                <input 
                  type="number" 
                  value={price} 
                  onChange={(e) => setPrice(e.target.value)} 
                  placeholder="e.g., 5000" 
                  min="100" 
                  max="1000000"
                  required 
                  disabled={loading}
                />
                <small>Min: 100 BDT • Max: 1,000,000 BDT</small>
              </div>
              <div className="pb-group">
                <label>Delivery Time (Days) <span className="required-star">*</span></label>
                <input 
                  type="number" 
                  value={deliveryTime} 
                  onChange={(e) => setDeliveryTime(e.target.value)} 
                  placeholder="e.g., 7" 
                  min="1" 
                  max="365"
                  required 
                  disabled={loading}
                />
                <small>Min: 1 day • Max: 365 days</small>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="pbox-footer">
            <button 
              type="button" 
              className="pbox-btn pb-btn-close" 
              onClick={onClose} 
              disabled={loading}
            >
              Cancel
            </button>
            <button 
              type="reset" 
              className="pbox-btn pb-btn-reset" 
              onClick={resetForm}
              disabled={loading}
            >
              <i className="fa-solid fa-rotate"></i> Reset
            </button>
            <button 
              type="submit" 
              className={`pbox-btn pb-btn-publish ${isButtonDisabled ? 'btn-locked-style' : ''}`} 
              disabled={isButtonDisabled || loading}
            >
              {loading ? (
                <>
                  <i className="fa-solid fa-spinner fa-spin"></i> Publishing...
                </>
              ) : (
                <>
                  <i className="fa-solid fa-paper-plane"></i> Publish Service
                </>
              )}
            </button>
          </div>
        </form>

      </div>
    </div>
  );
}

export default PostServiceBox;
