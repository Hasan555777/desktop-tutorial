// src/pages/PaymentGateway.jsx
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { auth, db } from '../firebase';
import { doc, getDoc } from 'firebase/firestore';
import { initiatePayment, executePaymentFlow, checkPaymentStatus } from './paymentFlow';
import BKashPayment from './bKashPayment';
import './PaymentGateway.css';

const PaymentGateway = () => {
  const { dealId, milestoneId } = useParams();
  const navigate = useNavigate();
  const user = auth.currentUser;

  const [loading, setLoading] = useState(true);
  const [dealData, setDealData] = useState(null);
  const [milestone, setMilestone] = useState(null);
  const [showBkashModal, setShowBkashModal] = useState(false);
  const [paymentStep, setPaymentStep] = useState(1);
  const [transactionId, setTransactionId] = useState('');
  const [processing, setProcessing] = useState(false);
  const [paymentID, setPaymentID] = useState(null);
  const [error, setError] = useState('');
  
  // ✅ ইউজারের রোল চেক
  const [isBuyer, setIsBuyer] = useState(false);

  // ============================================================
  // ✅ ডেটা লোড + রোল চেক
  // ============================================================
  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    const loadData = async () => {
      try {
        const dealRef = doc(db, 'deals', dealId);
        const dealSnap = await getDoc(dealRef);
        
        if (dealSnap.exists()) {
          const deal = dealSnap.data();
          setDealData(deal);
          
          // ✅ চেক করুন: বর্তমান ইউজার কি Buyer?
          const currentUserIsBuyer = deal.buyerId === user.uid;
          setIsBuyer(currentUserIsBuyer);
          
          // ✅ যদি ইউজার Buyer না হয়, তাহলে পেমেন্ট করতে পারবে না
          if (!currentUserIsBuyer) {
            setError('❌ Only the Buyer can make payment for this milestone.');
            setPaymentStep(0); // Error state
          }
          
          const foundMilestone = deal.milestones?.find(m => m.id === parseInt(milestoneId));
          if (foundMilestone) {
            setMilestone(foundMilestone);
          } else {
            alert('Milestone not found!');
            navigate(`/deal-manager?dealId=${dealId}`);
          }
        } else {
          alert('Deal not found!');
          navigate('/deal-manager');
        }
      } catch (error) {
        console.error("Error:", error);
        setError('Failed to load payment details');
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [dealId, milestoneId, user, navigate]);

  // ============================================================
  // ✅ bKash পেমেন্ট শুরু
  // ============================================================
  const handleBkashPayment = async () => {
    // ✅ চেক: শুধুমাত্র Buyer পেমেন্ট করতে পারে
    if (!isBuyer) {
      setError('❌ You are not authorized to make this payment.');
      return;
    }

    setError('');
    setProcessing(true);
    setPaymentStep(2);
    
    try {
      const result = await initiatePayment(
        dealId, 
        milestoneId, 
        milestone?.amount, 
        user?.uid
      );
      
      if (result.success) {
        setPaymentID(result.paymentID);
        setShowBkashModal(true);
      } else {
        setError(result.error || 'Payment initiation failed');
        setPaymentStep(1);
      }
    } catch (error) {
      console.error("Payment initiation error:", error);
      setError('Failed to initiate payment. Please try again.');
      setPaymentStep(1);
    }
    
    setProcessing(false);
  };

  // ============================================================
  // ✅ bKash পেমেন্ট সফল
  // ============================================================
  const handleBkashSuccess = async (paymentData) => {
    setShowBkashModal(false);
    setProcessing(true);
    setError('');
    
    try {
      const result = await executePaymentFlow(paymentData.paymentID);
      
      if (result.success) {
        setTransactionId(result.trxID);
        setPaymentStep(3);
        alert('✅ Payment successful! Amount: ' + formatMoney(milestone?.amount));
      } else {
        setError(result.error || 'Payment execution failed');
        setPaymentStep(1);
      }
    } catch (error) {
      console.error("Payment execution error:", error);
      setError('Payment processing failed. Please contact support.');
      setPaymentStep(1);
    }
    
    setProcessing(false);
  };

  // ============================================================
  // ✅ পেমেন্ট স্ট্যাটাস চেক
  // ============================================================
  useEffect(() => {
    const checkPendingPayment = async () => {
      if (paymentID && paymentStep === 2) {
        const status = await checkPaymentStatus(paymentID);
        if (status.status === 'Completed') {
          setPaymentStep(3);
          setShowBkashModal(false);
        } else if (status.status === 'Failed' || status.status === 'Cancelled') {
          setError('Payment was cancelled or failed');
          setPaymentStep(1);
        }
      }
    };
    
    checkPendingPayment();
  }, [paymentID, paymentStep]);

  // ============================================================
  // ✅ টাকা ফরম্যাট
  // ============================================================
  const formatMoney = (amount) => {
    return new Intl.NumberFormat('bn-BD', {
      style: 'currency',
      currency: 'BDT',
      minimumFractionDigits: 0
    }).format(amount || 0);
  };

  // ============================================================
  // ✅ লোডিং স্টেট
  // ============================================================
  if (loading) {
    return (
      <div className="payment-loading">
        <div className="loading-spinner"></div>
        <p>Loading payment information...</p>
      </div>
    );
  }

  // ============================================================
  // ✅ Error State (যদি ইউজার Buyer না হয়)
  // ============================================================
  if (paymentStep === 0) {
    return (
      <div className="payment-container">
        <div className="payment-card">
          <div className="payment-error-state">
            <i className="fa-solid fa-lock" style={{ fontSize: '48px', color: '#ef4444' }}></i>
            <h3>Unauthorized Access</h3>
            <p>{error}</p>
            <p style={{ fontSize: '14px', color: 'var(--text-secondary)' }}>
              Only the <strong>Buyer</strong> can make payments for this milestone.
            </p>
            <button 
              className="back-btn" 
              onClick={() => navigate(`/deal-manager?dealId=${dealId}`)}
              style={{ marginTop: '20px' }}
            >
              <i className="fa-solid fa-arrow-left"></i> Back to Deal
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ============================================================
  // ✅ রেন্ডার
  // ============================================================
  return (
    <div className="payment-container">
      <div className="payment-card">
        
        {/* হেডার */}
        <div className="payment-header">
          <button className="back-btn" onClick={() => navigate(-1)}>
            <i className="fa-solid fa-arrow-left"></i> Back
          </button>
          <h2><i className="fa-solid fa-credit-card"></i> Make Payment</h2>
          {isBuyer ? (
            <span className="role-badge buyer">👑 Buyer</span>
          ) : (
            <span className="role-badge seller">🛠️ Seller</span>
          )}
        </div>

        {/* Error মেসেজ */}
        {error && (
          <div className="payment-error">
            <i className="fa-solid fa-exclamation-circle"></i>
            {error}
            <button onClick={() => setError('')} className="error-close">
              <i className="fa-solid fa-times"></i>
            </button>
          </div>
        )}

        {/* পেমেন্ট স্টেপ ইন্ডিকেটর */}
        <div className="payment-steps">
          <div className={`step ${paymentStep >= 1 ? 'active' : ''}`}>
            <div className="step-number">1</div>
            <div className="step-label">Details</div>
          </div>
          <div className={`step-line ${paymentStep >= 2 ? 'active' : ''}`}></div>
          <div className={`step ${paymentStep >= 2 ? 'active' : ''}`}>
            <div className="step-number">2</div>
            <div className="step-label">Payment</div>
          </div>
          <div className={`step-line ${paymentStep >= 3 ? 'active' : ''}`}></div>
          <div className={`step ${paymentStep >= 3 ? 'active' : ''}`}>
            <div className="step-number">3</div>
            <div className="step-label">Complete</div>
          </div>
        </div>

        {/* পেমেন্ট ডিটেইলস */}
        <div className="payment-details">
          <h3>Payment Details</h3>
          <div className="detail-row">
            <span>Project:</span>
            <strong>{dealData?.postTitle || 'N/A'}</strong>
          </div>
          <div className="detail-row">
            <span>Milestone:</span>
            <strong>{milestone?.title || 'N/A'}</strong>
          </div>
          <div className="detail-row highlight">
            <span>Amount:</span>
            <strong>{formatMoney(milestone?.amount)}</strong>
          </div>
          <div className="detail-row">
            <span>Payer:</span>
            <strong>{isBuyer ? 'You (Buyer)' : 'Buyer'}</strong>
          </div>
          <div className="detail-row">
            <span>Receiver:</span>
            <strong>{dealData?.sellerName || 'Seller'}</strong>
          </div>
        </div>

        {/* স্টেপ 1: পেমেন্ট অপশন - শুধুমাত্র Buyer দেখতে পারে */}
        {paymentStep === 1 && isBuyer && (
          <div className="payment-options">
            <button 
              className="pay-option-btn bkash"
              onClick={handleBkashPayment}
              disabled={processing}
            >
              <i className="fa-brands fa-btc"></i>
              <span>Pay with bKash</span>
            </button>
            
            <button 
              className="pay-option-btn nagad"
              onClick={() => alert('Nagad payment coming soon!')}
              disabled={processing}
            >
              <i className="fa-solid fa-n"></i>
              <span>Pay with Nagad</span>
            </button>
            
            <button 
              className="pay-option-btn rocket"
              onClick={() => alert('Rocket payment coming soon!')}
              disabled={processing}
            >
              <i className="fa-solid fa-rocket"></i>
              <span>Pay with Rocket</span>
            </button>
            
            <div className="secure-note">
              <i className="fa-solid fa-shield-heart"></i>
              <p>Your payment is secured by SSL encryption</p>
            </div>
          </div>
        )}

        {/* স্টেপ 1: যদি Buyer না হয় */}
        {paymentStep === 1 && !isBuyer && (
          <div className="payment-not-authorized">
            <i className="fa-solid fa-info-circle"></i>
            <p>You are the <strong>Seller</strong>. Only the <strong>Buyer</strong> can make payments.</p>
            <p style={{ fontSize: '13px', color: 'var(--text-muted)' }}>
              Please wait for the Buyer to complete the payment.
            </p>
          </div>
        )}

        {/* স্টেপ 2: প্রসেসিং */}
        {paymentStep === 2 && (
          <div className="processing-section">
            <div className="spinner"></div>
            <h3>Processing Payment</h3>
            <p>Please wait while we process your payment...</p>
            <small>Do not close this window</small>
          </div>
        )}

        {/* স্টেপ 3: কনফার্মেশন */}
        {paymentStep === 3 && (
          <div className="confirmation-section">
            <i className="fa-solid fa-circle-check success-icon"></i>
            <h3>Payment Successful!</h3>
            <p>Your payment has been processed successfully.</p>
            
            <div className="transaction-details">
              <div className="tx-row">
                <span>Transaction ID:</span>
                <strong className="tx-id">{transactionId}</strong>
              </div>
              <div className="tx-row">
                <span>Amount:</span>
                <strong>{formatMoney(milestone?.amount)}</strong>
              </div>
              <div className="tx-row">
                <span>Status:</span>
                <span className="status-success">
                  <i className="fa-solid fa-check-circle"></i> Completed
                </span>
              </div>
            </div>

            <div className="action-buttons">
              <button className="view-deal-btn" onClick={() => navigate(`/deal-manager?dealId=${dealId}`)}>
                <i className="fa-solid fa-briefcase"></i> View Deal
              </button>
              <button className="go-home-btn" onClick={() => navigate('/')}>
                <i className="fa-solid fa-home"></i> Go Home
              </button>
            </div>
          </div>
        )}

      </div>

      {/* bKash পেমেন্ট মোডাল */}
      {showBkashModal && (
        <BKashPayment 
          amount={milestone?.amount}
          orderId={`${dealId}_${milestoneId}`}
          reference={`PAY_${dealId}_${milestoneId}`}
          onSuccess={handleBkashSuccess}
          onError={(error) => {
            console.error("BKash error:", error);
            setError(error || 'Payment failed');
            setPaymentStep(1);
            setShowBkashModal(false);
          }}
          onClose={() => {
            setShowBkashModal(false);
            setPaymentStep(1);
            setError('Payment was cancelled');
          }}
        />
      )}
    </div>
  );
};

export default PaymentGateway;