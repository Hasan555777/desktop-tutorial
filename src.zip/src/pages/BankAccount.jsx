import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth, db } from '../firebase';
import { 
  doc, getDoc, setDoc, updateDoc, 
  collection, query, where, getDocs, 
  deleteDoc, arrayUnion, arrayRemove 
} from 'firebase/firestore';
import './BankAccount.css';

const BankAccount = () => {
  const navigate = useNavigate();
  const user = auth.currentUser;
  
  const [loading, setLoading] = useState(true);
  const [accounts, setAccounts] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [bankName, setBankName] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [accountHolder, setAccountHolder] = useState('');
  const [isDefault, setIsDefault] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // ============================================================
  // ✅ ব্যাংক অ্যাকাউন্ট লোড করা
  // ============================================================
  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    const loadAccounts = async () => {
      try {
        const userRef = doc(db, 'users', user.uid);
        const userSnap = await getDoc(userRef);
        
        if (userSnap.exists()) {
          const data = userSnap.data();
          setAccounts(data.bankAccounts || []);
        }
      } catch (error) {
        console.error("Error loading bank accounts:", error);
      } finally {
        setLoading(false);
      }
    };

    loadAccounts();
  }, [user, navigate]);

  // ============================================================
  // ✅ নতুন অ্যাকাউন্ট যোগ করা
  // ============================================================
  const addAccount = async () => {
    // ভ্যালিডেশন
    if (!bankName.trim()) {
      alert('Please enter bank name!');
      return;
    }

    if (!accountNumber.trim()) {
      alert('Please enter account number!');
      return;
    }

    if (!accountHolder.trim()) {
      alert('Please enter account holder name!');
      return;
    }

    // ডুপ্লিকেট চেক
    const existing = accounts.find(acc => acc.accountNumber === accountNumber.trim());
    if (existing) {
      alert('This account number already exists!');
      return;
    }

    setIsSubmitting(true);

    try {
      const userRef = doc(db, 'users', user.uid);
      
      const newAccount = {
        id: Date.now().toString(),
        bankName: bankName.trim(),
        accountNumber: accountNumber.trim(),
        accountHolder: accountHolder.trim(),
        isDefault: isDefault,
        createdAt: new Date().toISOString()
      };

      // যদি ডিফল্ট সেট করা হয়, অন্য সব ডিফল্ট আনসেট করুন
      let updatedAccounts = [...accounts, newAccount];
      if (isDefault) {
        updatedAccounts = updatedAccounts.map(acc => ({
          ...acc,
          isDefault: false
        }));
        updatedAccounts[updatedAccounts.length - 1].isDefault = true;
      }

      await updateDoc(userRef, {
        bankAccounts: updatedAccounts,
        updatedAt: new Date().toISOString()
      });

      setAccounts(updatedAccounts);
      resetForm();
      alert('✅ Bank account added successfully!');
      
    } catch (error) {
      console.error("Error adding account:", error);
      alert('Failed to add bank account. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // ============================================================
  // ✅ অ্যাকাউন্ট ডিলিট করা
  // ============================================================
  const deleteAccount = async (id) => {
    if (!window.confirm('Are you sure you want to remove this bank account?')) {
      return;
    }

    try {
      const userRef = doc(db, 'users', user.uid);
      const updatedAccounts = accounts.filter(acc => acc.id !== id);
      
      await updateDoc(userRef, {
        bankAccounts: updatedAccounts,
        updatedAt: new Date().toISOString()
      });

      setAccounts(updatedAccounts);
      alert('✅ Bank account removed successfully!');
      
    } catch (error) {
      console.error("Error deleting account:", error);
      alert('Failed to delete bank account.');
    }
  };

  // ============================================================
  // ✅ ডিফল্ট অ্যাকাউন্ট সেট করা
  // ============================================================
  const setDefaultAccount = async (id) => {
    try {
      const userRef = doc(db, 'users', user.uid);
      const updatedAccounts = accounts.map(acc => ({
        ...acc,
        isDefault: acc.id === id
      }));

      await updateDoc(userRef, {
        bankAccounts: updatedAccounts,
        updatedAt: new Date().toISOString()
      });

      setAccounts(updatedAccounts);
      
    } catch (error) {
      console.error("Error setting default:", error);
      alert('Failed to set default account.');
    }
  };

  // ============================================================
  // ✅ ফর্ম রিসেট
  // ============================================================
  const resetForm = () => {
    setBankName('');
    setAccountNumber('');
    setAccountHolder('');
    setIsDefault(false);
    setShowForm(false);
    setEditingId(null);
  };

  // ============================================================
  // ✅ মাস্ক অ্যাকাউন্ট নম্বর
  // ============================================================
  const maskAccountNumber = (number) => {
    if (number.length <= 4) return number;
    const visible = number.slice(-4);
    const masked = '*'.repeat(number.length - 4);
    return masked + visible;
  };

  if (loading) {
    return (
      <div className="bankaccount-container">
        <div className="bankaccount-card">
          <div className="loading-state">
            <div className="loading-spinner"></div>
            <p>Loading accounts...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bankaccount-container">
      <div className="bankaccount-card">
        
        {/* হেডার */}
        <div className="bankaccount-header">
          <button className="back-btn" onClick={() => navigate(-1)}>
            <i className="fa-solid fa-arrow-left"></i> Back
          </button>
          <h2>
            <i className="fa-solid fa-building-columns"></i> Bank Accounts
          </h2>
          {!showForm && (
            <button className="add-btn" onClick={() => setShowForm(true)}>
              <i className="fa-solid fa-plus"></i> Add Account
            </button>
          )}
        </div>

        {/* অ্যাকাউন্ট লিস্ট */}
        {accounts.length === 0 && !showForm ? (
          <div className="no-account">
            <i className="fa-solid fa-credit-card"></i>
            <h3>No Bank Accounts</h3>
            <p>Add your bank account to receive payments</p>
            <button className="add-account-btn" onClick={() => setShowForm(true)}>
              <i className="fa-solid fa-plus-circle"></i> Add Bank Account
            </button>
          </div>
        ) : (
          <div className="accounts-list">
            {accounts.map((acc) => (
              <div key={acc.id} className={`account-item ${acc.isDefault ? 'default' : ''}`}>
                <div className="account-icon">
                  <i className="fa-solid fa-building-columns"></i>
                  {acc.isDefault && <span className="default-badge">Default</span>}
                </div>
                <div className="account-details">
                  <h4>{acc.bankName}</h4>
                  <p className="account-number">{maskAccountNumber(acc.accountNumber)}</p>
                  <p className="account-holder">{acc.accountHolder}</p>
                  <p className="account-added">
                    <i className="fa-regular fa-calendar"></i> 
                    Added {new Date(acc.createdAt).toLocaleDateString()}
                  </p>
                </div>
                <div className="account-actions">
                  {!acc.isDefault && (
                    <button 
                      className="set-default-btn"
                      onClick={() => setDefaultAccount(acc.id)}
                      title="Set as default"
                    >
                      <i className="fa-regular fa-star"></i>
                    </button>
                  )}
                  <button 
                    className="delete-btn"
                    onClick={() => deleteAccount(acc.id)}
                    title="Remove account"
                  >
                    <i className="fa-solid fa-trash"></i>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ফর্ম */}
        {showForm && (
          <div className="add-account-form">
            <div className="form-header">
              <h3>
                <i className="fa-solid fa-plus-circle"></i> 
                {editingId ? 'Edit Account' : 'Add New Account'}
              </h3>
              <button className="close-form-btn" onClick={resetForm}>
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>

            <div className="form-group">
              <label>Bank Name</label>
              <input 
                type="text" 
                placeholder="e.g., Dutch-Bangla Bank"
                value={bankName}
                onChange={(e) => setBankName(e.target.value)}
              />
            </div>

            <div className="form-group">
              <label>Account Number</label>
              <input 
                type="text" 
                placeholder="Enter account number"
                value={accountNumber}
                onChange={(e) => setAccountNumber(e.target.value.replace(/\s/g, ''))}
              />
            </div>

            <div className="form-group">
              <label>Account Holder Name</label>
              <input 
                type="text" 
                placeholder="Full name as per bank account"
                value={accountHolder}
                onChange={(e) => setAccountHolder(e.target.value)}
              />
            </div>

            <div className="form-group checkbox">
              <label className="checkbox-label">
                <input 
                  type="checkbox"
                  checked={isDefault}
                  onChange={(e) => setIsDefault(e.target.checked)}
                />
                <span>Set as default account</span>
              </label>
            </div>

            <div className="form-actions">
              <button className="cancel-btn" onClick={resetForm}>
                Cancel
              </button>
              <button 
                className="save-btn" 
                onClick={addAccount}
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <>
                    <i className="fa-solid fa-spinner fa-spin"></i> Saving...
                  </>
                ) : (
                  <>
                    <i className="fa-solid fa-check"></i> Save Account
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* ফুটার */}
        <div className="bankaccount-footer">
          <p>
            <i className="fa-solid fa-shield-check"></i> 
            Your bank account information is encrypted and secure
          </p>
        </div>

      </div>
    </div>
  );
};

export default BankAccount;