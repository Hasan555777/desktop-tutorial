// src/pages/QRCode.jsx
import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth, db } from '../firebase';
import { doc, addDoc, collection, serverTimestamp } from 'firebase/firestore';
import './QRCode.css';

const QRCode = () => {
  const navigate = useNavigate();
  const user = auth.currentUser;
  const [amount, setAmount] = useState('');
  const [qrCode, setQrCode] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [transactionId, setTransactionId] = useState(null);
  const [copySuccess, setCopySuccess] = useState(false);
  const qrRef = useRef(null);

  // ============================================================
  // ✅ প্রি-সেট অ্যামাউন্ট
  // ============================================================
  const presetAmounts = [100, 200, 500, 1000, 2000];

  // ============================================================
  // ✅ QR কোড জেনারেট
  // ============================================================
  const generateQR = async () => {
    setError('');
    
    if (!user) {
      setError('Please login first!');
      navigate('/login');
      return;
    }

    if (!amount || Number(amount) < 10) {
      setError('Please enter a valid amount (minimum 10 BDT)');
      return;
    }

    if (Number(amount) > 50000) {
      setError('Maximum amount is 50,000 BDT');
      return;
    }

    setLoading(true);

    try {
      // ১. ট্রানজেকশন আইডি তৈরি
      const txnId = `QR_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
      setTransactionId(txnId);

      // ২. ট্রানজেকশন ডেটা তৈরি
      const transactionData = {
        userId: user.uid,
        userEmail: user.email,
        userName: user.displayName || 'User',
        amount: Number(amount),
        type: 'deposit',
        status: 'pending',
        method: 'QR Code',
        trxId: txnId,
        source: 'qr_generate',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };

      // ৩. Firebase এ সেভ
      await addDoc(collection(db, 'transactions'), transactionData);
      console.log('✅ Transaction saved:', txnId);

      // ৪. QR কোড URL তৈরি
      const qrData = JSON.stringify({
        txnId: txnId,
        amount: Number(amount),
        userId: user.uid,
        timestamp: Date.now()
      });

      const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(qrData)}&bgcolor=ffffff&color=0f1420&margin=10`;
      setQrCode(qrUrl);

    } catch (error) {
      console.error("Error generating QR:", error);
      setError('Failed to generate QR code. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // ============================================================
  // ✅ QR কোড ডাউনলোড
  // ============================================================
  const downloadQR = () => {
    if (!qrCode) return;
    const link = document.createElement('a');
    link.download = `qr-payment-${amount}-${Date.now()}.png`;
    link.href = qrCode;
    link.click();
  };

  // ============================================================
  // ✅ QR কোড কপি
  // ============================================================
  const copyToClipboard = async () => {
    if (!qrCode) return;
    try {
      await navigator.clipboard.writeText(qrCode);
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  // ============================================================
  // ✅ ফর্ম রিসেট
  // ============================================================
  const resetForm = () => {
    setAmount('');
    setQrCode(null);
    setTransactionId(null);
    setError('');
  };

  // ============================================================
  // ✅ রেন্ডার
  // ============================================================
  return (
    <div className="qrcode-container">
      <div className="qrcode-card">
        
        {/* হেডার */}
        <div className="qrcode-header">
          <button className="back-btn" onClick={() => navigate(-1)}>
            <i className="fa-solid fa-arrow-left"></i> Back
          </button>
          <h2>
            <i className="fa-solid fa-qrcode" style={{ color: '#fbbf24' }}></i> 
            QR Code Payment
          </h2>
        </div>

        <p className="qrcode-subtitle">
          Generate a QR code for easy payment
        </p>

        {/* Error Message */}
        {error && (
          <div className="qrcode-error">
            <i className="fa-solid fa-exclamation-circle"></i>
            {error}
          </div>
        )}

        {/* প্রি-সেট অ্যামাউন্ট */}
        <div className="qrcode-presets">
          <label>Quick Amount</label>
          <div className="preset-buttons">
            {presetAmounts.map((preset) => (
              <button
                key={preset}
                className={`preset-btn ${Number(amount) === preset ? 'active' : ''}`}
                onClick={() => setAmount(String(preset))}
              >
                ৳{preset}
              </button>
            ))}
          </div>
        </div>

        {/* অ্যামাউন্ট ইনপুট */}
        <div className="qrcode-input-group">
          <label>
            <i className="fa-solid fa-wallet"></i> Amount (BDT)
          </label>
          <div className="input-with-icon">
            <span className="input-icon">৳</span>
            <input 
              type="number" 
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Enter amount (min: 10 BDT)"
              min="10"
              max="50000"
              disabled={loading}
            />
          </div>
          <small className="input-hint">Minimum 10 BDT • Maximum 50,000 BDT</small>
        </div>

        {/* অ্যাকশন বাটন */}
        <div className="qrcode-actions">
          {!qrCode ? (
            <button 
              className="generate-btn" 
              onClick={generateQR}
              disabled={loading}
            >
              {loading ? (
                <>
                  <i className="fa-solid fa-spinner fa-spin"></i> Generating...
                </>
              ) : (
                <>
                  <i className="fa-solid fa-qrcode"></i> Generate QR Code
                </>
              )}
            </button>
          ) : (
            <div className="qrcode-buttons">
              <button className="qr-btn-regenerate" onClick={resetForm}>
                <i className="fa-solid fa-rotate-left"></i> New
              </button>
              <button className="qr-btn-download" onClick={downloadQR}>
                <i className="fa-solid fa-download"></i> Download
              </button>
              <button className="qr-btn-copy" onClick={copyToClipboard}>
                <i className="fa-solid fa-copy"></i> {copySuccess ? 'Copied!' : 'Copy'}
              </button>
            </div>
          )}
        </div>

        {/* QR কোড ডিসপ্লে */}
        {qrCode && (
          <div className="qr-display">
            <div className="qr-image-wrapper" ref={qrRef}>
              <img 
                src={qrCode} 
                alt="QR Code for payment" 
                className="qr-image"
                onError={(e) => {
                  e.target.src = 'https://via.placeholder.com/250x250?text=QR+Error';
                }}
              />
              <div className="qr-overlay">
                <span>Scan to Pay</span>
              </div>
            </div>
            
            <div className="qr-details">
              <p className="qr-amount">
                <i className="fa-solid fa-money-bill-wave"></i> 
                ৳ {Number(amount).toLocaleString()}
              </p>
              {transactionId && (
                <p className="qr-txn-id">
                  <i className="fa-solid fa-receipt"></i> 
                  Txn ID: {transactionId}
                </p>
              )}
              <p className="qr-hint">
                <i className="fa-solid fa-info-circle"></i> 
                Scan this QR code with any payment app
              </p>
            </div>
          </div>
        )}

        {/* ফুটার */}
        <div className="qrcode-footer">
          <p>
            <i className="fa-solid fa-shield-check"></i> 
            Secure and encrypted payment
          </p>
        </div>

      </div>
    </div>
  );
};

export default QRCode;