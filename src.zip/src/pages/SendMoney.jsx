// src/pages/SendMoney.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth, db } from '../firebase';
import { 
  doc, 
  getDoc, 
  updateDoc, 
  runTransaction, 
  collection, 
  addDoc, 
  serverTimestamp,
  query,
  where,
  getDocs
} from 'firebase/firestore';
import './SendMoney.css';

const SendMoney = () => {
  const navigate = useNavigate();
  const user = auth.currentUser;
  
  const [amount, setAmount] = useState('');
  const [receiverId, setReceiverId] = useState('');
  const [receiverName, setReceiverName] = useState('');
  const [note, setNote] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [balance, setBalance] = useState(0);
  const [walletLoading, setWalletLoading] = useState(true);

  // ============================================================
  // ✅ ইউজারের ব্যালেন্স লোড
  // ============================================================
  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    const loadBalance = async () => {
      try {
        const walletRef = doc(db, 'wallets', user.uid);
        const walletSnap = await getDoc(walletRef);
        
        if (walletSnap.exists()) {
          setBalance(walletSnap.data().balance || 0);
        }
      } catch (error) {
        console.error("Error loading balance:", error);
      } finally {
        setWalletLoading(false);
      }
    };

    loadBalance();
  }, [user, navigate]);

  // ============================================================
  // ✅ রিসিভার খুঁজুন
  // ============================================================
  const findReceiver = async () => {
    if (!receiverId.trim()) {
      setError('Please enter receiver ID or phone number');
      return;
    }

    setLoading(true);
    setError('');

    try {
      // ১. ইউজার আইডি দিয়ে খোঁজা
      let foundUser = null;
      
      // ইউজার আইডি দিয়ে
      const userRef = doc(db, 'users', receiverId.trim());
      const userSnap = await getDoc(userRef);
      
      if (userSnap.exists()) {
        foundUser = { id: userSnap.id, ...userSnap.data() };
      } else {
        // ফোন নম্বর দিয়ে খোঁজা
        const q = query(
          collection(db, 'users'),
          where('phone', '==', receiverId.trim())
        );
        const querySnap = await getDocs(q);
        
        if (!querySnap.empty) {
          foundUser = { id: querySnap.docs[0].id, ...querySnap.docs[0].data() };
        }
      }

      if (foundUser) {
        if (foundUser.id === user.uid) {
          setError('You cannot send money to yourself!');
          return;
        }
        setReceiverName(foundUser.displayName || foundUser.email || 'User');
        setError('');
        alert(`✅ User found: ${foundUser.displayName || foundUser.email}`);
      } else {
        setError('User not found! Please check the ID or phone number.');
        setReceiverName('');
      }
    } catch (error) {
      console.error("Error finding receiver:", error);
      setError('Failed to find user. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // ============================================================
  // ✅ টাকা পাঠান (Firestore Transaction)
  // ============================================================
  const handleSend = async () => {
    // ভ্যালিডেশন
    if (!receiverId.trim()) {
      setError('Please enter receiver ID or phone number');
      return;
    }

    if (!receiverName) {
      setError('Please find receiver first by clicking the search button');
      return;
    }

    if (!amount || Number(amount) <= 0) {
      setError('Please enter a valid amount');
      return;
    }

    if (Number(amount) < 10) {
      setError('Minimum amount is 10 BDT');
      return;
    }

    if (Number(amount) > balance) {
      setError(`Insufficient balance! Available: ৳${balance.toFixed(2)}`);
      return;
    }

    if (!window.confirm(`Are you sure you want to send ৳${amount} to ${receiverName}?`)) {
      return;
    }

    setLoading(true);
    setError('');

    try {
      const senderWalletRef = doc(db, 'wallets', user.uid);
      const receiverWalletRef = doc(db, 'wallets', receiverId);
      const amountNum = Number(amount);

      // 🔥 Firestore Transaction - Atomic অপারেশন
      await runTransaction(db, async (transaction) => {
        // ১. সেন্ডারের ওয়ালেট চেক
        const senderDoc = await transaction.get(senderWalletRef);
        if (!senderDoc.exists()) {
          throw new Error('Sender wallet not found!');
        }

        const senderBalance = senderDoc.data().balance || 0;
        if (senderBalance < amountNum) {
          throw new Error('Insufficient balance!');
        }

        // ২. রিসিভারের ওয়ালেট চেক
        const receiverDoc = await transaction.get(receiverWalletRef);
        let receiverBalance = 0;
        if (receiverDoc.exists()) {
          receiverBalance = receiverDoc.data().balance || 0;
        }

        // ৩. সেন্ডারের ব্যালেন্স কমান
        transaction.update(senderWalletRef, {
          balance: senderBalance - amountNum,
          updatedAt: serverTimestamp()
        });

        // ৪. রিসিভারের ব্যালেন্স বাড়ান
        if (receiverDoc.exists()) {
          transaction.update(receiverWalletRef, {
            balance: receiverBalance + amountNum,
            updatedAt: serverTimestamp()
          });
        } else {
          // রিসিভারের ওয়ালেট না থাকলে তৈরি করুন
          transaction.set(receiverWalletRef, {
            balance: amountNum,
            totalEarned: amountNum,
            totalWithdrawn: 0,
            pendingWithdraw: 0,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp()
          });
        }

        // ৫. ট্রানজেকশন রেকর্ড (সেন্ডার)
        const senderTxRef = doc(collection(db, 'transactions'));
        transaction.set(senderTxRef, {
          userId: user.uid,
          userName: user.displayName || 'User',
          amount: amountNum,
          type: 'debit',
          status: 'completed',
          title: 'Money Sent',
          description: `Sent to ${receiverName}`,
          receiverId: receiverId,
          receiverName: receiverName,
          note: note.trim() || '',
          createdAt: serverTimestamp(),
          completedAt: serverTimestamp()
        });

        // ৬. ট্রানজেকশন রেকর্ড (রিসিভার)
        const receiverTxRef = doc(collection(db, 'transactions'));
        transaction.set(receiverTxRef, {
          userId: receiverId,
          userName: receiverName,
          amount: amountNum,
          type: 'credit',
          status: 'completed',
          title: 'Money Received',
          description: `Received from ${user.displayName || 'User'}`,
          senderId: user.uid,
          senderName: user.displayName || 'User',
          note: note.trim() || '',
          createdAt: serverTimestamp(),
          completedAt: serverTimestamp()
        });
      });

      // ✅ সফল হলে UI আপডেট
      setBalance(prev => prev - amountNum);
      alert(`✅ ৳${amount} sent successfully to ${receiverName}!`);
      
      // ফর্ম রিসেট
      setAmount('');
      setReceiverId('');
      setReceiverName('');
      setNote('');
      
      // ওয়ালেট পেজে রিডাইরেক্ট
      setTimeout(() => navigate('/wallet'), 1500);

    } catch (error) {
      console.error("❌ Transaction error:", error);
      setError(error.message || 'Failed to send money. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // ============================================================
  // ✅ ফরম্যাট টাকা
  // ============================================================
  const formatMoney = (amount) => {
    return new Intl.NumberFormat('bn-BD', {
      style: 'currency',
      currency: 'BDT',
      minimumFractionDigits: 0
    }).format(amount || 0);
  };

  // ============================================================
  // ✅ লোডিং স্টেট
  // ============================================================
  if (walletLoading) {
    return (
      <div className="sendmoney-loading">
        <div className="loading-spinner"></div>
        <p>Loading wallet...</p>
      </div>
    );
  }

  // ============================================================
  // ✅ রেন্ডার
  // ============================================================
  return (
    <div className="sendmoney-container">
      <div className="sendmoney-card">
        
        {/* হেডার */}
        <div className="sendmoney-header">
          <button className="back-btn" onClick={() => navigate(-1)}>
            <i className="fa-solid fa-arrow-left"></i> Back
          </button>
          <h2>
            <i className="fa-solid fa-paper-plane" style={{ color: '#3b82f6' }}></i> 
            Send Money
          </h2>
        </div>

        {/* ব্যালেন্স ডিসপ্লে */}
        <div className="balance-display">
          <span className="balance-label">Available Balance</span>
          <span className="balance-amount">{formatMoney(balance)}</span>
        </div>

        {/* Error মেসেজ */}
        {error && (
          <div className="sendmoney-error">
            <i className="fa-solid fa-exclamation-circle"></i>
            {error}
          </div>
        )}

        {/* রিসিভার */}
        <div className="input-group">
          <label>Receiver ID or Phone Number</label>
          <div className="receiver-input-group">
            <input 
              type="text" 
              value={receiverId}
              onChange={(e) => setReceiverId(e.target.value)}
              placeholder="e.g., WH-1001 or 017XXXXXXXX"
              disabled={loading}
            />
            <button 
              className="find-btn"
              onClick={findReceiver}
              disabled={loading || !receiverId.trim()}
            >
              {loading ? (
                <i className="fa-solid fa-spinner fa-spin"></i>
              ) : (
                <i className="fa-solid fa-search"></i>
              )}
            </button>
          </div>
          {receiverName && (
            <div className="receiver-found">
              <i className="fa-solid fa-check-circle" style={{ color: '#10b981' }}></i>
              Sending to: <strong>{receiverName}</strong>
            </div>
          )}
        </div>

        {/* অ্যামাউন্ট */}
        <div className="input-group">
          <label>Amount (BDT)</label>
          <div className="amount-input-group">
            <span className="currency-icon">৳</span>
            <input 
              type="number" 
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Enter amount"
              min="10"
              max={balance}
              disabled={loading || !receiverName}
            />
          </div>
          <div className="amount-hint">
            <span>Min: ৳10</span>
            <span>Max: {formatMoney(balance)}</span>
          </div>
        </div>

        {/* প্রি-সেট অ্যামাউন্ট */}
        <div className="preset-amounts">
          {[100, 500, 1000, 2000].map((preset) => (
            <button
              key={preset}
              className={`preset-btn ${Number(amount) === preset ? 'active' : ''}`}
              onClick={() => setAmount(String(preset))}
              disabled={loading || !receiverName || preset > balance}
            >
              ৳{preset}
            </button>
          ))}
        </div>

        {/* নোট */}
        <div className="input-group">
          <label>Note (Optional)</label>
          <textarea 
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Add a note for the receiver..."
            rows="2"
            maxLength="100"
            disabled={loading}
          />
          <span className="char-count">{note.length}/100</span>
        </div>

        {/* সামারি */}
        {receiverName && amount && (
          <div className="send-summary">
            <div className="summary-row">
              <span>Amount:</span>
              <strong>{formatMoney(Number(amount) || 0)}</strong>
            </div>
            <div className="summary-row">
              <span>Fee:</span>
              <strong style={{ color: '#10b981' }}>Free</strong>
            </div>
            <div className="summary-row total">
              <span>Total:</span>
              <strong>{formatMoney(Number(amount) || 0)}</strong>
            </div>
          </div>
        )}

        {/* সেন্ড বাটন */}
        <button 
          className="send-btn" 
          onClick={handleSend}
          disabled={loading || !receiverName || !amount || Number(amount) > balance || Number(amount) < 10}
        >
          {loading ? (
            <>
              <i className="fa-solid fa-spinner fa-spin"></i> Sending...
            </>
          ) : (
            <>
              <i className="fa-solid fa-paper-plane"></i> Send Money
            </>
          )}
        </button>

        {/* ফুটার */}
        <div className="sendmoney-footer">
          <p>
            <i className="fa-solid fa-shield-check"></i> 
            Your transaction is secure and encrypted
          </p>
        </div>

      </div>
    </div>
  );
};

export default SendMoney;