import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './WalletActions.css';

const WalletActions = ({ walletBalance, onRefresh }) => {
  const navigate = useNavigate();
  const [showMenu, setShowMenu] = useState(false);

  const actions = [
    {
      id: 'deposit',
      name: 'Deposit Money',
      icon: 'fa-solid fa-circle-dollar',
      color: '#10b981',
      bg: 'rgba(16, 185, 129, 0.1)',
      path: '/deposit',
      description: 'Add money to your wallet'
    },
    {
      id: 'withdraw',
      name: 'Withdraw',
      icon: 'fa-solid fa-money-bill-wave',
      color: '#f59e0b',
      bg: 'rgba(245, 158, 11, 0.1)',
      path: '/withdraw',
      description: 'Withdraw funds to your account'
    },
    {
      id: 'transactions',
      name: 'Transactions',
      icon: 'fa-solid fa-clock-rotate-left',
      color: '#38bdf8',
      bg: 'rgba(56, 189, 248, 0.1)',
      path: '/transactions',
      description: 'View all transactions'
    },
    {
      id: 'qr-code',
      name: 'QR Code',
      icon: 'fa-solid fa-qrcode',
      color: '#a855f7',
      bg: 'rgba(168, 85, 247, 0.1)',
      path: '/qr-code',
      description: 'Scan to pay'
    },
    {
      id: 'send-money',
      name: 'Send Money',
      icon: 'fa-solid fa-paper-plane',
      color: '#ec4899',
      bg: 'rgba(236, 72, 153, 0.1)',
      path: '/send-money',
      description: 'Send money to others'
    },
    {
      id: 'bank-account',
      name: 'Bank Account',
      icon: 'fa-solid fa-building-columns',
      color: '#14b8a6',
      bg: 'rgba(20, 184, 166, 0.1)',
      path: '/bank-account',
      description: 'Manage bank accounts'
    },
    {
      id: 'payment-history',
      name: 'Payment History',
      icon: 'fa-solid fa-receipt',
      color: '#f43f5e',
      bg: 'rgba(244, 63, 94, 0.1)',
      path: '/payment-history',
      description: 'View payment history'
    },
    {
      id: 'referral',
      name: 'Referral',
      icon: 'fa-solid fa-user-plus',
      color: '#06b6d4',
      bg: 'rgba(6, 182, 212, 0.1)',
      path: '/referral',
      description: 'Invite friends & earn'
    }
  ];

  const handleAction = (action) => {
    setShowMenu(false);
    navigate(action.path);
  };

  return (
    <div className="wallet-actions-module">
      {/* হেডার */}
      <div className="actions-header">
        <div className="balance-info">
          <span className="balance-label">Available Balance</span>
          <div className="balance-value">
            <i className="fa-solid fa-wallet"></i>
            <span>৳ {walletBalance?.toLocaleString() || 0}</span>
          </div>
        </div>
        <button className="refresh-btn" onClick={onRefresh}>
          <i className="fa-solid fa-rotate-right"></i>
        </button>
      </div>

      {/* অ্যাকশন গ্রিড */}
      <div className="actions-grid">
        {actions.map((action) => (
          <div 
            key={action.id}
            className="action-card"
            onClick={() => handleAction(action)}
            style={{ '--action-color': action.color, '--action-bg': action.bg }}
          >
            <div className="action-icon" style={{ background: action.bg, color: action.color }}>
              <i className={action.icon}></i>
            </div>
            <div className="action-info">
              <h4>{action.name}</h4>
              <p>{action.description}</p>
            </div>
            <div className="action-arrow">
              <i className="fa-solid fa-chevron-right"></i>
            </div>
          </div>
        ))}
      </div>

      {/* দ্রুত অ্যাকশন বাটন */}
      <div className="quick-actions">
        <button className="quick-btn deposit" onClick={() => navigate('/deposit')}>
          <i className="fa-solid fa-plus-circle"></i> Deposit
        </button>
        <button className="quick-btn withdraw" onClick={() => navigate('/withdraw')}>
          <i className="fa-solid fa-money-bill-wave"></i> Withdraw
        </button>
        <button className="quick-btn send" onClick={() => navigate('/send-money')}>
          <i className="fa-solid fa-paper-plane"></i> Send
        </button>
        <button className="quick-btn history" onClick={() => navigate('/transactions')}>
          <i className="fa-solid fa-clock-rotate-left"></i> History
        </button>
      </div>
    </div>
  );
};

export default WalletActions;