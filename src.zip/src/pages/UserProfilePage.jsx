
import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  doc, 
  getDoc, 
  setDoc, 
  collection, 
  query, 
  where, 
  getDocs, 
  onSnapshot, 
  orderBy, 
  addDoc, 
  serverTimestamp 
} from 'firebase/firestore';
import { db, auth } from "../firebase";
import './UserProfilePage.css';
// ✅ UserStatus ইম্পোর্ট রাখা হয়েছে (যদিও ইউজ হয়নি, ভবিষ্যতে কাজে লাগতে পারে)

// ============================================================
// 📌 রিভিউ মোডাল কম্পোনেন্ট
// ============================================================
const ReviewModal = ({ userId, userName, userPhoto, onClose, onReviewSubmitted, hasReviewed: propHasReviewed }) => {
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [reviewText, setReviewText] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [hasReviewed, setHasReviewed] = useState(propHasReviewed);
  
  const handleSubmit = async () => {
    if (!auth.currentUser) {
      setError('Please login to submit a review!');
      return;
    }

    if (rating === 0) {
      setError('Please select a rating!');
      return;
    }

    if (reviewText.trim().length < 10) {
      setError('Please write at least 10 characters!');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const reviewData = {
        reviewerId: auth.currentUser.uid,
        reviewerName: auth.currentUser.displayName || 'Anonymous',
        reviewerPhoto: auth.currentUser.photoURL || '',
        userId: userId,
        rating: rating,
        text: reviewText.trim(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      await addDoc(collection(db, 'reviews'), reviewData);
      alert('✅ Review submitted successfully!');
      
      if (onReviewSubmitted) {
        onReviewSubmitted();
      }
      onClose();
    } catch (error) {
      console.error('Error submitting review:', error);
      setError('Failed to submit review. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const renderStars = () => {
    const stars = [];
    const currentRating = hoverRating || rating;
    
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <span
          key={i}
          className={`star ${i <= currentRating ? 'filled' : ''}`}
          onClick={() => setRating(i)}
          onMouseEnter={() => setHoverRating(i)}
          onMouseLeave={() => setHoverRating(0)}
          style={{ cursor: 'pointer', color: i <= currentRating ? '#fbbf24' : '#ccc' }}
        >
          <i className={i <= currentRating ? 'fa-solid fa-star' : 'fa-regular fa-star'}></i>
        </span>
      );
    }
    return stars;
  };

  return (
    <div className="review-modal-overlay" onClick={onClose}>
      <div className="review-modal" onClick={(e) => e.stopPropagation()}>
        <div className="review-modal-header">
          <h3>
            <i className="fa-solid fa-star" style={{ color: '#fbbf24' }}></i>
            Review {userName || 'User'}
          </h3>
          <button className="modal-close-btn" onClick={onClose}>
            <i className="fa-solid fa-xmark"></i>
          </button>
        </div>

        <div className="review-modal-body">
          <div className="review-user-info">
            <div className="review-user-avatar-wrapper">
              <img 
                src={userPhoto || `https://ui-avatars.com/api/?name=${encodeURIComponent(userName || 'User')}&background=14b8a6&color=fff&bold=true&size=60`} 
                alt={userName || 'User'} 
                className="review-user-avatar"
                onError={(e) => {
                  e.target.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(userName || 'User')}&background=14b8a6&color=fff&bold=true&size=60`;
                }}
              />
            </div>
            <div className="review-user-details">
              <h4>{userName || 'Unknown User'}</h4>
              <p>How was your experience working with them?</p>
            </div>
          </div>

          {hasReviewed ? (
            <div className="review-already-done">
              <i className="fa-solid fa-check-circle"></i>
              <p>You have already reviewed this user.</p>
            </div>
          ) : (
            <>
              <div className="rating-section">
                <label>Rate your experience</label>
                <div className="stars-container">
                  {renderStars()}
                </div>
                <span className="rating-text">
                  {rating > 0 ? `${rating} / 5` : 'Select a rating'}
                </span>
              </div>

              <div className="review-text-section">
                <label>Write your review</label>
                <textarea
                  value={reviewText}
                  onChange={(e) => setReviewText(e.target.value)}
                  placeholder={`What was it like working with ${userName || 'this user'}?`}
                  rows="4"
                  maxLength="500"
                  disabled={loading}
                />
                <span className="char-count">{reviewText.length}/500</span>
              </div>

              {error && (
                <div className="review-error">
                  <i className="fa-solid fa-exclamation-circle"></i>
                  {error}
                </div>
              )}

              <div className="review-actions">
                <button className="cancel-btn" onClick={onClose} disabled={loading}>Cancel</button>
                <button className="submit-btn" onClick={handleSubmit} disabled={loading || hasReviewed}>
                  {loading ? (
                    <><i className="fa-solid fa-spinner fa-spin"></i> Submitting...</>
                  ) : (
                    <><i className="fa-solid fa-paper-plane"></i> Submit Review</>
                  )}
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

// ============================================================
// 📌 মেইন প্রোফাইল পেজ কম্পোনেন্ট
// ============================================================
const UserProfilePage = () => {
  const { userId } = useParams();
  const navigate = useNavigate();
  const [userData, setUserData] = useState(null);
  const [userPosts, setUserPosts] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [userRating, setUserRating] = useState({ average: 0, total: 0 });
  const [loading, setLoading] = useState(true);
  const [isOwner, setIsOwner] = useState(false);
  const [activeTab, setActiveTab] = useState('about');
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [hasReviewed, setHasReviewed] = useState(false);

  // ── রিভিউ ফেচ ফাংশন (রিফ্যাক্টর করা) ──
  const fetchReviews = useCallback(async () => {
    if (!userId) return;

    try {
      const q = query(collection(db, 'reviews'), where('userId', '==', userId), orderBy('createdAt', 'desc'));
      const snapshot = await getDocs(q);
      const reviewsData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setReviews(reviewsData);

      if (reviewsData.length > 0) {
        const total = reviewsData.reduce((sum, r) => sum + r.rating, 0);
        const average = total / reviewsData.length;
        setUserRating({ average: Math.round(average * 10) / 10, total: reviewsData.length });
      }

      if (auth.currentUser) {
        const hasUserReviewed = reviewsData.some(r => r.reviewerId === auth.currentUser.uid);
        setHasReviewed(hasUserReviewed);
      }
    } catch (error) {
      console.error("Error fetching reviews:", error);
    }
  }, [userId]);

  // ── ইউজার ডেটা ফেচ ──
  useEffect(() => {
    if (!userId) {
      setLoading(false);
      return;
    }

    const userRef = doc(db, 'users', userId);
    const unsubscribeUser = onSnapshot(userRef, (docSnapshot) => {
      if (docSnapshot.exists()) {
        setUserData(docSnapshot.data());
        setIsOwner(auth.currentUser?.uid === userId);
      } else {
        setUserData(null);
      }
      setLoading(false);
    }, (error) => {
      console.error("Error listening to user data:", error);
      setLoading(false);
    });

    const fetchPosts = async () => {
      try {
        const postsRef = collection(db, 'posts');
        const q = query(postsRef, where('userId', '==', userId));
        const postsSnap = await getDocs(q);
        const posts = postsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setUserPosts(posts);
      } catch (error) {
        console.error("Error fetching posts:", error);
      }
    };

    fetchPosts();
    return () => unsubscribeUser();
  }, [userId]);

  // ── রিভিউ ফেচ ──
  useEffect(() => {
    fetchReviews();
  }, [fetchReviews]);

  // ── চ্যাট আইডি জেনারেটর ──
  const getChatId = useCallback(() => {
    if (!auth.currentUser || !userId) return null;
    return [auth.currentUser.uid, userId].sort().join('_');
  }, [userId]);

  // ── Hire Flow ──
  const handleStartFlow = async () => {
    if (!auth.currentUser) {
      alert("Please login to start a project!");
      navigate('/login');
      return;
    }

    if (isOwner) {
      alert("You cannot start a project with yourself!");
      return;
    }

    try {
      const chatId = getChatId();
      const chatRef = doc(db, 'chats', chatId);
      const chatSnap = await getDoc(chatRef);

      if (!chatSnap.exists()) {
        await setDoc(chatRef, {
          participants: [auth.currentUser.uid, userId],
          createdAt: serverTimestamp(),
          lastMessage: '',
          unreadCount: {
            [auth.currentUser.uid]: 0,
            [userId]: 0
          }
        });
      }

      navigate('/inbox', { state: { chatId, userId } });
    } catch (error) {
      console.error("Error starting flow:", error);
      alert("Failed to start project. Please try again.");
    }
  };

  // ── মেসেজ ──
  const handleSendMessage = useCallback(() => {
    if (!auth.currentUser) {
      alert("Please login to send message!");
      navigate('/login');
      return;
    }
    const chatId = getChatId();
    navigate('/inbox', { state: { chatId, userId } });
  }, [getChatId, navigate]);

  // ✅ ফিক্স ২: রিভিউ সাবমিট হ্যান্ডলার
  const handleReviewSubmitted = useCallback(() => {
    setHasReviewed(true);
    fetchReviews(); // ✅ রিভিউ রিলোড
  }, [fetchReviews]);

  if (loading) {
    return (
      <div className="profile-loading">
        <div className="loading-spinner"></div>
        <p>Loading profile...</p>
      </div>
    );
  }

  if (!userData) {
    return (
      <div className="profile-not-found">
        <i className="fa-solid fa-user-slash"></i>
        <h2>User Not Found</h2>
        <p>The user you're looking for doesn't exist.</p>
        <button onClick={() => navigate('/')}>Back to Home</button>
      </div>
    );
  }

  const isProfilePrivate = userData.privacySettings?.profileVisibility === 'private';
  const canViewProfile = !isProfilePrivate || isOwner;

  if (!canViewProfile) {
    return (
      <div className="profile-private">
        <i className="fa-solid fa-lock"></i>
        <h2>This profile is private</h2>
        <p>This user has set their profile to private mode.</p>
        <button onClick={() => navigate('/')}>Back to Home</button>
      </div>
    );
  }

  return (
    <div className="user-profile-page">
      {/* প্রোফাইল হেডার */}
      <div className="profile-header">
        <div className="profile-avatar-section">
          <div className="avatar-wrapper">
            <img 
              src={userData.photoURL || `https://ui-avatars.com/api/?name=${userData.displayName || 'User'}&background=14b8a6&color=fff&bold=true&size=120`} 
              alt={userData.displayName || 'User'} 
              className="profile-avatar"
            />
          </div>
          
          <div className="profile-info">
            <h1>{userData.displayName || 'Unknown User'}</h1>
            <p className="profile-headline">{userData.headline || 'No headline set'}</p>
            
            <div className="profile-stats">
              <span><i className="fa-solid fa-file-alt"></i> {userPosts.length} Posts</span>
              <span><i className="fa-solid fa-users"></i> {userData.followers || 0} Followers</span>
              <span>
                <i className="fa-solid fa-star" style={{ color: '#fbbf24' }}></i> 
                {userRating.average > 0 ? `${userRating.average} (${userRating.total})` : 'No reviews'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* অ্যাকশন বাটনস */}
      {!isOwner && (
        <div className="profile-actions">
          <button className="btn-flow" onClick={handleStartFlow}>
            <i className="fa-solid fa-rocket"></i> Start Project
          </button>
          
          <button className="btn-message" onClick={handleSendMessage}>
            <i className="fa-solid fa-envelope"></i> Message
          </button>
          
          <button 
            className="btn-review" 
            onClick={() => setShowReviewModal(true)}
            disabled={hasReviewed}
          >
            <i className="fa-solid fa-star"></i> 
            {hasReviewed ? 'Already Reviewed' : 'Write a Review'}
          </button>
        </div>
      )}

      {isOwner && (
        <div className="profile-actions owner-actions">
          <button className="btn-edit-profile" onClick={() => navigate('/settings')}>
            <i className="fa-solid fa-pen"></i> Edit Profile
          </button>
        </div>
      )}

      {/* ট্যাব নেভিগেশন */}
      <div className="profile-tabs">
        <button className={`tab-btn ${activeTab === 'about' ? 'active' : ''}`} onClick={() => setActiveTab('about')}>
          <i className="fa-solid fa-user"></i> About
        </button>
        <button className={`tab-btn ${activeTab === 'posts' ? 'active' : ''}`} onClick={() => setActiveTab('posts')}>
          <i className="fa-solid fa-file-alt"></i> Posts ({userPosts.length})
        </button>
        <button className={`tab-btn ${activeTab === 'reviews' ? 'active' : ''}`} onClick={() => setActiveTab('reviews')}>
          <i className="fa-solid fa-star"></i> Reviews ({reviews.length})
          {reviews.length > 0 && <span className="tab-badge">{userRating.average}★</span>}
        </button>
        <button className={`tab-btn ${activeTab === 'experience' ? 'active' : ''}`} onClick={() => setActiveTab('experience')}>
          <i className="fa-solid fa-briefcase"></i> Experience
        </button>
        <button className={`tab-btn ${activeTab === 'education' ? 'active' : ''}`} onClick={() => setActiveTab('education')}>
          <i className="fa-solid fa-graduation-cap"></i> Education
        </button>
        <button className={`tab-btn ${activeTab === 'certifications' ? 'active' : ''}`} onClick={() => setActiveTab('certifications')}>
          <i className="fa-solid fa-award"></i> Certifications
        </button>
        <button className={`tab-btn ${activeTab === 'social' ? 'active' : ''}`} onClick={() => setActiveTab('social')}>
          <i className="fa-solid fa-share-nodes"></i> Connect
        </button>
        {isOwner && (
          <button className={`tab-btn ${activeTab === 'private' ? 'active' : ''}`} onClick={() => setActiveTab('private')}>
            <i className="fa-solid fa-lock"></i> Private Info
          </button>
        )}
      </div>

      {/* ট্যাব কন্টেন্ট */}
      <div className="profile-tab-content">
        {activeTab === 'about' && (
          <div className="tab-panel about-panel">
            <h3><i className="fa-solid fa-user-pen"></i> About</h3>
            <p>{userData.bio || 'No bio provided yet.'}</p>
            
            {userData.skills && (
              <div className="skills-section">
                <h4>Skills</h4>
                <div className="skills-tags">
                  {userData.skills.split(',').map((skill, idx) => (
                    <span key={idx} className="skill-tag">{skill.trim()}</span>
                  ))}
                </div>
              </div>
            )}
            
            <div className="info-grid">
              <div className="info-item"><i className="fa-solid fa-location-dot"></i><span>{userData.location || 'Location not set'}</span></div>
              <div className="info-item"><i className="fa-solid fa-globe"></i><span>{userData.website || 'No website'}</span></div>
              <div className="info-item"><i className="fa-solid fa-calendar"></i><span>Joined {userData.createdAt ? new Date(userData.createdAt).toLocaleDateString() : 'Recently'}</span></div>
            </div>
          </div>
        )}

        {activeTab === 'posts' && (
          <div className="tab-panel posts-panel">
            <h3><i className="fa-solid fa-file-alt"></i> Posts ({userPosts.length})</h3>
            {userPosts.length === 0 ? (
              <div className="no-posts"><i className="fa-solid fa-folder-open"></i><p>No posts yet.</p></div>
            ) : (
              <div className="posts-grid">
                {userPosts.map((post) => (
                  <div key={post.id} className="post-card-mini" onClick={() => navigate(`/post/${post.id}`)} style={{ cursor: 'pointer' }}>
                    {post.images && post.images.length > 0 && <img src={post.images[0]} alt={post.title} className="post-thumbnail" />}
                    <div className="post-info">
                      <h4>{post.title}</h4>
                      <p>{post.description?.substring(0, 60)}...</p>
                      <span className="post-budget">৳ {post.budget} BDT</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'reviews' && (
          <div className="tab-panel reviews-panel">
            <div className="reviews-header">
              <h3><i className="fa-solid fa-star" style={{ color: '#fbbf24' }}></i> Reviews ({reviews.length})</h3>
              {reviews.length > 0 && (
                <div className="average-rating">
                  <span className="rating-number">{userRating.average}</span>
                  <div className="rating-stars">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <i key={star} className={`fa-solid fa-star ${star <= Math.round(userRating.average) ? 'filled' : ''}`}></i>
                    ))}
                  </div>
                  <span className="rating-total">({userRating.total} reviews)</span>
                </div>
              )}
            </div>
            
            {reviews.length === 0 ? (
              <div className="no-reviews">
                <i className="fa-solid fa-star-half-stroke"></i>
                <p>No reviews yet.</p>
                {!isOwner && !hasReviewed && (
                  <button className="btn-review" onClick={() => setShowReviewModal(true)}>
                    <i className="fa-solid fa-star"></i> Be the first to review
                  </button>
                )}
              </div>
            ) : (
              <div className="reviews-list">
                {reviews.map((review) => (
                  <div key={review.id} className="review-card">
                    <div className="review-header">
                      <div className="reviewer-info">
                        <img src={review.reviewerPhoto || `https://ui-avatars.com/api/?name=${review.reviewerName}&background=14b8a6&color=fff&bold=true&size=40`} alt={review.reviewerName} className="reviewer-avatar" />
                        <div>
                          <h4>{review.reviewerName}</h4>
                          <div className="review-stars">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <i key={star} className={`fa-solid fa-star ${star <= review.rating ? 'filled' : ''}`}></i>
                            ))}
                          </div>
                        </div>
                      </div>
                      <span className="review-date">{review.createdAt ? new Date(review.createdAt).toLocaleDateString() : 'Recently'}</span>
                    </div>
                    <p className="review-text">{review.text}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'experience' && (
          <div className="tab-panel experience-panel">
            <h3><i className="fa-solid fa-briefcase"></i> Work Experience</h3>
            {userData.experience && userData.experience.length > 0 ? (
              userData.experience.map((exp, index) => (
                <div key={index} className="item-card">
                  <div className="item-header"><h4>{exp.role} at {exp.company}</h4></div>
                  <p className="item-date">{exp.startDate} - {exp.endDate || 'Present'}</p>
                  <p className="item-description">{exp.description}</p>
                </div>
              ))
            ) : (
              <div className="empty-state"><i className="fa-solid fa-briefcase"></i><p>No experience added yet</p></div>
            )}
          </div>
        )}

        {activeTab === 'education' && (
          <div className="tab-panel education-panel">
            <h3><i className="fa-solid fa-graduation-cap"></i> Education</h3>
            {userData.education && userData.education.length > 0 ? (
              userData.education.map((edu, index) => (
                <div key={index} className="item-card">
                  <div className="item-header"><h4>{edu.degree} - {edu.field}</h4></div>
                  <p className="item-institution">{edu.institution}</p>
                  <p className="item-date">{edu.startDate} - {edu.endDate || 'Present'}</p>
                </div>
              ))
            ) : (
              <div className="empty-state"><i className="fa-solid fa-graduation-cap"></i><p>No education added yet</p></div>
            )}
          </div>
        )}

        {activeTab === 'certifications' && (
          <div className="tab-panel certifications-panel">
            <h3><i className="fa-solid fa-award"></i> Certifications</h3>
            {userData.certifications && userData.certifications.length > 0 ? (
              userData.certifications.map((cert, index) => (
                <div key={index} className="item-card">
                  <div className="item-header"><h4>{cert.name}</h4></div>
                  <p className="item-issuer">Issued by: {cert.issuer}</p>
                  <p className="item-date">{cert.date}</p>
                  {cert.link && <a href={cert.link} target="_blank" rel="noopener noreferrer" className="cert-link">🔗 View Certificate</a>}
                </div>
              ))
            ) : (
              <div className="empty-state"><i className="fa-solid fa-award"></i><p>No certifications added yet</p></div>
            )}
          </div>
        )}

        {activeTab === 'social' && (
          <div className="tab-panel social-panel">
            <h3><i className="fa-solid fa-share-nodes"></i> Connect</h3>
            <div className="social-links-container">
              {userData.socialLinks?.linkedin && <a href={userData.socialLinks.linkedin} target="_blank" rel="noopener noreferrer" className="social-link-item linkedin"><i className="fa-brands fa-linkedin"></i> LinkedIn</a>}
              {userData.socialLinks?.github && <a href={userData.socialLinks.github} target="_blank" rel="noopener noreferrer" className="social-link-item github"><i className="fa-brands fa-github"></i> GitHub</a>}
              {userData.socialLinks?.website && <a href={userData.socialLinks.website} target="_blank" rel="noopener noreferrer" className="social-link-item website"><i className="fa-solid fa-globe"></i> Website</a>}
              {(!userData.socialLinks?.linkedin && !userData.socialLinks?.github && !userData.socialLinks?.website) && (
                <div className="empty-state"><i className="fa-solid fa-share-nodes"></i><p>No social links added yet</p></div>
              )}
            </div>
          </div>
        )}

        {isOwner && activeTab === 'private' && (
          <div className="tab-panel private-panel">
            <h3><i className="fa-solid fa-lock"></i> Private Information</h3>
            <div className="private-info-grid">
              <div className="private-item"><label>Email</label><p>{auth.currentUser?.email || 'Not set'}</p></div>
              <div className="private-item"><label>Wallet Balance</label><p>৳ {userData.balance || 0} BDT</p></div>
              <div className="private-item"><label>User ID</label><p>{userId}</p></div>
              <div className="private-item"><label>Account Status</label><p className="status-active">Active</p></div>
              <div className="private-item"><label>Phone Number</label><p>{userData.phone || 'Not set'}</p></div>
            </div>
          </div>
        )}
      </div>

      {/* রিভিউ মোডাল */}
      {showReviewModal && (
        <ReviewModal
          userId={userId}
          userName={userData?.displayName}
          userPhoto={userData?.photoURL}
          onClose={() => setShowReviewModal(false)}
          onReviewSubmitted={handleReviewSubmitted}
          hasReviewed={hasReviewed}
        />
      )}
    </div>
  );
};

export default UserProfilePage;
