// src/pages/Settings.jsx
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  doc, getDoc, updateDoc, serverTimestamp,
  collection, query, where, getDocs, deleteDoc, 
  writeBatch, orderBy, onSnapshot
} from "firebase/firestore";
import { 
  updateProfile, updatePassword, reauthenticateWithCredential, 
  EmailAuthProvider, sendEmailVerification
} from "firebase/auth";
import { auth, db } from '../firebase';
import toast, { Toaster } from 'react-hot-toast';
import './Settings.css';

// Cloudinary কনফিগারেশন
const CLOUD_NAME = "drwex6tmf";
const UPLOAD_PRESET = "workhub_preset";

// ============================================================
// 🆕 টগল সুইচ কম্পোনেন্ট
// ============================================================
const ToggleSwitch = ({ checked, onChange, label, description = '', disabled = false }) => {
  return (
    <div className="toggle-switch-wrapper">
      <div className="toggle-info">
        <label className="toggle-label">{label}</label>
        {description && <p className="toggle-description">{description}</p>}
      </div>
      <div
        className={`toggle-switch ${checked ? 'active' : ''} ${disabled ? 'disabled' : ''}`}
        onClick={() => !disabled && onChange(!checked)}
      >
        <div className="toggle-slider"></div>
      </div>
    </div>
  );
};

// ============================================================
// মেইন Settings কম্পোনেন্ট
// ============================================================
const Settings = () => {
  const navigate = useNavigate();
  const user = auth.currentUser;

  // ========== স্টেট ==========
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState('profile');
  const [uploadingDocs, setUploadingDocs] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [userPosts, setUserPosts] = useState([]);
  const [postsLoading, setPostsLoading] = useState(false);
  const [editingPost, setEditingPost] = useState(null);

  // ── প্রোফাইল ডেটা ──
  const [profileData, setProfileData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    dob: '',
    address: '',
    bio: '',
    skills: [],
    role: 'client',
    displayName: '',
    photoURL: '',
    headline: '',
    coverPhoto: ''
  });

  // ── ডকুমেন্ট স্ট্যাটাস ──
  const [docStatus, setDocStatus] = useState({
    nidFront: false,
    nidBack: false,
    birth: false,
    faceVerified: false,
    documentsUploaded: false
  });

  // ── সিকিউরিটি ডেটা ──
  const [securityData, setSecurityData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
    twoFactorEnabled: false
  });

  // ── নোটিফিকেশন সেটিংস ──
  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    pushNotifications: true,
    dealUpdates: true,
    messageNotifications: true,
    marketingEmails: false
  });

  // ── প্রাইভেসি সেটিংস ──
  const [privacySettings, setPrivacySettings] = useState({
    profileVisibility: 'public',
    showEmail: false,
    showPhone: false,
    activityStatus: true
  });

  // ── পেমেন্ট সেটিংস ──
  const [paymentSettings, setPaymentSettings] = useState({
    defaultCurrency: 'BDT',
    paymentMethod: 'bank',
    bankAccount: '',
    bankName: '',
    accountHolder: ''
  });

  // ── এক্সপেরিয়েন্স ──
  const [experience, setExperience] = useState([]);
  const [isEditingExperience, setIsEditingExperience] = useState(false);
  const [newExperience, setNewExperience] = useState({ 
    company: '', role: '', startDate: '', endDate: '', description: '' 
  });

  // ── এডুকেশন ──
  const [education, setEducation] = useState([]);
  const [isEditingEducation, setIsEditingEducation] = useState(false);
  const [newEducation, setNewEducation] = useState({ 
    institution: '', degree: '', field: '', startDate: '', endDate: '' 
  });

  // ── সার্টিফিকেশন ──
  const [certifications, setCertifications] = useState([]);
  const [isEditingCertifications, setIsEditingCertifications] = useState(false);
  const [newCertification, setNewCertification] = useState({ 
    name: '', issuer: '', date: '', link: '' 
  });

  // ── সোশ্যাল লিংক ──
  const [socialLinks, setSocialLinks] = useState({
    linkedin: '', github: '', website: ''
  });

  // ── ফেস ভেরিফিকেশন ──
  const [faceVerified, setFaceVerified] = useState(false);
  const [camStream, setCamStream] = useState(null);
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const [livenessComplete, setLivenessComplete] = useState(false);
  const [currentLivenessStep, setCurrentLivenessStep] = useState(0);
  const [livenessTimer, setLivenessTimer] = useState(null);
  const [livenessState, setLivenessState] = useState([
    { id: 'eyeOpen', label: '👁️ চোখ খোলা', done: false },
    { id: 'eyeClose', label: '😌 চোখ বন্ধ', done: false },
    { id: 'mouthOpen', label: '👄 মুখ খোলা', done: false },
    { id: 'mouthClose', label: '😐 মুখ বন্ধ', done: false },
    { id: 'headRight', label: '👉 মাথা ডানে', done: false },
    { id: 'headLeft', label: '👈 মাথা বামে', done: false }
  ]);

  // ── পোস্ট এডিট ──
  const [editForm, setEditForm] = useState({
    title: '', description: '', budget: '', deadline: '', images: []
  });
  const [editImages, setEditImages] = useState([]);
  const [editImagePreviews, setEditImagePreviews] = useState([]);
  const [editImageLoading, setEditImageLoading] = useState(false);
  const editFileInputRef = useRef(null);

  // ============================================================
  // ✅ ইউজার ডাটা লোড - রিয়েল-টাইম
  // ============================================================
  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    setLoading(true);
    
    const userRef = doc(db, 'users', user.uid);
    const unsubscribe = onSnapshot(userRef, (docSnapshot) => {
      if (docSnapshot.exists()) {
        const data = docSnapshot.data();
        
        // প্রোফাইল ডেটা সেট
        setProfileData(prev => ({
          ...prev,
          displayName: data.displayName || user.displayName || '',
          email: user.email || '',
          photoURL: data.photoURL || user.photoURL || '',
          firstName: data.firstName || '',
          lastName: data.lastName || '',
          phone: data.phone || '',
          dob: data.dob || '',
          address: data.address || '',
          bio: data.bio || '',
          headline: data.headline || '',
          skills: data.skills || [],
          role: data.role || 'client',
          coverPhoto: data.coverPhoto || ''
        }));

        // ডকুমেন্ট স্ট্যাটাস
        const docs = data.documents || {};
        setDocStatus({
          nidFront: !!docs.nidFront,
          nidBack: !!docs.nidBack,
          birth: !!docs.birthCert,
          faceVerified: !!data.facePhotoUrl,
          documentsUploaded: !!(docs.nidFront || docs.birthCert)
        });
        setFaceVerified(!!data.facePhotoUrl);

        // এক্সপেরিয়েন্স, এডুকেশন, সার্টিফিকেশন
        setExperience(data.experience || []);
        setEducation(data.education || []);
        setCertifications(data.certifications || []);
        setSocialLinks(data.socialLinks || { linkedin: '', github: '', website: '' });

        // নোটিফিকেশন, প্রাইভেসি, পেমেন্ট সেটিংস
        if (data.notificationSettings) {
          setNotificationSettings(prev => ({ ...prev, ...data.notificationSettings }));
        }
        if (data.privacySettings) {
          setPrivacySettings(prev => ({ ...prev, ...data.privacySettings }));
        }
        if (data.paymentSettings) {
          setPaymentSettings(prev => ({ ...prev, ...data.paymentSettings }));
        }
        if (data.twoFactorEnabled !== undefined) {
          setSecurityData(prev => ({ ...prev, twoFactorEnabled: data.twoFactorEnabled }));
        }
      }
      setLoading(false);
    }, (error) => {
      console.error("Error loading settings:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user, navigate]);

  // ============================================================
  // ✅ ইউজারের পোস্ট লোড
  // ============================================================
  useEffect(() => {
    if (!user?.uid) return;

    const loadPosts = async () => {
      setPostsLoading(true);
      try {
        const q = query(
          collection(db, 'posts'), 
          where('userId', '==', user.uid),
          orderBy('createdAt', 'desc')
        );
        const snapshot = await getDocs(q);
        const posts = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        }));
        setUserPosts(posts);
      } catch (error) {
        console.error("Error loading posts:", error);
      } finally {
        setPostsLoading(false);
      }
    };

    loadPosts();
  }, [user?.uid]);

  // ============================================================
  // ✅ ক্লাউডিনারি আপলোড
  // ============================================================
  const uploadToCloudinary = async (file, folder = 'user_documents') => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('upload_preset', UPLOAD_PRESET);
    formData.append('folder', folder);
    
    try {
      const response = await fetch(
        `https://api.cloudinary.com/v1_1/${CLOUD_NAME}/image/upload`,
        { method: 'POST', body: formData }
      );
      
      if (!response.ok) throw new Error('Upload failed');
      const data = await response.json();
      return { url: data.secure_url, publicId: data.public_id };
    } catch (error) {
      console.error('Cloudinary upload error:', error);
      throw error;
    }
  };

  // ============================================================
  // ✅ কমন আপডেট ফাংশন
  // ============================================================
  const updateFirebase = async (dataToUpdate, successMessage = '✅ Updated successfully!') => {
    setSaving(true);
    try {
      const userRef = doc(db, 'users', user.uid);
      await updateDoc(userRef, {
        ...dataToUpdate,
        updatedAt: serverTimestamp()
      });
      toast.success(successMessage);
      return true;
    } catch (error) {
      console.error("Error updating:", error);
      toast.error('❌ Failed to update: ' + error.message);
      return false;
    } finally {
      setSaving(false);
    }
  };

  // ============================================================
  // ✅ প্রোফাইল আপডেট
  // ============================================================
  const handleUpdateProfile = async () => {
    if (!profileData.firstName.trim() || !profileData.lastName.trim()) {
      toast.error('❌ নাম দিন!');
      return;
    }

    setSaving(true);
    try {
      const fullName = `${profileData.firstName} ${profileData.lastName}`.trim();
      
      await updateProfile(user, {
        displayName: fullName,
        photoURL: profileData.photoURL
      });

      const userRef = doc(db, 'users', user.uid);
      await updateDoc(userRef, {
        firstName: profileData.firstName,
        lastName: profileData.lastName,
        displayName: fullName,
        phone: profileData.phone,
        dob: profileData.dob,
        address: profileData.address,
        bio: profileData.bio,
        headline: profileData.headline,
        skills: profileData.skills,
        role: profileData.role,
        updatedAt: serverTimestamp()
      });

      toast.success('✅ প্রোফাইল আপডেট করা হয়েছে!');
      checkCompletion();
      
    } catch (error) {
      console.error("Error updating profile:", error);
      toast.error('❌ প্রোফাইল আপডেট করতে সমস্যা হয়েছে');
    } finally {
      setSaving(false);
    }
  };

  // ============================================================
  // ✅ প্রোফাইল পিক আপলোড
  // ============================================================
  const handleProfilePicUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    try {
      const result = await uploadToCloudinary(file, 'profile_pictures');
      if (result.url) {
        await updateProfile(user, { photoURL: result.url });
        const userRef = doc(db, 'users', user.uid);
        await updateDoc(userRef, { photoURL: result.url });
        setProfileData(prev => ({ ...prev, photoURL: result.url }));
        toast.success('✅ প্রোফাইল ছবি আপডেট করা হয়েছে!');
      }
    } catch (error) {
      console.error("Error:", error);
      toast.error('❌ প্রোফাইল ছবি আপলোড ব্যর্থ হয়েছে');
    }
  };

  // ============================================================
  // ✅ ডকুমেন্ট আপলোড
  // ============================================================
  const uploadDocuments = async () => {
    setUploadingDocs(true);
    setUploadProgress(0);
    
    try {
      const uploadedDocs = {};
      let progress = 0;
      
      const frontFile = document.getElementById('nidFront')?.files[0];
      if (frontFile) {
        const result = await uploadToCloudinary(frontFile, 'nid_documents');
        uploadedDocs.nidFront = result;
        progress += 33;
        setUploadProgress(progress);
      }
      
      const backFile = document.getElementById('nidBack')?.files[0];
      if (backFile) {
        const result = await uploadToCloudinary(backFile, 'nid_documents');
        uploadedDocs.nidBack = result;
        progress += 33;
        setUploadProgress(progress);
      }
      
      const birthFile = document.getElementById('birthCert')?.files[0];
      if (birthFile) {
        const result = await uploadToCloudinary(birthFile, 'birth_documents');
        uploadedDocs.birthCert = result;
        progress += 34;
        setUploadProgress(progress);
      }
      
      await updateDoc(doc(db, 'users', user.uid), {
        documents: uploadedDocs,
        documentVerified: false,
        documentType: 'nid',
        documentSubmittedAt: serverTimestamp()
      });
      
      setDocStatus(prev => ({ ...prev, documentsUploaded: true }));
      setUploadProgress(100);
      toast.success('✅ ডকুমেন্ট আপলোড সম্পন্ন!');
      checkCompletion();
      
    } catch (error) {
      console.error('Document upload error:', error);
      toast.error('❌ ডকুমেন্ট আপলোড ব্যর্থ হয়েছে');
    } finally {
      setUploadingDocs(false);
    }
  };

  // ============================================================
  // ✅ ফেস ভেরিফিকেশন
  // ============================================================
  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } }
      });
      setCamStream(stream);
      if (videoRef.current) videoRef.current.srcObject = stream;
      
      document.getElementById('cameraBox')?.classList.add('camera-active');
      document.getElementById('camStartBtn').style.display = 'none';
      document.getElementById('captureBtn').style.display = '';
      document.getElementById('camStopBtn').style.display = '';
      
      toast.success('📷 ক্যামেরা চালু হয়েছে');
      resetLiveness();
      setTimeout(startLivenessDetection, 1000);
      
    } catch (e) {
      if (e.name === 'NotAllowedError') {
        toast.error('⚠️ ক্যামেরা অ্যাক্সেস ডিনাই করা হয়েছে');
      } else {
        toast.error('⚠️ ক্যামেরা চালু করা যায়নি');
      }
    }
  };

  const stopCamera = () => {
    if (camStream) {
      camStream.getTracks().forEach(t => t.stop());
      setCamStream(null);
    }
    document.getElementById('cameraBox')?.classList.remove('camera-active');
    document.getElementById('camStartBtn').style.display = '';
    document.getElementById('captureBtn').style.display = 'none';
    document.getElementById('camStopBtn').style.display = 'none';
    resetLiveness();
  };

  const startLivenessDetection = () => {
    if (livenessComplete) return;
    const resetState = livenessState.map(s => ({ ...s, done: false }));
    setLivenessState(resetState);
    setCurrentLivenessStep(0);
    setLivenessComplete(false);
    startLivenessTimer();
  };

  const startLivenessTimer = () => {
    clearInterval(livenessTimer);
    const interval = setInterval(() => {
      if (livenessComplete) { clearInterval(interval); return; }
      const current = livenessState[currentLivenessStep];
      if (current && !current.done) {
        const updated = [...livenessState];
        updated[currentLivenessStep].done = true;
        setLivenessState(updated);
        const nextStep = currentLivenessStep + 1;
        setCurrentLivenessStep(nextStep);
        if (nextStep >= livenessState.length) {
          clearInterval(interval);
        }
        updateLivenessUI(updated);
      }
    }, 3000);
    setLivenessTimer(interval);
  };

  const updateLivenessUI = (state) => {
    const doneCount = state.filter(s => s.done).length;
    const total = state.length;
    document.getElementById('livenessProgressText').textContent = `${doneCount}/${total} সম্পন্ন`;
    document.getElementById('livenessProgressFill').style.width = `${(doneCount/total)*100}%`;
    
    if (doneCount === total) {
      setLivenessComplete(true);
      clearInterval(livenessTimer);
      setTimeout(capturePhoto, 1000);
    }
  };

  const resetLiveness = () => {
    setLivenessComplete(false);
    setCurrentLivenessStep(0);
    const resetState = livenessState.map(s => ({ ...s, done: false }));
    setLivenessState(resetState);
    clearInterval(livenessTimer);
    updateLivenessUI(resetState);
  };

  const capturePhoto = async () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;
    
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0);
    
    const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg'));
    
    if (camStream) {
      camStream.getTracks().forEach(t => t.stop());
      setCamStream(null);
    }
    
    document.getElementById('cameraBox')?.classList.remove('camera-active');
    document.getElementById('captureBtn').style.display = 'none';
    document.getElementById('camStartBtn').style.display = '';
    
    try {
      const file = new File([blob], 'face_photo.jpg', { type: 'image/jpeg' });
      const result = await uploadToCloudinary(file, 'face_photos');
      
      await updateDoc(doc(db, 'users', user.uid), {
        facePhotoUrl: result.url,
        faceVerified: true
      });
      
      setFaceVerified(true);
      setDocStatus(prev => ({ ...prev, faceVerified: true }));
      toast.success('✅ মুখমণ্ডল যাচাই সম্পন্ন!');
      checkCompletion();
      
    } catch (error) {
      console.error('Face photo upload error:', error);
      toast.error('❌ ফেস ফটো আপলোড ব্যর্থ হয়েছে');
    }
  };

  // ============================================================
  // ✅ কমপ্লিটনেস চেক
  // ============================================================
  const checkCompletion = async () => {
    if (!user) return;
    
    try {
      const userDoc = await getDoc(doc(db, 'users', user.uid));
      const data = userDoc.data();
      
      const isComplete = !!(
        data.firstName &&
        data.lastName &&
        data.email &&
        data.phone &&
        data.dob &&
        (data.documents?.nidFront || data.documents?.birthCert) &&
        data.facePhotoUrl
      );
      
      if (isComplete) {
        await updateDoc(doc(db, 'users', user.uid), {
          isComplete: true,
          completedAt: serverTimestamp()
        });
        toast.success('🎉 আপনার প্রোফাইল সম্পূর্ণ! এখন লেনদেন করতে পারবেন।');
      }
      
    } catch (error) {
      console.error('Completion check error:', error);
    }
  };

  // ============================================================
  // ✅ পাসওয়ার্ড পরিবর্তন
  // ============================================================
  const handleChangePassword = async () => {
    if (securityData.newPassword !== securityData.confirmPassword) {
      toast.error('❌ পাসওয়ার্ড মিলছে না!');
      return;
    }
    if (securityData.newPassword.length < 6) {
      toast.error('❌ পাসওয়ার্ড কমপক্ষে ৬ অক্ষর হতে হবে!');
      return;
    }
    if (!securityData.currentPassword) {
      toast.error('❌ বর্তমান পাসওয়ার্ড দিন!');
      return;
    }

    setSaving(true);
    try {
      const credential = EmailAuthProvider.credential(user.email, securityData.currentPassword);
      await reauthenticateWithCredential(user, credential);
      await updatePassword(user, securityData.newPassword);

      setSecurityData({ currentPassword: '', newPassword: '', confirmPassword: '', twoFactorEnabled: securityData.twoFactorEnabled });
      toast.success('✅ পাসওয়ার্ড পরিবর্তন করা হয়েছে!');
      
    } catch (error) {
      console.error("Error changing password:", error);
      toast.error('❌ ' + (error.code === 'auth/wrong-password' ? 'বর্তমান পাসওয়ার্ড ভুল!' : error.message));
    } finally {
      setSaving(false);
    }
  };

  // ============================================================
  // ✅ 2FA টগল
  // ============================================================
  const handleTwoFactorToggle = async () => {
    const newValue = !securityData.twoFactorEnabled;
    setSecurityData(prev => ({ ...prev, twoFactorEnabled: newValue }));
    await updateFirebase(
      { twoFactorEnabled: newValue },
      newValue ? '✅ 2FA সক্রিয় করা হয়েছে!' : '❌ 2FA নিষ্ক্রিয় করা হয়েছে!'
    );
  };

  // ============================================================
  // ✅ সেটিংস সেভ
  // ============================================================
  const handleSaveSettings = async (section, data) => {
    await updateFirebase(
      { [section]: data },
      `✅ ${section.replace('Settings', '')} সেটিংস সংরক্ষণ করা হয়েছে!`
    );
  };

  // ============================================================
  // ✅ এক্সপেরিয়েন্স ফাংশন
  // ============================================================
  const handleAddExperience = async () => {
    if (!newExperience.company || !newExperience.role) {
      toast.error('❌ কোম্পানি এবং পদবি দিন!');
      return;
    }
    const updatedExperience = [...experience, { ...newExperience, id: Date.now() }];
    await updateFirebase({ experience: updatedExperience }, '✅ অভিজ্ঞতা যোগ করা হয়েছে!');
    setExperience(updatedExperience);
    setNewExperience({ company: '', role: '', startDate: '', endDate: '', description: '' });
    setIsEditingExperience(false);
  };

  const handleDeleteExperience = async (id) => {
    if (!window.confirm('এই অভিজ্ঞতা ডিলিট করবেন?')) return;
    const updatedExperience = experience.filter(exp => exp.id !== id);
    await updateFirebase({ experience: updatedExperience });
    setExperience(updatedExperience);
  };

  // ============================================================
  // ✅ এডুকেশন ফাংশন
  // ============================================================
  const handleAddEducation = async () => {
    if (!newEducation.institution || !newEducation.degree) {
      toast.error('❌ প্রতিষ্ঠান এবং ডিগ্রি দিন!');
      return;
    }
    const updatedEducation = [...education, { ...newEducation, id: Date.now() }];
    await updateFirebase({ education: updatedEducation }, '✅ শিক্ষা যোগ করা হয়েছে!');
    setEducation(updatedEducation);
    setNewEducation({ institution: '', degree: '', field: '', startDate: '', endDate: '' });
    setIsEditingEducation(false);
  };

  const handleDeleteEducation = async (id) => {
    if (!window.confirm('এই শিক্ষা ডিলিট করবেন?')) return;
    const updatedEducation = education.filter(edu => edu.id !== id);
    await updateFirebase({ education: updatedEducation });
    setEducation(updatedEducation);
  };

  // ============================================================
  // ✅ সার্টিফিকেশন ফাংশন
  // ============================================================
  const handleAddCertification = async () => {
    if (!newCertification.name || !newCertification.issuer) {
      toast.error('❌ সার্টিফিকেশন নাম এবং ইস্যুয়ার দিন!');
      return;
    }
    const updatedCertifications = [...certifications, { ...newCertification, id: Date.now() }];
    await updateFirebase({ certifications: updatedCertifications }, '✅ সার্টিফিকেশন যোগ করা হয়েছে!');
    setCertifications(updatedCertifications);
    setNewCertification({ name: '', issuer: '', date: '', link: '' });
    setIsEditingCertifications(false);
  };

  const handleDeleteCertification = async (id) => {
    if (!window.confirm('এই সার্টিফিকেশন ডিলিট করবেন?')) return;
    const updatedCertifications = certifications.filter(cert => cert.id !== id);
    await updateFirebase({ certifications: updatedCertifications });
    setCertifications(updatedCertifications);
  };

  // ============================================================
  // ✅ সোশ্যাল লিংক সেভ
  // ============================================================
  const handleSaveSocialLinks = async () => {
    await updateFirebase({ socialLinks }, '✅ সোশ্যাল লিংক আপডেট করা হয়েছে!');
  };

  // ============================================================
  // ✅ পোস্ট এডিট ফাংশন
  // ============================================================
  const handleEditPost = (post) => {
    setEditingPost(post);
    setEditForm({
      title: post.title || '',
      description: post.description || '',
      budget: post.budget || post.price || '',
      deadline: post.deadline || post.deliveryDays || '',
      images: post.images || []
    });
    setEditImagePreviews([... (post.images || [])]);
    setEditImages([]);
  };

  const handleEditImageChange = (e) => {
    const files = Array.from(e.target.files);
    const remainingSlots = 2 - editImagePreviews.length;
    
    if (files.length > remainingSlots) {
      toast.error(`⚠️ আপনি আরও ${remainingSlots}টি ছবি যোগ করতে পারবেন। সর্বোচ্চ ২টি ছবি!`);
      return;
    }
    
    const newPreviews = files.map(file => URL.createObjectURL(file));
    setEditImages(prev => [...prev, ...files]);
    setEditImagePreviews(prev => [...prev, ...newPreviews]);
  };

  const handleRemoveEditImage = (indexToRemove) => {
    const previewToRemove = editImagePreviews[indexToRemove];
    const isExistingImage = typeof previewToRemove === 'string' && previewToRemove.startsWith('http');
    
    if (isExistingImage) {
      const currentImages = [...editForm.images];
      const imageUrlToRemove = previewToRemove.split('?')[0];
      const imageIndex = currentImages.findIndex(img => img.split('?')[0] === imageUrlToRemove);
      
      if (imageIndex !== -1) {
        currentImages.splice(imageIndex, 1);
        setEditForm(prev => ({ ...prev, images: currentImages }));
      }
    } else {
      const fileIndex = indexToRemove - (editForm.images?.length || 0);
      if (fileIndex >= 0 && fileIndex < editImages.length) {
        setEditImages(prev => prev.filter((_, i) => i !== fileIndex));
      }
    }
    
    setEditImagePreviews(prev => prev.filter((_, i) => i !== indexToRemove));
  };

  const uploadEditImages = async () => {
    if (editImages.length === 0) return [];
    
    const uploadedUrls = [];
    for (const file of editImages) {
      const result = await uploadToCloudinary(file, 'post_images');
      if (result.url) uploadedUrls.push(result.url);
    }
    return uploadedUrls;
  };

  const handleUpdatePost = async () => {
    if (!editingPost) return;
    
    setEditImageLoading(true);
    
    try {
      const postRef = doc(db, 'posts', editingPost.id);
      const postSnap = await getDoc(postRef);
      
      if (!postSnap.exists()) {
        toast.error('❌ এই পোস্ট আর নেই।');
        setEditingPost(null);
        setEditImageLoading(false);
        return;
      }
      
      const existingImages = (editForm.images || []).filter(img => typeof img === 'string');
      let newImageUrls = [];
      
      if (editImages.length > 0) {
        newImageUrls = await uploadEditImages();
      }
      
      const finalImages = [...existingImages, ...newImageUrls];
      
      if (finalImages.length === 0) {
        toast.error('⚠️ কমপক্ষে একটি ছবি রাখুন!');
        setEditImageLoading(false);
        return;
      }
      
      await updateDoc(postRef, {
        title: editForm.title,
        description: editForm.description,
        budget: editForm.budget,
        deadline: editForm.deadline,
        images: finalImages,
        updatedAt: serverTimestamp()
      });
      
      toast.success('✅ পোস্ট আপডেট করা হয়েছে!');
      
      setUserPosts(prev => prev.map(post => 
        post.id === editingPost.id 
          ? { ...post, title: editForm.title, description: editForm.description, budget: editForm.budget, deadline: editForm.deadline, images: finalImages } 
          : post
      ));
      
      setEditingPost(null);
      setEditForm({ title: '', description: '', budget: '', deadline: '', images: [] });
      setEditImages([]);
      setEditImagePreviews([]);
      
    } catch (error) {
      console.error("❌ Update error:", error);
      toast.error('❌ পোস্ট আপডেট ব্যর্থ হয়েছে: ' + error.message);
    } finally {
      setEditImageLoading(false);
    }
  };

  const handleDeletePost = async (postId) => {
    if (!window.confirm('⚠️ এই পোস্ট স্থায়ীভাবে ডিলিট করবেন?')) return;
    
    try {
      const batch = writeBatch(db);
      const postRef = doc(db, 'posts', postId);
      batch.delete(postRef);
      await batch.commit();
      
      setUserPosts(prev => prev.filter(p => p.id !== postId));
      toast.success('✅ পোস্ট ডিলিট করা হয়েছে!');
    } catch (error) {
      console.error("❌ Delete error:", error);
      toast.error('❌ পোস্ট ডিলিট ব্যর্থ হয়েছে: ' + error.message);
    }
  };

  // ============================================================
  // ✅ চেক ফাংশন
  // ============================================================
  const isProfileComplete = () => {
    const { firstName, lastName, phone, dob } = profileData;
    return !!(firstName && lastName && phone && dob);
  };

  const isDocsComplete = docStatus.documentsUploaded;
  const isFaceComplete = docStatus.faceVerified;
  const allComplete = isProfileComplete() && isDocsComplete && isFaceComplete;

  // ============================================================
  // ✅ রেন্ডার
  // ============================================================
  if (loading) {
    return (
      <div className="settings-container">
        <div className="loading-state">
          <div className="loading-spinner"></div>
          <p>লোড হচ্ছে...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="settings-container">
      <Toaster position="top-center" />

      <div className="settings-wrapper">
        <div className="settings-header">
          <h1><i className="fa-solid fa-sliders"></i> সেটিংস</h1>
          <p>আপনার অ্যাকাউন্ট সম্পূর্ণ করুন</p>
          
          {!allComplete && (
            <div className="completion-warning">
              <i className="fa-solid fa-triangle-exclamation"></i>
              <span>
                লেনদেন করতে হলে সব সেকশন সম্পূর্ণ করতে হবে। 
                {!isProfileComplete() && ' প্রোফাইল তথ্য'}
                {!isProfileComplete() && !isDocsComplete && ' ও '}
                {!isDocsComplete && ' ডকুমেন্ট'}
                {(!isDocsComplete || !isFaceComplete) && ' ও '}
                {!isFaceComplete && ' ফেস ভেরিফিকেশন'}
                {!isProfileComplete() && !isDocsComplete && !isFaceComplete && ' সম্পূর্ণ করতে হবে।'}
              </span>
            </div>
          )}
          
          {allComplete && (
            <div className="completion-success">
              <i className="fa-solid fa-check-circle"></i>
              <span>🎉 আপনার প্রোফাইল সম্পূর্ণ! এখন লেনদেন করতে পারবেন।</span>
            </div>
          )}
          
          <div className="progress-steps">
            <div className={`step-item ${isProfileComplete() ? 'completed' : 'active'}`}>
              <div className="step-number">1</div>
              <span>প্রোফাইল</span>
            </div>
            <div className={`step-line ${isProfileComplete() ? 'completed' : ''}`}></div>
            <div className={`step-item ${isDocsComplete ? 'completed' : isProfileComplete() ? 'active' : ''}`}>
              <div className="step-number">2</div>
              <span>ডকুমেন্ট</span>
            </div>
            <div className={`step-line ${isDocsComplete ? 'completed' : ''}`}></div>
            <div className={`step-item ${isFaceComplete ? 'completed' : isDocsComplete && isProfileComplete() ? 'active' : ''}`}>
              <div className="step-number">3</div>
              <span>ফেস ভেরিফাই</span>
            </div>
          </div>
        </div>

        <div className="settings-tabs">
          <button className={`settings-tab ${activeTab === 'profile' ? 'active' : ''}`} onClick={() => setActiveTab('profile')}>
            <i className="fa-solid fa-user"></i> প্রোফাইল
          </button>
          <button className={`settings-tab ${activeTab === 'documents' ? 'active' : ''}`} onClick={() => setActiveTab('documents')}>
            <i className="fa-solid fa-file"></i> ডকুমেন্ট
          </button>
          <button className={`settings-tab ${activeTab === 'face' ? 'active' : ''}`} onClick={() => setActiveTab('face')}>
            <i className="fa-solid fa-camera"></i> ফেস
          </button>
          <button className={`settings-tab ${activeTab === 'experience' ? 'active' : ''}`} onClick={() => setActiveTab('experience')}>
            <i className="fa-solid fa-briefcase"></i> অভিজ্ঞতা
          </button>
          <button className={`settings-tab ${activeTab === 'education' ? 'active' : ''}`} onClick={() => setActiveTab('education')}>
            <i className="fa-solid fa-graduation-cap"></i> শিক্ষা
          </button>
          <button className={`settings-tab ${activeTab === 'certifications' ? 'active' : ''}`} onClick={() => setActiveTab('certifications')}>
            <i className="fa-solid fa-award"></i> সার্টিফিকেশন
          </button>
          <button className={`settings-tab ${activeTab === 'social' ? 'active' : ''}`} onClick={() => setActiveTab('social')}>
            <i className="fa-solid fa-share-nodes"></i> সোশ্যাল
          </button>
          <button className={`settings-tab ${activeTab === 'security' ? 'active' : ''}`} onClick={() => setActiveTab('security')}>
            <i className="fa-solid fa-shield"></i> নিরাপত্তা
          </button>
          <button className={`settings-tab ${activeTab === 'notifications' ? 'active' : ''}`} onClick={() => setActiveTab('notifications')}>
            <i className="fa-solid fa-bell"></i> নোটিফিকেশন
          </button>
          <button className={`settings-tab ${activeTab === 'privacy' ? 'active' : ''}`} onClick={() => setActiveTab('privacy')}>
            <i className="fa-solid fa-lock"></i> প্রাইভেসি
          </button>
          <button className={`settings-tab ${activeTab === 'payment' ? 'active' : ''}`} onClick={() => setActiveTab('payment')}>
            <i className="fa-solid fa-credit-card"></i> পেমেন্ট
          </button>
          <button className={`settings-tab ${activeTab === 'posts' ? 'active' : ''}`} onClick={() => setActiveTab('posts')}>
            <i className="fa-solid fa-file-alt"></i> আমার পোস্ট
          </button>
        </div>

        <div className="settings-content">
          
          {/* ===== প্রোফাইল ট্যাব ===== */}
          {activeTab === 'profile' && (
            <div className="settings-section">
              <h2><i className="fa-solid fa-user"></i> প্রোফাইল সেটিংস</h2>
              <div className="settings-form">
                <div className="profile-pic-section">
                  <img 
                    src={profileData.photoURL || `https://ui-avatars.com/api/?name=${profileData.firstName || 'User'}&background=14b8a6&color=fff&bold=true&size=120`} 
                    alt="Profile" 
                    className="settings-avatar" 
                  />
                  <label htmlFor="avatar-upload" className="avatar-upload-btn">
                    <i className="fa-solid fa-camera"></i> ছবি পরিবর্তন
                  </label>
                  <input type="file" id="avatar-upload" hidden accept="image/*" onChange={handleProfilePicUpload} />
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label>নাম <span className="required">*</span></label>
                    <input 
                      type="text" 
                      value={profileData.firstName} 
                      onChange={(e) => setProfileData({...profileData, firstName: e.target.value})} 
                      placeholder="আপনার নাম" 
                    />
                  </div>
                  <div className="form-group">
                    <label>পদবি <span className="required">*</span></label>
                    <input 
                      type="text" 
                      value={profileData.lastName} 
                      onChange={(e) => setProfileData({...profileData, lastName: e.target.value})} 
                      placeholder="পদবি" 
                    />
                  </div>
                </div>

                <div className="form-group">
                  <label>হেডলাইন</label>
                  <input 
                    type="text" 
                    value={profileData.headline} 
                    onChange={(e) => setProfileData({...profileData, headline: e.target.value})} 
                    placeholder="আপনার পেশাগত হেডলাইন" 
                  />
                </div>

                <div className="form-group">
                  <label>ইমেইল <span className="required">*</span></label>
                  <input type="email" value={profileData.email} disabled className="disabled-input" />
                  <small>ইমেইল পরিবর্তন করা যাবে না।</small>
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label>ফোন <span className="required">*</span></label>
                    <input 
                      type="tel" 
                      value={profileData.phone} 
                      onChange={(e) => setProfileData({...profileData, phone: e.target.value})} 
                      placeholder="01XXXXXXXXX" 
                    />
                  </div>
                  <div className="form-group">
                    <label>জন্ম তারিখ <span className="required">*</span></label>
                    <input 
                      type="date" 
                      value={profileData.dob} 
                      onChange={(e) => setProfileData({...profileData, dob: e.target.value})} 
                    />
                  </div>
                </div>

                <div className="form-group">
                  <label>ঠিকানা</label>
                  <textarea 
                    value={profileData.address} 
                    onChange={(e) => setProfileData({...profileData, address: e.target.value})} 
                    placeholder="আপনার বর্তমান ঠিকানা" 
                    rows="3" 
                  />
                </div>

                <div className="form-group">
                  <label>বায়ো</label>
                  <textarea 
                    value={profileData.bio} 
                    onChange={(e) => setProfileData({...profileData, bio: e.target.value})} 
                    placeholder="আপনার সম্পর্কে সংক্ষেপে বলুন" 
                    rows="3" 
                    maxLength="500" 
                  />
                  <small>{profileData.bio?.length || 0}/500</small>
                </div>

<div className="form-group">
  <label>দক্ষতা (কমা দিয়ে আলাদা করুন)</label>
  <input 
    type="text" 
    value={Array.isArray(profileData.skills) ? profileData.skills.join(', ') : profileData.skills || ''} 
    onChange={(e) => {
      const skillsArray = e.target.value.split(',').map(s => s.trim()).filter(s => s);
      setProfileData({...profileData, skills: skillsArray});
    }} 
    placeholder="JavaScript, React, Firebase" 
  />
</div>

                <div className="form-group">
                  <label>আপনি কি হিসেবে কাজ করতে চান? <span className="required">*</span></label>
                  <div className="role-selector">
                    <label className={`role-option ${profileData.role === 'client' ? 'active' : ''}`}>
                      <input 
                        type="radio" 
                        value="client" 
                        checked={profileData.role === 'client'} 
                        onChange={() => setProfileData({...profileData, role: 'client'})} 
                      />
                      <i className="fa-solid fa-briefcase"></i>
                      <span>ক্লায়েন্ট</span>
                    </label>
                    <label className={`role-option ${profileData.role === 'freelancer' ? 'active' : ''}`}>
                      <input 
                        type="radio" 
                        value="freelancer" 
                        checked={profileData.role === 'freelancer'} 
                        onChange={() => setProfileData({...profileData, role: 'freelancer'})} 
                      />
                      <i className="fa-solid fa-laptop-code"></i>
                      <span>ফ্রিল্যান্সার</span>
                    </label>
                  </div>
                </div>

                <button className="save-btn" onClick={handleUpdateProfile} disabled={saving}>
                  {saving ? <><i className="fa-solid fa-spinner fa-spin"></i> সংরক্ষণ হচ্ছে...</> : '💾 প্রোফাইল সংরক্ষণ করুন'}
                </button>
              </div>
            </div>
          )}

          {/* ===== ডকুমেন্ট ট্যাব ===== */}
          {activeTab === 'documents' && (
            <div className="settings-section">
              <h2><i className="fa-solid fa-file"></i> ডকুমেন্ট যাচাই</h2>
              <div className="settings-form">
                {docStatus.documentsUploaded ? (
                  <div className="info-box success">
                    <span className="info-icon">✅</span>
                    <div>
                      <strong>ডকুমেন্ট আপলোড সম্পন্ন!</strong>
                      <p>আপনার ডকুমেন্ট অ্যাডমিন দ্বারা যাচাই করা হচ্ছে।</p>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="upload-row">
                      <div className="form-group">
                        <label>NID কার্ড (সামনে) <span className="required">*</span></label>
                        <div className="upload-area" id="nidFrontArea">
                          <input type="file" id="nidFront" accept="image/*" />
                          <div className="upload-default">
                            <div className="upload-icon">🪪</div>
                            <div className="upload-label">সামনের ছবি</div>
                          </div>
                        </div>
                      </div>
                      <div className="form-group">
                        <label>NID কার্ড (পিছনে) <span className="required">*</span></label>
                        <div className="upload-area" id="nidBackArea">
                          <input type="file" id="nidBack" accept="image/*" />
                          <div className="upload-default">
                            <div className="upload-icon">🔄</div>
                            <div className="upload-label">পিছনের ছবি</div>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="form-group">
                      <label>জন্ম নিবন্ধন সনদ</label>
                      <div className="upload-area" id="birthArea">
                        <input type="file" id="birthCert" accept="image/*,application/pdf" />
                        <div className="upload-default">
                          <div className="upload-icon">📄</div>
                          <div className="upload-label">সনদের ছবি বা PDF</div>
                        </div>
                      </div>
                    </div>
                    
                    {uploadingDocs && (
                      <div className="upload-progress">
                        <div className="progress-text">আপলোড হচ্ছে... {Math.round(uploadProgress)}%</div>
                        <div className="progress-bar-small">
                          <div className="progress-fill-small" style={{ width: `${uploadProgress}%` }}></div>
                        </div>
                      </div>
                    )}
                    
                    <button className="save-btn" onClick={uploadDocuments} disabled={uploadingDocs}>
                      {uploadingDocs ? '⏳ আপলোড হচ্ছে...' : '📤 ডকুমেন্ট আপলোড করুন'}
                    </button>
                  </>
                )}
              </div>
            </div>
          )}

          {/* ===== ফেস ভেরিফিকেশন ট্যাব ===== */}
          {activeTab === 'face' && (
            <div className="settings-section">
              <h2><i className="fa-solid fa-camera"></i> মুখমণ্ডল যাচাই</h2>
              <div className="settings-form">
                {docStatus.faceVerified ? (
                  <div className="info-box success">
                    <span className="info-icon">✅</span>
                    <div>
                      <strong>মুখমণ্ডল যাচাই সম্পন্ন!</strong>
                      <p>আপনার ফেস ভেরিফিকেশন সফলভাবে সম্পন্ন হয়েছে।</p>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="liveness-instructions">
                      {livenessState.map((step) => (
                        <div key={step.id} className={`instruction-step ${step.done ? 'done' : ''}`}>
                          <div className="inst-text">{step.label}</div>
                          <div className="inst-status">{step.done ? '✅' : '⬜'}</div>
                        </div>
                      ))}
                    </div>
                    
                    <div className="camera-box" id="cameraBox">
                      <video ref={videoRef} autoPlay muted playsInline></video>
                      <canvas ref={canvasRef}></canvas>
                      <div className="camera-placeholder">
                        <span>📷</span>
                        <div>ক্যামেরা চালু করুন</div>
                      </div>
                    </div>
                    
                    <div className="liveness-progress">
                      <div className="progress-text" id="livenessProgressText">০/৬ সম্পন্ন</div>
                      <div className="progress-bar-small">
                        <div className="progress-fill-small" id="livenessProgressFill" style={{ width: '0%' }}></div>
                      </div>
                    </div>
                    
                    <div className="btn-row">
                      <button className="btn btn-ghost" id="camStartBtn" onClick={startCamera}>📷 ক্যামেরা চালু</button>
                      <button className="btn btn-primary" id="captureBtn" onClick={capturePhoto} style={{ display: 'none' }}>📸 ছবি তুলুন</button>
                      <button className="btn btn-danger" id="camStopBtn" onClick={stopCamera} style={{ display: 'none' }}>⏹ বন্ধ</button>
                    </div>
                  </>
                )}
              </div>
            </div>
          )}

          {/* ===== এক্সপেরিয়েন্স ট্যাব ===== */}
          {activeTab === 'experience' && (
            <div className="settings-section">
              <h2><i className="fa-solid fa-briefcase"></i> অভিজ্ঞতা</h2>
              <div className="settings-form">
                {experience.map(exp => (
                  <div key={exp.id} className="item-card">
                    <div className="item-header">
                      <h4>{exp.role} - {exp.company}</h4>
                      <button className="delete-btn-small" onClick={() => handleDeleteExperience(exp.id)}>
                        <i className="fa-solid fa-trash"></i>
                      </button>
                    </div>
                    <p className="item-date">{exp.startDate} - {exp.endDate || 'বর্তমান'}</p>
                    <p className="item-description">{exp.description}</p>
                  </div>
                ))}
                
                {isEditingExperience ? (
                  <div className="add-form">
                    <input type="text" placeholder="কোম্পানি" value={newExperience.company} onChange={(e) => setNewExperience({...newExperience, company: e.target.value})} />
                    <input type="text" placeholder="পদবি" value={newExperience.role} onChange={(e) => setNewExperience({...newExperience, role: e.target.value})} />
                    <div className="form-row">
                      <input type="text" placeholder="শুরুর তারিখ" value={newExperience.startDate} onChange={(e) => setNewExperience({...newExperience, startDate: e.target.value})} />
                      <input type="text" placeholder="শেষ তারিখ (বা Present)" value={newExperience.endDate} onChange={(e) => setNewExperience({...newExperience, endDate: e.target.value})} />
                    </div>
                    <textarea placeholder="বর্ণনা" value={newExperience.description} onChange={(e) => setNewExperience({...newExperience, description: e.target.value})} rows="2" />
                    <div className="form-actions">
                      <button className="cancel-btn" onClick={() => setIsEditingExperience(false)}>বাতিল</button>
                      <button className="save-btn" onClick={handleAddExperience}>যোগ করুন</button>
                    </div>
                  </div>
                ) : (
                  <button className="add-btn" onClick={() => setIsEditingExperience(true)}>
                    <i className="fa-solid fa-plus"></i> অভিজ্ঞতা যোগ করুন
                  </button>
                )}
              </div>
            </div>
          )}

          {/* ===== এডুকেশন ট্যাব ===== */}
          {activeTab === 'education' && (
            <div className="settings-section">
              <h2><i className="fa-solid fa-graduation-cap"></i> শিক্ষা</h2>
              <div className="settings-form">
                {education.map(edu => (
                  <div key={edu.id} className="item-card">
                    <div className="item-header">
                      <h4>{edu.degree} - {edu.field}</h4>
                      <button className="delete-btn-small" onClick={() => handleDeleteEducation(edu.id)}>
                        <i className="fa-solid fa-trash"></i>
                      </button>
                    </div>
                    <p className="item-institution">{edu.institution}</p>
                    <p className="item-date">{edu.startDate} - {edu.endDate || 'বর্তমান'}</p>
                  </div>
                ))}
                
                {isEditingEducation ? (
                  <div className="add-form">
                    <input type="text" placeholder="প্রতিষ্ঠান" value={newEducation.institution} onChange={(e) => setNewEducation({...newEducation, institution: e.target.value})} />
                    <input type="text" placeholder="ডিগ্রি" value={newEducation.degree} onChange={(e) => setNewEducation({...newEducation, degree: e.target.value})} />
                    <input type="text" placeholder="বিষয়" value={newEducation.field} onChange={(e) => setNewEducation({...newEducation, field: e.target.value})} />
                    <div className="form-row">
                      <input type="text" placeholder="শুরুর তারিখ" value={newEducation.startDate} onChange={(e) => setNewEducation({...newEducation, startDate: e.target.value})} />
                      <input type="text" placeholder="শেষ তারিখ" value={newEducation.endDate} onChange={(e) => setNewEducation({...newEducation, endDate: e.target.value})} />
                    </div>
                    <div className="form-actions">
                      <button className="cancel-btn" onClick={() => setIsEditingEducation(false)}>বাতিল</button>
                      <button className="save-btn" onClick={handleAddEducation}>যোগ করুন</button>
                    </div>
                  </div>
                ) : (
                  <button className="add-btn" onClick={() => setIsEditingEducation(true)}>
                    <i className="fa-solid fa-plus"></i> শিক্ষা যোগ করুন
                  </button>
                )}
              </div>
            </div>
          )}

          {/* ===== সার্টিফিকেশন ট্যাব ===== */}
          {activeTab === 'certifications' && (
            <div className="settings-section">
              <h2><i className="fa-solid fa-award"></i> সার্টিফিকেশন</h2>
              <div className="settings-form">
                {certifications.map(cert => (
                  <div key={cert.id} className="item-card">
                    <div className="item-header">
                      <h4>{cert.name}</h4>
                      <button className="delete-btn-small" onClick={() => handleDeleteCertification(cert.id)}>
                        <i className="fa-solid fa-trash"></i>
                      </button>
                    </div>
                    <p className="item-issuer">ইস্যুকারী: {cert.issuer}</p>
                    <p className="item-date">{cert.date}</p>
                    {cert.link && <a href={cert.link} target="_blank" rel="noopener noreferrer" className="cert-link">🔗 দেখুন</a>}
                  </div>
                ))}
                
                {isEditingCertifications ? (
                  <div className="add-form">
                    <input type="text" placeholder="সার্টিফিকেশন নাম" value={newCertification.name} onChange={(e) => setNewCertification({...newCertification, name: e.target.value})} />
                    <input type="text" placeholder="ইস্যুকারী" value={newCertification.issuer} onChange={(e) => setNewCertification({...newCertification, issuer: e.target.value})} />
                    <input type="text" placeholder="তারিখ" value={newCertification.date} onChange={(e) => setNewCertification({...newCertification, date: e.target.value})} />
                    <input type="url" placeholder="লিংক (ঐচ্ছিক)" value={newCertification.link} onChange={(e) => setNewCertification({...newCertification, link: e.target.value})} />
                    <div className="form-actions">
                      <button className="cancel-btn" onClick={() => setIsEditingCertifications(false)}>বাতিল</button>
                      <button className="save-btn" onClick={handleAddCertification}>যোগ করুন</button>
                    </div>
                  </div>
                ) : (
                  <button className="add-btn" onClick={() => setIsEditingCertifications(true)}>
                    <i className="fa-solid fa-plus"></i> সার্টিফিকেশন যোগ করুন
                  </button>
                )}
              </div>
            </div>
          )}

          {/* ===== সোশ্যাল ট্যাব ===== */}
          {activeTab === 'social' && (
            <div className="settings-section">
              <h2><i className="fa-solid fa-share-nodes"></i> সোশ্যাল লিংক</h2>
              <div className="settings-form">
                <div className="form-group">
                  <label><i className="fa-brands fa-linkedin"></i> LinkedIn</label>
                  <input type="url" placeholder="https://linkedin.com/in/yourprofile" value={socialLinks.linkedin} onChange={(e) => setSocialLinks({...socialLinks, linkedin: e.target.value})} />
                </div>
                <div className="form-group">
                  <label><i className="fa-brands fa-github"></i> GitHub</label>
                  <input type="url" placeholder="https://github.com/yourusername" value={socialLinks.github} onChange={(e) => setSocialLinks({...socialLinks, github: e.target.value})} />
                </div>
                <div className="form-group">
                  <label><i className="fa-solid fa-globe"></i> ওয়েবসাইট</label>
                  <input type="url" placeholder="https://yourwebsite.com" value={socialLinks.website} onChange={(e) => setSocialLinks({...socialLinks, website: e.target.value})} />
                </div>
                <button className="save-btn" onClick={handleSaveSocialLinks} disabled={saving}>
                  {saving ? <><i className="fa-solid fa-spinner fa-spin"></i> সংরক্ষণ হচ্ছে...</> : '💾 সোশ্যাল লিংক সংরক্ষণ করুন'}
                </button>
              </div>
            </div>
          )}

          {/* ===== নিরাপত্তা ট্যাব ===== */}
          {activeTab === 'security' && (
            <div className="settings-section">
              <h2><i className="fa-solid fa-shield"></i> নিরাপত্তা</h2>
              <div className="settings-form">
                <div className="form-group">
                  <label>বর্তমান পাসওয়ার্ড</label>
                  <input type="password" value={securityData.currentPassword} onChange={(e) => setSecurityData({...securityData, currentPassword: e.target.value})} placeholder="বর্তমান পাসওয়ার্ড দিন" />
                </div>
                <div className="form-row">
                  <div className="form-group">
                    <label>নতুন পাসওয়ার্ড</label>
                    <input type="password" value={securityData.newPassword} onChange={(e) => setSecurityData({...securityData, newPassword: e.target.value})} placeholder="নতুন পাসওয়ার্ড দিন" />
                  </div>
                  <div className="form-group">
                    <label>পাসওয়ার্ড নিশ্চিত করুন</label>
                    <input type="password" value={securityData.confirmPassword} onChange={(e) => setSecurityData({...securityData, confirmPassword: e.target.value})} placeholder="নতুন পাসওয়ার্ড পুনরায় দিন" />
                  </div>
                </div>
                <button className="save-btn" onClick={handleChangePassword} disabled={saving || !securityData.currentPassword || !securityData.newPassword}>
                  {saving ? <><i className="fa-solid fa-spinner fa-spin"></i> পরিবর্তন হচ্ছে...</> : '🔑 পাসওয়ার্ড পরিবর্তন করুন'}
                </button>
                
                <div className="security-divider"></div>
                
                <ToggleSwitch 
                  checked={securityData.twoFactorEnabled}
                  onChange={handleTwoFactorToggle}
                  label="দুই-স্তরের যাচাইকরণ (2FA)"
                  description="অতিরিক্ত নিরাপত্তার জন্য 2FA সক্রিয় করুন। লগইন করার সময় আপনাকে পরিচয় যাচাই করতে হবে।"
                  disabled={saving}
                />
              </div>
            </div>
          )}

          {/* ===== নোটিফিকেশন ট্যাব ===== */}
          {activeTab === 'notifications' && (
            <div className="settings-section">
              <h2><i className="fa-solid fa-bell"></i> নোটিফিকেশন</h2>
              <div className="settings-form">
                <ToggleSwitch 
                  checked={notificationSettings.emailNotifications} 
                  onChange={(value) => setNotificationSettings({...notificationSettings, emailNotifications: value})} 
                  label="ইমেইল নোটিফিকেশন" 
                />
                <ToggleSwitch 
                  checked={notificationSettings.pushNotifications} 
                  onChange={(value) => setNotificationSettings({...notificationSettings, pushNotifications: value})} 
                  label="পুশ নোটিফিকেশন" 
                />
                <ToggleSwitch 
                  checked={notificationSettings.dealUpdates} 
                  onChange={(value) => setNotificationSettings({...notificationSettings, dealUpdates: value})} 
                  label="ডিল আপডেট" 
                />
                <ToggleSwitch 
                  checked={notificationSettings.messageNotifications} 
                  onChange={(value) => setNotificationSettings({...notificationSettings, messageNotifications: value})} 
                  label="মেসেজ নোটিফিকেশন" 
                />
                <ToggleSwitch 
                  checked={notificationSettings.marketingEmails} 
                  onChange={(value) => setNotificationSettings({...notificationSettings, marketingEmails: value})} 
                  label="মার্কেটিং ইমেইল" 
                />
                <button className="save-btn" onClick={() => handleSaveSettings('notificationSettings', notificationSettings)} disabled={saving}>
                  {saving ? <><i className="fa-solid fa-spinner fa-spin"></i> সংরক্ষণ হচ্ছে...</> : '💾 নোটিফিকেশন সংরক্ষণ করুন'}
                </button>
              </div>
            </div>
          )}

          {/* ===== প্রাইভেসি ট্যাব ===== */}
          {activeTab === 'privacy' && (
            <div className="settings-section">
              <h2><i className="fa-solid fa-lock"></i> প্রাইভেসি</h2>
              <div className="settings-form">
                <div className="form-group">
                  <label>প্রোফাইল দৃশ্যমানতা</label>
                  <select value={privacySettings.profileVisibility} onChange={(e) => setPrivacySettings({...privacySettings, profileVisibility: e.target.value})}>
                    <option value="public">🌍 পাবলিক - সবাই দেখতে পারে</option>
                    <option value="contacts">👥 কন্টাক্ট - শুধু সংযোগগুলি</option>
                    <option value="private">🔒 প্রাইভেট - শুধু আমি</option>
                  </select>
                </div>
                <ToggleSwitch 
                  checked={privacySettings.showEmail} 
                  onChange={(value) => setPrivacySettings({...privacySettings, showEmail: value})} 
                  label="প্রোফাইলে ইমেইল দেখান" 
                />
                <ToggleSwitch 
                  checked={privacySettings.showPhone} 
                  onChange={(value) => setPrivacySettings({...privacySettings, showPhone: value})} 
                  label="প্রোফাইলে ফোন দেখান" 
                />
                <ToggleSwitch 
                  checked={privacySettings.activityStatus} 
                  onChange={(value) => setPrivacySettings({...privacySettings, activityStatus: value})} 
                  label="অ্যাক্টিভিটি স্ট্যাটাস দেখান" 
                />
                <button className="save-btn" onClick={() => handleSaveSettings('privacySettings', privacySettings)} disabled={saving}>
                  {saving ? <><i className="fa-solid fa-spinner fa-spin"></i> সংরক্ষণ হচ্ছে...</> : '💾 প্রাইভেসি সংরক্ষণ করুন'}
                </button>
              </div>
            </div>
          )}

          {/* ===== পেমেন্ট ট্যাব ===== */}
          {activeTab === 'payment' && (
            <div className="settings-section">
              <h2><i className="fa-solid fa-credit-card"></i> পেমেন্ট সেটিংস</h2>
              <div className="settings-form">
                <div className="form-group">
                  <label>ডিফল্ট মুদ্রা</label>
                  <select value={paymentSettings.defaultCurrency} onChange={(e) => setPaymentSettings({...paymentSettings, defaultCurrency: e.target.value})}>
                    <option value="BDT">BDT - বাংলাদেশি টাকা</option>
                    <option value="USD">USD - US ডলার</option>
                    <option value="EUR">EUR - ইউরো</option>
                    <option value="GBP">GBP - ব্রিটিশ পাউন্ড</option>
                  </select>
                </div>
                <div className="form-group">
                  <label>পেমেন্ট পদ্ধতি</label>
                  <select value={paymentSettings.paymentMethod} onChange={(e) => setPaymentSettings({...paymentSettings, paymentMethod: e.target.value})}>
                    <option value="bank">🏦 ব্যাংক ট্রান্সফার</option>
                    <option value="bKash">📱 bKash</option>
                    <option value="nagad">📱 Nagad</option>
                    <option value="rocket">📱 Rocket</option>
                  </select>
                </div>
                <div className="form-group">
                  <label>ব্যাংকের নাম</label>
                  <input type="text" value={paymentSettings.bankName} onChange={(e) => setPaymentSettings({...paymentSettings, bankName: e.target.value})} placeholder="ব্যাংকের নাম দিন" />
                </div>
                <div className="form-group">
                  <label>অ্যাকাউন্ট হোল্ডারের নাম</label>
                  <input type="text" value={paymentSettings.accountHolder} onChange={(e) => setPaymentSettings({...paymentSettings, accountHolder: e.target.value})} placeholder="অ্যাকাউন্ট হোল্ডারের নাম দিন" />
                </div>
                <div className="form-group">
                  <label>ব্যাংক অ্যাকাউন্ট নম্বর</label>
                  <input type="text" value={paymentSettings.bankAccount} onChange={(e) => setPaymentSettings({...paymentSettings, bankAccount: e.target.value})} placeholder="ব্যাংক অ্যাকাউন্ট নম্বর দিন" />
                </div>
                <button className="save-btn" onClick={() => handleSaveSettings('paymentSettings', paymentSettings)} disabled={saving}>
                  {saving ? <><i className="fa-solid fa-spinner fa-spin"></i> সংরক্ষণ হচ্ছে...</> : '💾 পেমেন্ট সেটিংস সংরক্ষণ করুন'}
                </button>
              </div>
            </div>
          )}

          {/* ===== আমার পোস্ট ট্যাব ===== */}
          {activeTab === 'posts' && (
            <div className="settings-section">
              <h2><i className="fa-solid fa-file-alt"></i> আমার পোস্ট</h2>
              <div className="settings-form">
                {postsLoading ? (
                  <div className="loading-posts"><div className="loading-spinner-small"></div><p>পোস্ট লোড হচ্ছে...</p></div>
                ) : userPosts.length === 0 ? (
                  <div className="no-posts"><i className="fa-solid fa-folder-open"></i><p>আপনি এখনও কোনো পোস্ট তৈরি করেননি।</p></div>
                ) : (
                  <div className="posts-list">
                    {userPosts.map(post => (
                      <div key={post.id} className="post-item">
                        <div className="post-item-info">
                          <h4>{post.title}</h4>
                          <p>{post.description?.substring(0, 80)}...</p>
                          <span className="post-item-meta">৳{post.budget || post.price} BDT · {post.type === 'hire' ? 'জব' : 'সার্ভিস'}</span>
                        </div>
                        <div className="post-item-actions">
                          <button className="edit-btn-small" onClick={() => handleEditPost(post)}>
                            <i className="fa-solid fa-pen"></i>
                          </button>
                          <button className="delete-btn-small" onClick={() => handleDeletePost(post.id)}>
                            <i className="fa-solid fa-trash"></i>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

        </div>
      </div>

      {/* ===== পোস্ট এডিট মোডাল ===== */}
      {editingPost && (
        <div className="modal-overlay" onClick={() => setEditingPost(null)}>
          <div className="edit-modal" onClick={(e) => e.stopPropagation()}>
            <div className="edit-modal-header">
              <h3><i className="fa-solid fa-pen-to-square" style={{ color: '#fbbf24' }}></i> পোস্ট এডিট করুন</h3>
              <button className="modal-close-btn" onClick={() => setEditingPost(null)}>
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>
            <div className="edit-form">
              <div className="form-group">
                <label>শিরোনাম <span className="required">*</span></label>
                <input 
                  type="text" 
                  value={editForm.title} 
                  onChange={(e) => setEditForm({...editForm, title: e.target.value})} 
                  placeholder="পোস্টের শিরোনাম..." 
                  className="edit-input" 
                  maxLength="100" 
                />
                <small className="char-count">{editForm.title?.length || 0}/100</small>
              </div>
              
              <div className="form-group">
                <label>বর্ণনা <span className="required">*</span></label>
                <textarea 
                  value={editForm.description} 
                  onChange={(e) => setEditForm({...editForm, description: e.target.value})} 
                  placeholder="পোস্টের বিবরণ লিখুন..." 
                  rows="4" 
                  className="edit-textarea" 
                  maxLength="2000" 
                />
                <small className="char-count">{editForm.description?.length || 0}/2000</small>
              </div>
              
              <div className="form-row">
                <div className="form-group">
                  <label>বাজেট/মূল্য <span className="required">*</span></label>
                  <div className="input-with-icon">
                    <span className="input-icon">৳</span>
                    <input 
                      type="number" 
                      value={editForm.budget} 
                      onChange={(e) => setEditForm({...editForm, budget: e.target.value})} 
                      placeholder="মূল্য দিন" 
                      className="edit-input with-icon" 
                      min="0" 
                    />
                  </div>
                </div>
                <div className="form-group">
                  <label>ডেলিভারি দিন <span className="required">*</span></label>
                  <div className="input-with-icon">
                    <input 
                      type="number" 
                      value={editForm.deadline} 
                      onChange={(e) => setEditForm({...editForm, deadline: e.target.value})} 
                      placeholder="দিন সংখ্যা" 
                      className="edit-input with-icon" 
                      min="1" 
                    />
                    <span className="input-icon-right">দিন</span>
                  </div>
                </div>
              </div>
              
              <div className="form-group">
                <label>ছবি ({editImagePreviews.length}/2)</label>
                <div className="edit-images-section">
                  {editImagePreviews.length > 0 && (
                    <div className="edit-images-grid">
                      {editImagePreviews.map((img, idx) => (
                        <div key={idx} className="edit-image-item">
                          <img src={img} alt={`Preview ${idx}`} />
                          <button type="button" className="remove-image-btn" onClick={() => handleRemoveEditImage(idx)}>
                            <i className="fa-solid fa-xmark"></i>
                          </button>
                          <div className="image-order-badge">{idx + 1}</div>
                        </div>
                      ))}
                    </div>
                  )}
                  {editImagePreviews.length < 2 && (
                    <div className="upload-drop-zone-small" onClick={() => editFileInputRef.current?.click()}>
                      <i className="fa-solid fa-cloud-arrow-up"></i>
                      <p>ক্লিক করে ছবি যোগ করুন</p>
                      <span>({editImagePreviews.length}/2 ব্যবহৃত)</span>
                    </div>
                  )}
                  <input type="file" ref={editFileInputRef} hidden accept="image/*" onChange={handleEditImageChange} multiple={editImagePreviews.length < 2} />
                </div>
              </div>
              
              <div className="edit-actions">
                <button className="cancel-btn" onClick={() => setEditingPost(null)}>
                  <i className="fa-solid fa-times"></i> বাতিল
                </button>
                <button 
                  className="save-btn" 
                  onClick={handleUpdatePost} 
                  disabled={editImageLoading || !editForm.title.trim() || !editForm.description.trim()}
                >
                  {editImageLoading ? 
                    <><i className="fa-solid fa-spinner fa-spin"></i> আপডেট হচ্ছে...</> : 
                    <><i className="fa-solid fa-check"></i> আপডেট করুন</>
                  }
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

export default Settings;