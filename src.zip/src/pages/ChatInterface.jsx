import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import './ChatInterface.css';

// Helpers - একই ফোল্ডারে (pages)
import { 
  uploadToCloudinary, 
  generateMilestones, 
  formatLastSeen, 
  getInitialsAvatar, 
  formatTime,
  sendProposal,
  approveDeal,
  rejectDeal,
  reopenDeal
} from './chatHelpers';


import { useChatMessages } from './hooks/useChatMessages';
import { useUserStatus } from './hooks/useUserStatus';
import { useDealStatus } from './hooks/useDealStatus';
import { useUserRole } from './hooks/useUserRole';
import { useOnlineStatus } from './hooks/useOnlineStatus';


import ChatHeader from './components/ChatHeader';
import PostDetailCard from './components/PostDetailCard';
import MessageList from './components/MessageList';
import ChatInput from './components/ChatInput';
import BlockedView from './components/BlockedView';
import ProposalModal from './components/ProposalModal';
import EditMessageModal from './components/EditMessageModal';
import ContextMenu from './components/ContextMenu';
import ReplyIndicator from './components/ReplyIndicator';
import ImageZoom from './components/ImageZoom';


const ChatInterface = ({ chatContext, onBack, onConfirm, onCancel, currentUser: propCurrentUser, currentMode }) => {
  const navigate = useNavigate();
  const { currentUser: authUser } = useAuth();
  const currentUser = propCurrentUser || authUser;

  // ========== State ==========
  const [message, setMessage] = useState('');
  const [uploading, setUploading] = useState(false);
  const [showProposalModal, setShowProposalModal] = useState(false);
  const [proposalData, setProposalData] = useState({
    budget: chatContext?.budget || '',
    deadline: chatContext?.deadline || '',
    details: ''
  });
  const [contextMenu, setContextMenu] = useState({ 
    visible: false, x: 0, y: 0, messageId: null, messageText: null, 
    messageImage: null, senderName: null, senderId: null 
  });
  const [replyTo, setReplyTo] = useState(null);
  const [editMessage, setEditMessage] = useState(null);
  const [activeZoomImage, setActiveZoomImage] = useState(null);

  // ========== Refs ==========
  const fileInputRef = useRef(null);
  const contextMenuRef = useRef(null);
  const chatInputRef = useRef(null);

  // ========== Chat ID ==========
  const safeChatId = useMemo(() => {
    if (!chatContext) return null;
    return String(chatContext.id || chatContext.postId || '');
  }, [chatContext]);

  // ========== Custom Hooks ==========
  const { messages, loading, sendMessage: sendMsg, deleteMessage, editMessage: editMsg } = useChatMessages(safeChatId, currentUser);
  const { otherPartyInfo, targetUserInfo, setTargetUserInfo } = useUserStatus(chatContext, currentUser);
  const { existingDeal, isBlocked, blockedBy, isActiveDeal, setIsActiveDeal, setExistingDeal, setIsBlocked, setBlockedBy, unblockUser } = useDealStatus(safeChatId, currentUser);
  const { userRole, postType, isPostOwner, roleLoading } = useUserRole(chatContext, currentUser);
  useOnlineStatus(currentUser);

  // ========== Other Party Info ==========
  const otherPartyId = otherPartyInfo.id;

  // ========== Post Data ==========
  const postData = useMemo(() => {
    const data = chatContext?.fullData || chatContext || {};
    return {
      id: data.id || chatContext?.id || chatContext?.postId || 'unknown',
      title: data.title || data.postTitle || data.jobTitle || chatContext?.title || chatContext?.postTitle || 'No title',
      description: data.description || data.jobDescription || data.details || chatContext?.description || chatContext?.details || 'No description provided',
      budget: Number(data.budget || data.price || chatContext?.budget || chatContext?.price || 0),
      deadline: Number(data.deadline || data.deliveryDays || chatContext?.deadline || chatContext?.deliveryDays || 0),
      image: data.images?.[0] || data.postImage || data.image || data.jobImage || 
             chatContext?.images?.[0] || chatContext?.postImage || chatContext?.image || 
             getInitialsAvatar(data.clientName || chatContext?.clientName || 'User'),
      clientName: data.clientName || data.userName || data.buyerName || 
                   chatContext?.clientName || chatContext?.userName || chatContext?.buyerName || 'Unknown Client',
      userId: data.userId || chatContext?.userId || chatContext?.ownerId,
      buyerId: data.buyerId || chatContext?.buyerId,
      sellerId: data.sellerId || chatContext?.sellerId,
      postType: postType
    };
  }, [chatContext, postType]);

  // ========== Handlers ==========
  const handleSendMessage = async (imageUrl = null) => {
    await sendMsg(message, imageUrl, isBlocked, blockedBy, chatContext, safeChatId);
    if (!imageUrl) setMessage('');
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      alert("File size must be less than 5MB");
      return;
    }
    if (!file.type.startsWith('image/')) {
      alert("Only image files are allowed");
      return;
    }
    setUploading(true);
    try {
      const imageUrl = await uploadToCloudinary(file);
      if (imageUrl) {
        await handleSendMessage(imageUrl);
      } else {
        alert("Failed to upload image. Please try again.");
      }
    } catch (error) {
      console.error("Upload error:", error);
      alert("Failed to upload image.");
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleContextMenu = (e, message) => {
    e.preventDefault();
    setContextMenu({
      visible: true,
      x: e.clientX,
      y: e.clientY,
      messageId: message.id,
      messageText: message.text,
      messageImage: message.imageUrl,
      senderName: message.senderName,
      senderId: message.senderId
    });
  };

  const closeContextMenu = () => {
    setContextMenu({ visible: false, x: 0, y: 0, messageId: null, messageText: null, messageImage: null, senderName: null, senderId: null });
  };

  const handleCopyMessage = () => {
    if (contextMenu.messageText) navigator.clipboard.writeText(contextMenu.messageText);
    else if (contextMenu.messageImage) navigator.clipboard.writeText(contextMenu.messageImage);
    closeContextMenu();
  };

  const handleEditMessage = () => {
    setEditMessage({ id: contextMenu.messageId, text: contextMenu.messageText });
    closeContextMenu();
  };

  const handleDeleteMessage = async () => {
    if (contextMenu.messageId && window.confirm('Are you sure you want to delete this message?')) {
      await deleteMessage(contextMenu.messageId);
    }
    closeContextMenu();
  };

  const handleReplyMessage = () => {
    setReplyTo({
      id: contextMenu.messageId,
      text: contextMenu.messageText,
      senderName: contextMenu.senderName
    });
    closeContextMenu();
    chatInputRef.current?.focus();
  };

  const handleForwardMessage = () => {
    setMessage(`📨 Forwarded: ${contextMenu.messageText}`);
    closeContextMenu();
    chatInputRef.current?.focus();
  };

  const handleUnblock = async () => {
    await unblockUser(targetUserInfo.displayName);
  };

  // ========== Permission Functions ==========
  const canSendOffer = () => {
    if (roleLoading || existingDeal || isActiveDeal) return false;
    if (postType === 'hire') return userRole === 'seller';
    if (postType === 'service') return userRole === 'buyer';
    return false;
  };

  const canApproveDeal = () => {
    if (roleLoading || !existingDeal || existingDeal.status !== 'pending') return false;
    if (postType === 'hire') return userRole === 'buyer';
    if (postType === 'service') return userRole === 'seller';
    return false;
  };

  const getPendingBadgeText = () => {
    if (postType === 'hire') {
      return userRole === 'seller' ? '⏳ Offer Sent - Waiting for Buyer' : '📨 Pending Approval';
    } else {
      return userRole === 'buyer' ? '⏳ Offer Sent - Waiting for Seller' : '📨 Pending Approval';
    }
  };

  // ========== Blocked Views ==========
  if (isBlocked || (blockedBy && blockedBy !== currentUser?.uid)) {
    return (
      <BlockedView 
        isBlocked={isBlocked}
        blockedBy={blockedBy}
        currentUser={currentUser}
        targetUserInfo={targetUserInfo}
        onBack={onBack}
        onUnblock={handleUnblock}
        isActiveDeal={isActiveDeal}
      />
    );
  }

  if (!safeChatId) {
    return (
      <div className="chat-container">
        <div className="chat-header">
          <button className="back-btn" onClick={onBack}><i className="fa-solid fa-arrow-left"></i></button>
          <div className="user-info"><h3>No Chat Selected</h3></div>
        </div>
        <div className="empty-chat-state"><i className="fa-solid fa-comments"></i><p>Select a conversation</p></div>
      </div>
    );
  }

  // ========== Main Render ==========
  return (
    <div className="chat-container">
      {/* Modals */}
      <ProposalModal 
        show={showProposalModal}
        onClose={() => setShowProposalModal(false)}
        proposalData={proposalData}
        setProposalData={setProposalData}
        onSend={async () => {
          // Import sendProposal from chatHelpers
          const { sendProposal } = await import('./chatHelpers');
          await sendProposal(proposalData, chatContext, currentUser, postType, userRole, safeChatId);
          setShowProposalModal(false);
          setExistingDeal({ status: 'pending' });
        }}
      />

      <ImageZoom 
        imageUrl={activeZoomImage}
        onClose={() => setActiveZoomImage(null)}
      />

      <ContextMenu 
        contextMenu={contextMenu}
        contextMenuRef={contextMenuRef}
        onCopy={handleCopyMessage}
        onReply={handleReplyMessage}
        onForward={handleForwardMessage}
        onEdit={handleEditMessage}
        onDelete={handleDeleteMessage}
        isOwnMessage={contextMenu.senderId === currentUser?.uid}
      />

      <EditMessageModal 
        editMessage={editMessage}
        setEditMessage={setEditMessage}
        onSave={async () => {
          if (editMessage && editMessage.text.trim()) {
            await editMsg(editMessage.id, editMessage.text.trim());
            setEditMessage(null);
          }
        }}
      />

      <ReplyIndicator 
        replyTo={replyTo}
        onCancel={() => setReplyTo(null)}
      />

      {/* Header */}
      <ChatHeader 
        targetUserInfo={targetUserInfo}
        otherPartyInfo={otherPartyInfo}
        onBack={onBack}
        isActiveDeal={isActiveDeal}
      />

      {/* Post Detail Card */}
      <PostDetailCard 
        postData={postData}
        onViewPost={() => {
          const postId = chatContext?.id || chatContext?.postId;
          if (postId) {
            sessionStorage.setItem('viewPost', JSON.stringify(postData));
            navigate(`/post/${postId}`);
          }
        }}
        canSendOffer={canSendOffer()}
        onSendOffer={() => setShowProposalModal(true)}
        canApproveDeal={canApproveDeal()}
        onApproveDeal={async () => {
          const { approveDeal } = await import('./chatHelpers');
          await approveDeal(existingDeal, currentUser, safeChatId);
          setExistingDeal({ ...existingDeal, status: 'active' });
          setIsActiveDeal(true);
        }}
        onRejectDeal={async () => {
          const { rejectDeal } = await import('./chatHelpers');
          await rejectDeal(existingDeal, currentUser, safeChatId);
          setExistingDeal({ ...existingDeal, status: 'rejected' });
          setIsActiveDeal(false);
        }}
        onReopenDeal={async () => {
          const { reopenDeal } = await import('./chatHelpers');
          await reopenDeal(existingDeal, currentUser, safeChatId);
          setExistingDeal(prev => ({ ...prev, status: 'pending' }));
          setIsActiveDeal(false);
        }}
        existingDeal={existingDeal}
        getPendingBadgeText={getPendingBadgeText}
      />

      {/* Messages */}
      <MessageList 
        messages={messages}
        currentUserId={currentUser?.uid}
        loading={loading}
        onContextMenu={handleContextMenu}
        onImageClick={setActiveZoomImage}
      />

      {/* Input */}
      <ChatInput 
        message={message}
        setMessage={setMessage}
        onSend={handleSendMessage}
        onKeyDown={handleKeyDown}
        onFileUpload={handleFileUpload}
        fileInputRef={fileInputRef}
        isBlocked={isBlocked}
        blockedBy={blockedBy}
        uploading={uploading}
        inputRef={chatInputRef}
      />

      {uploading && (
        <div className="uploading-indicator">
          <i className="fa-solid fa-spinner fa-spin"></i> Uploading...
        </div>
      )}
    </div>
  );
};

export default ChatInterface;