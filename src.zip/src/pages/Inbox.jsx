import React, { useState, useEffect, useRef } from 'react';
import ChatInterface from './ChatInterface';
import './Inbox.css';

// Import Helpers
import { createNormalizedChatObject } from './inboxHelpers';

// Import Hooks
import { useUserProfiles } from './hooks/useUserProfiles';
import { useInboxChats } from './hooks/useInboxChats';
import { useInboxFilters } from './hooks/useInboxFilters';

// Import Components
import { InboxHeader } from './components/InboxHeader';
import { InboxSearch } from './components/InboxSearch';
import { InboxModeSwitcher } from './components/InboxModeSwitcher';
import { InboxFilterTabs } from './components/InboxFilterTabs';
import { InboxEmptyState } from './components/InboxEmptyState';
import { InboxChatItem } from './components/InboxChatItem';
import { InboxChatMenu } from './components/InboxChatMenu';

const Inbox = ({ chatContext, currentUser }) => {
  // ========== State ==========
  const [currentMode, setCurrentMode] = useState(() => {
    return localStorage.getItem('inboxMode') || 'all';
  });
  const [selectedChat, setSelectedChat] = useState(null);
  const [openMenuChatId, setOpenMenuChatId] = useState(null);
  const [isChatReady, setIsChatReady] = useState(false);

  // ========== Refs ==========
  const menuRef = useRef(null);
  const dotBtnRef = useRef(null);

  // ========== Hooks ==========
  const { 
    userProfiles, 
    fetchUserProfile, 
    getOnlineStatusText, 
    getIsOnline, 
    getDisplayName, 
    getPhotoURL 
  } = useUserProfiles();

  const {
    chats,
    loading,
    isDataReady,
    handleDeleteChat,
    handleBlockUser,
    handleUnblockUser,
    handleSelectChat
  } = useInboxChats(currentUser, currentMode, selectedChat, setSelectedChat, fetchUserProfile, chatContext);

  const {
    activeFilter,
    setActiveFilter,
    searchQuery,
    setSearchQuery,
    filteredChats,
    getUnreadCount
  } = useInboxFilters(chats, currentUser, currentMode);

  // ========== Handlers ==========
  const handleModeChange = (mode) => {
    setCurrentMode(mode);
    localStorage.setItem('inboxMode', mode);
    setSelectedChat(null);
    setIsChatReady(false);
  };

  const toggleMenu = (chatId, e) => {
    if (e) {
      e.stopPropagation();
      e.preventDefault();
    }
    setOpenMenuChatId(prevId => prevId === chatId ? null : chatId);
  };

  const closeMenu = () => setOpenMenuChatId(null);

  // ========== Click Outside Handler ==========
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current?.contains(event.target) || dotBtnRef.current?.contains(event.target)) {
        return;
      }
      setOpenMenuChatId(null);
    };
    
    const handleEscKey = (event) => {
      if (event.key === 'Escape') {
        setOpenMenuChatId(null);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleEscKey);
    
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscKey);
    };
  }, []);

  // ========== Handle Select with Normalization ==========
  const handleSelectChatWithNormalization = async (chat) => {
    closeMenu();
    
    // ✅ ডেটা রেডি না হলে return
    if (!isDataReady) {
      console.log("⏳ Data not ready yet, waiting...");
      return;
    }
    
    // ✅ ইউজার প্রোফাইল ফেচ করুন
    const otherId = chat.participants?.find(p => p !== currentUser?.uid);
    if (otherId) {
      await fetchUserProfile(otherId);
    }
    
    const normalizedChat = createNormalizedChatObject(chat, currentUser);
    if (normalizedChat) {
      handleSelectChat(normalizedChat);
      setIsChatReady(true);
    }
  };

  // ========== Chat Interface Props ==========
  const getChatInterfaceProps = () => {
    if (!selectedChat || !isChatReady) return null;
    
    // ✅ নরমালাইজড ডেটা পাঠান
    return {
      chatContext: selectedChat,
      onBack: () => {
        setSelectedChat(null);
        setIsChatReady(false);
        localStorage.removeItem('activeChat');
      },
      currentUser: currentUser,
      currentMode: currentMode
    };
  };

  // ============================================================
  // ✅ Render
  // ============================================================
  const chatProps = getChatInterfaceProps();

  return (
    <div className={`inbox-page-layout ${selectedChat && isChatReady ? 'chat-active' : ''}`}>
      
      {/* Chat List */}
      <div className="workspace-inbox-wrapper">
        <div className="workspace-inbox">
          <InboxHeader 
            currentMode={currentMode}
            handleModeChange={handleModeChange}
            getUnreadCount={getUnreadCount}
            filteredChats={filteredChats}
          />

          <InboxSearch 
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
          />

          <InboxModeSwitcher 
            currentMode={currentMode}
            handleModeChange={handleModeChange}
            getUnreadCount={getUnreadCount}
            filteredChats={filteredChats}
          />

          <InboxFilterTabs 
            activeFilter={activeFilter}
            setActiveFilter={setActiveFilter}
          />

          <div className="inbox-rows-container">
            <InboxEmptyState 
              loading={loading}
              searchQuery={searchQuery}
              currentMode={currentMode}
              filteredChats={filteredChats}
            />

{/* 
const {
  userProfiles,  // ✅ এইটা ব্যবহার করুন
  fetchUserProfile,
  getOnlineStatusText,
  getIsOnline,
  getDisplayName,
  getPhotoURL
} = useUserProfiles(); */}



{!loading && isDataReady && filteredChats.map((chat) => {
  const isMenuOpen = openMenuChatId === chat.id;
  
  return (
    <div key={chat.id} style={{ position: 'relative' }}>
      <InboxChatItem 
        chat={chat}
        isSelected={selectedChat?.id === chat.id}
        onSelect={handleSelectChatWithNormalization}
        onMenuToggle={toggleMenu}
        isMenuOpen={isMenuOpen}
        menuRef={menuRef}
        dotBtnRef={dotBtnRef}
        getDisplayName={getDisplayName}
        getPhotoURL={getPhotoURL}
        getIsOnline={getIsOnline}
        getOnlineStatusText={getOnlineStatusText}
        currentUser={currentUser}
        userProfiles={userProfiles}  // ✅ এইটা যোগ করুন
      />

      <InboxChatMenu 
        chat={chat}
        isOpen={isMenuOpen}
        onClose={closeMenu}
        onDelete={handleDeleteChat}
        onBlock={handleBlockUser}
        onUnblock={handleUnblockUser}
        menuRef={menuRef}
        dotBtnRef={dotBtnRef}
      />
    </div>
  );
})}
          </div>
        </div>
      </div>

      {/* Chat Interface - শুধু ডেটা রেডি হলে দেখান */}
      <div className="active-chat-area">
        {selectedChat && isChatReady && chatProps ? (
          <ChatInterface {...chatProps} />
        ) : loading ? (
          <div className="no-chat-selected-message">
            <div className="loading-spinner"></div>
            <p>Loading conversation...</p>
          </div>
        ) : (
          <div className="no-chat-selected-message">
            <i className="fa-solid fa-comments" style={{fontSize: '50px', color: '#438e82'}}></i>
            <p>আপনার কনভারসেশন শুরু করতে বাম দিক থেকে একটি জব সিলেক্ট করুন।</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Inbox;