import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { db, auth } from '../firebase';
import { 
  collection, query, where, onSnapshot, orderBy, 
  updateDoc, doc, writeBatch, serverTimestamp, deleteDoc, getDoc
} from 'firebase/firestore';
import NotificationModal from '../components/NotificationModal';
import './Notifications.css';

const Notifications = ({ currentMode: propMode, currentUser, onUnreadCountChange }) => {
  console.log("📌 Notifications component mounted");

  const navigate = useNavigate();

  const [currentMode, setCurrentMode] = useState(() => {
    if (propMode) return propMode;
    return localStorage.getItem('notificationsMode') || 'buyer';
  });
  const [selectedNoti, setSelectedNoti] = useState(null);
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  
  const processedIds = useRef(new Set());
  const prevUnreadCount = useRef(0);
  const isFirstLoad = useRef(true);

  const handleModeChange = (mode) => {
    setCurrentMode(mode);
    localStorage.setItem('notificationsMode', mode);
    processedIds.current.clear();
    isFirstLoad.current = true;
  };

  const formatNotificationTime = (timestamp) => {
    if (!timestamp) return 'Just now';
    try {
      let date;
      if (timestamp.toDate) {
        date = timestamp.toDate();
      } else if (typeof timestamp === 'string') {
        date = new Date(timestamp);
      } else {
        return 'Just now';
      }
      
      const now = new Date();
      const diff = now - date;
      
      if (diff < 60000) return 'Just now';
      if (diff < 3600000) return `${Math.floor(diff / 60000)} minutes ago`;
      if (diff < 86400000) return `${Math.floor(diff / 3600000)} hours ago`;
      if (diff < 604800000) return `${Math.floor(diff / 86400000)} days ago`;
      
      return date.toLocaleDateString();
    } catch (error) {
      console.error("Time format error:", error);
    }
    return 'Just now';
  };

  // ============================================================
  // ✅ সব নোটিফিকেশন টাইপের স্টাইল (সম্পূর্ণ)
  // ============================================================
  const getNotificationStyle = (type) => {
    const styles = {
      // ডিল সম্পর্কিত
      'deal': { icon: 'fa-solid fa-handshake', colorClass: 'noti-project' },
      'new_offer': { icon: 'fa-solid fa-paper-plane', colorClass: 'noti-message' },
      'offer': { icon: 'fa-solid fa-file-invoice', colorClass: 'noti-project' },
      'proposal': { icon: 'fa-solid fa-paper-plane', colorClass: 'noti-message' },
      'bid': { icon: 'fa-solid fa-gavel', colorClass: 'noti-project' },
      'deal_confirmed': { icon: 'fa-solid fa-check-circle', colorClass: 'noti-success' },
      'deal_rejected': { icon: 'fa-solid fa-times-circle', colorClass: 'noti-danger' },
      
      // মাইলস্টোন সম্পর্কিত
      'milestone': { icon: 'fa-solid fa-flag-checkered', colorClass: 'noti-project' },
      'milestone_funded': { icon: 'fa-solid fa-circle-dollar', colorClass: 'noti-payment' },
      'review': { icon: 'fa-solid fa-star', colorClass: 'noti-message' },
      'review_requested': { icon: 'fa-solid fa-star', colorClass: 'noti-message' },
      
      // পেমেন্ট সম্পর্কিত
      'payment': { icon: 'fa-solid fa-money-bill-wave', colorClass: 'noti-payment' },
      'payment_released': { icon: 'fa-solid fa-circle-check', colorClass: 'noti-success' },
      'wallet': { icon: 'fa-solid fa-wallet', colorClass: 'noti-payment' },
      'withdraw': { icon: 'fa-solid fa-arrow-up-right-from-square', colorClass: 'noti-payment' },
      'deposit': { icon: 'fa-solid fa-arrow-down-left', colorClass: 'noti-payment' },
      
      // ক্যানসেলেশন সম্পর্কিত
      'cancellation_request': { icon: 'fa-solid fa-clock', colorClass: 'noti-warning' },
      'cancellation_approved': { icon: 'fa-solid fa-ban', colorClass: 'noti-danger' },
      'cancellation_rejected': { icon: 'fa-solid fa-times', colorClass: 'noti-system' },
      'deal_cancelled': { icon: 'fa-solid fa-ban', colorClass: 'noti-danger' },
      
      // ডেডলাইন সম্পর্কিত
      'deadline_passed': { icon: 'fa-solid fa-clock', colorClass: 'noti-warning' },
      
      // মেসেজ সম্পর্কিত
      'message': { icon: 'fa-solid fa-envelope', colorClass: 'noti-message' },
      
      // ইউজার সম্পর্কিত
      'new_user_registration': { icon: 'fa-solid fa-user-plus', colorClass: 'noti-system' },
      'pending_verification': { icon: 'fa-solid fa-hourglass-half', colorClass: 'noti-warning' },
      
      // সিস্টেম
      'system': { icon: 'fa-solid fa-bell', colorClass: 'noti-system' },
    };
    return styles[type] || styles['system'];
  };

  // ============================================================
  // ✅ নোটিফিকেশন টাইটেল জেনারেটর
  // ============================================================
  const getNotificationTitle = (type, data) => {
    const titles = {
      'deal': '🤝 Deal Update',
      'new_offer': '📩 New Offer Received',
      'offer': '📄 Offer Update',
      'proposal': '📩 Proposal Update',
      'bid': '💰 Bid Received',
      'deal_confirmed': '✅ Deal Confirmed!',
      'deal_rejected': '❌ Offer Rejected',
      'milestone': '📌 Milestone Update',
      'milestone_funded': '💰 Milestone Funded',
      'review': '⭐ Review Update',
      'review_requested': '📝 Review Requested',
      'payment': '💳 Payment Update',
      'payment_released': '✅ Payment Released',
      'wallet': '💰 Wallet Update',
      'withdraw': '💳 Withdrawal Request',
      'deposit': '💰 Deposit Received',
      'cancellation_request': '⚠️ Cancellation Request',
      'cancellation_approved': '✅ Deal Cancelled',
      'cancellation_rejected': '❌ Cancellation Rejected',
      'deal_cancelled': '❌ Deal Cancelled',
      'deadline_passed': '⏰ Deadline Passed',
      'message': '💬 New Message',
      'new_user_registration': '👤 New User Registered',
      'pending_verification': '⏳ Verification Pending',
      'system': '📢 System Notification'
    };
    return titles[type] || '📢 Notification';
  };

  // ============================================================
  // 🔥 Firebase থেকে নোটিফিকেশন লোড করা (ফিক্সড)
  // ============================================================
useEffect(() => {
  const userId = currentUser?.uid;
  
  if (!userId) {
    setLoading(false);
    return;
  }

  setLoading(true);
  const notiRef = collection(db, 'notifications');
  
  // কুয়েরি থেকে 'in' ফিল্টারটি আপাতত সরিয়ে দিলাম যেন সব নোটিফিকেশন আসে
  // এটি ডাটাবেসে আপনার সব নোটিফিকেশন দেখতে সাহায্য করবে
  const q = query(
    notiRef, 
    where('userId', '==', userId),
    orderBy('createdAt', 'desc')
  );

  let isMounted = true;

  const unsubscribe = onSnapshot(q, 
    (snapshot) => {
      if (!isMounted) return;
      
      console.log("📊 Total docs found:", snapshot.docs.length);
      
      const notificationsData = snapshot.docs.map(doc => {
        const data = doc.data();
        const style = getNotificationStyle(data.type);
        
        // টাইপ যদি লিস্টে নাও থাকে, তবুও যেন এরর না দেয়
        const title = data.title || getNotificationTitle(data.type, data);
        
        return {
          id: doc.id,
          ...data,
          title: title,
          time: formatNotificationTime(data.createdAt),
          icon: data.icon || style.icon || 'fa-solid fa-bell',
          colorClass: data.colorClass || style.colorClass || 'noti-system',
          isUnread: data.isUnread === true || data.isRead === false,
        };
      });
      
      setNotifications(notificationsData);
      
      const unreadCount = notificationsData.filter(n => n.isUnread).length;
      if (typeof onUnreadCountChange === 'function') {
        onUnreadCountChange(unreadCount);
      }
      
      setLoading(false);
    },
    (error) => {
      console.error("❌ Firebase Error:", error);
      setLoading(false);
    }
  );

  return () => {
    isMounted = false;
    unsubscribe();
  };
}, [currentUser?.uid, onUnreadCountChange]);
  // ============================================================
  // 🗑️ সিঙ্গেল নোটিফিকেশন ডিলিট
  // ============================================================
  const handleDeleteNotification = async (id, event) => {
    event.stopPropagation();
    
    const confirmDelete = window.confirm('Are you sure you want to delete this notification?');
    if (!confirmDelete) return;
    
    try {
      const notiRef = doc(db, 'notifications', id);
      await deleteDoc(notiRef);
      console.log("🗑️ Deleted notification:", id);
      
      setNotifications(prev => {
        const updated = prev.filter(n => n.id !== id);
        const newUnreadCount = updated.filter(n => n.isUnread === true).length;
        prevUnreadCount.current = newUnreadCount;
        if (typeof onUnreadCountChange === 'function') {
          onUnreadCountChange(newUnreadCount);
        }
        return updated;
      });
      
    } catch (error) {
      console.error("Error deleting notification:", error);
      alert('Failed to delete notification');
    }
  };

  // ============================================================
  // 🗑️ সব নোটিফিকেশন ডিলিট
  // ============================================================
  const handleClearAllNotifications = async () => {
    if (notifications.length === 0) return;
    
    const confirmClear = window.confirm('Are you sure you want to delete ALL notifications? This cannot be undone!');
    if (!confirmClear) return;
    
    try {
      const batch = writeBatch(db);
      notifications.forEach(noti => {
        const notiRef = doc(db, 'notifications', noti.id);
        batch.delete(notiRef);
      });
      
      await batch.commit();
      
      setNotifications([]);
      prevUnreadCount.current = 0;
      if (typeof onUnreadCountChange === 'function') {
        onUnreadCountChange(0);
      }
    } catch (error) {
      console.error("Error clearing notifications:", error);
      alert('Failed to clear notifications');
    }
  };

  // ============================================================
  // সব নোটিফিকেশন রিড করা
  // ============================================================
  const markAllAsRead = async () => {
    if (notifications.length === 0) return;
    
    const unreadNotifications = notifications.filter(n => n.isUnread === true);
    if (unreadNotifications.length === 0) {
      alert('No unread notifications!');
      return;
    }
    
    try {
      const batch = writeBatch(db);
      
      unreadNotifications.forEach(noti => {
        const notiRef = doc(db, 'notifications', noti.id);
        batch.update(notiRef, { 
          isUnread: false,
          readAt: serverTimestamp()
        });
      });
      
      await batch.commit();
      console.log(`✅ Marked ${unreadNotifications.length} as read`);
      
      setNotifications(prev => 
        prev.map(n => ({
          ...n,
          isUnread: false
        }))
      );
      
      prevUnreadCount.current = 0;
      if (typeof onUnreadCountChange === 'function') {
        onUnreadCountChange(0);
      }
      
    } catch (error) {
      console.error("Error marking all as read:", error);
      alert('Failed to mark as read');
    }
  };

  // ============================================================
  // সিঙ্গেল নোটিফিকেশন রিড করা
  // ============================================================
  const toggleReadStatus = async (id) => {
    try {
      const notiRef = doc(db, 'notifications', id);
      await updateDoc(notiRef, { 
        isUnread: false,
        readAt: serverTimestamp()
      });
      console.log("✅ Marked as read:", id);
      
      setNotifications(prev => 
        prev.map(n => 
          n.id === id ? { ...n, isUnread: false } : n
        )
      );
      
      const newUnreadCount = notifications.filter(n => n.isUnread === true && n.id !== id).length;
      prevUnreadCount.current = newUnreadCount;
      if (typeof onUnreadCountChange === 'function') {
        onUnreadCountChange(newUnreadCount);
      }
      
    } catch (error) {
      console.error("Error toggling read status:", error);
    }
  };

  // ============================================================
  // ✅ নোটিফিকেশন ক্লিক হ্যান্ডলার (সম্পূর্ণ)
  // ============================================================
  const handleNotificationClick = async (noti) => {
    console.log("🖱️ Notification clicked:", noti);


    if (noti.type === 'system' || noti.type === 'info' || noti.type === 'success') {
    setSelectedNoti(noti); // মোডাল ওপেন হবে
    if (noti.isUnread) await toggleReadStatus(noti.id);
    return;
  }
    
    if (noti.isUnread) {
      await toggleReadStatus(noti.id);
    }
    
    // ✅ ক্যানসেলেশন রেসপন্স
    if (noti.type === 'cancellation_request' || noti.type === 'cancellation_approved' || noti.type === 'cancellation_rejected') {
      if (noti.dealId) {
        navigate(`/deal-manager?dealId=${noti.dealId}`);
      } else {
        navigate('/deal-manager');
      }
      return;
    }
    
    // ✅ ডেডলাইন
    if (noti.type === 'deadline_passed') {
      if (noti.dealId) {
        navigate(`/deal-manager?dealId=${noti.dealId}`);
      } else {
        navigate('/deal-manager');
      }
      return;
    }
    
    // ✅ ডিল কনফার্ম/রিজেক্ট
    if (noti.type === 'deal_confirmed' || noti.type === 'deal_rejected') {
      if (noti.dealId) {
        navigate(`/deal-manager?dealId=${noti.dealId}`);
      } else {
        navigate('/deal-manager');
      }
      return;
    }
    
    // ✅ পেমেন্ট
    if (['payment', 'wallet', 'deposit', 'withdraw', 'payment_released', 'milestone_funded'].includes(noti.type)) {
      navigate('/wallet');
      return;
    }
    
    // ✅ মেসেজ/অফার/প্রপোজাল
    if (noti.type === 'message' || noti.type === 'new_offer' || noti.type === 'proposal' || noti.type === 'bid') {
      if (noti.chatId) {
        navigate(`/inbox?chatId=${noti.chatId}`);
      } else if (noti.dealId) {
        navigate(`/inbox?dealId=${noti.dealId}`);
      } else {
        navigate('/inbox');
      }
      return;
    }
    
    // ✅ ডিল আইডি থাকলে
    if (noti.dealId) {
      navigate(`/deal-manager?dealId=${noti.dealId}`);
      return;
    }
    
    // ✅ পোস্ট আইডি থাকলে
    if (noti.postId) {
      navigate(`/post/${noti.postId}`);
      return;
    }
    
    // ✅ লিংক থাকলে
    if (noti.link) {
      navigate(noti.link);
      return;
    }
    
    // ✅ ডিফল্ট
    navigate('/');
  };

  const unreadCount = notifications.filter(n => n.isUnread === true).length;

  // ============================================================
  // লোডিং স্টেট
  // ============================================================
  if (loading) {
    return (
      <div className="notifications-container-wrapper">
        <div className="notifications-panel">
          <div className="loading-state">
            <div className="loading-spinner"></div>
            <p>Loading notifications...</p>
          </div>
        </div>
      </div>
    );
  }

  // ============================================================
  // রেন্ডার
  // ============================================================
  return (
    <div className="notifications-container-wrapper">
      <div className="notifications-panel">
        
        {/* Mode Switcher */}
        <div className="notif-mode-switcher">
          <button 
            className={`mode-switch-btn ${currentMode === 'buyer' ? 'active' : ''}`}
            onClick={() => handleModeChange('buyer')}
          >
            <i className="fa-solid fa-briefcase"></i> Buyer Mode
            {currentMode === 'buyer' && unreadCount > 0 && (
              <span className="mode-badge-count">{unreadCount}</span>
            )}
          </button>
          <button 
            className={`mode-switch-btn ${currentMode === 'seller' ? 'active' : ''}`}
            onClick={() => handleModeChange('seller')}
          >
            <i className="fa-solid fa-laptop-code"></i> Seller Mode
            {currentMode === 'seller' && unreadCount > 0 && (
              <span className="mode-badge-count">{unreadCount}</span>
            )}
          </button>
        </div>

        {/* Header */}
        <div className="noti-header">
          <div className="noti-header-left">
            <h2><i className="fa-solid fa-bell"></i> Notifications</h2>
            {unreadCount > 0 && (
              <span className="noti-count-badge">{unreadCount} New</span>
            )}
          </div>
          
          <div className="noti-header-right">
            {unreadCount > 0 && (
              <button className="mark-all-btn" onClick={markAllAsRead}>
                <i className="fa-solid fa-check-double"></i> Read All
              </button>
            )}
            {notifications.length > 0 && (
              <button className="clear-all-btn" onClick={handleClearAllNotifications}>
                <i className="fa-solid fa-trash"></i> Clear All
              </button>
            )}
          </div>
        </div>

        {/* Notifications List */}
        <div className="noti-list-body">
          {notifications.length > 0 ? (
            notifications.map((noti) => (
              <div 
                key={noti.id} 
                className={`noti-item-card ${noti.isUnread ? 'unread-noti' : 'read-noti'}`}
                onClick={() => handleNotificationClick(noti)}
              >
                <div className={`noti-icon-box ${noti.colorClass || 'noti-system'}`}>
                  <i className={noti.icon || 'fa-solid fa-bell'}></i>
                </div>

                <div className="noti-content-block">
                  <div className="noti-top-line">
                    <h4>{noti.title || 'Notification'}</h4>
                    <span className="noti-time">{noti.time}</span>
                  </div>
                  <p className="noti-message">{noti.message}</p>
                  {noti.actionRequired && (
                    <div className="noti-action-badge">
                      <i className="fa-solid fa-exclamation-circle"></i> Action Required
                    </div>
                  )}
                </div>

                {/* 🗑️ ডিলিট বাটন */}
                <button 
                  className="noti-delete-btn"
                  onClick={(e) => handleDeleteNotification(noti.id, e)}
                  title="Delete notification"
                >
                  <i className="fa-solid fa-xmark"></i>
                </button>

                {noti.isUnread && <div className="noti-unread-dot"></div>}
              </div>
            ))
          ) : (
            <div className="no-noti-notice">
              <i className="fa-solid fa-bell-slash"></i>
              <p>
                {currentMode === 'buyer' 
                  ? 'No buyer notifications yet' 
                  : 'No seller notifications yet'}
              </p>
              <span>All your notifications will appear here</span>
            </div>
          )}
        </div>

      </div>

      {selectedNoti && (
      <NotificationModal 
        notification={selectedNoti} 
        onClose={() => setSelectedNoti(null)} 
      />
    )}

    </div>
  );
};

export default Notifications;