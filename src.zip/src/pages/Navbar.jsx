import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import PostJobBox from './PostJobBox';
import PostServiceBox from './PostServiceBox';
import './Navbar.css';

const Navbar = ({ 
  children, 
  currentMode, 
  setCurrentMode, 
  onLogout, 
  activeTab, 
  setActiveTab, 
  onSilentPost, 
  currentUser, 
  totalUnread,
  totalDeals,
  unreadNotifications = 0,
  onSearch,
  searchQuery: propSearchQuery,
  searchResults: propSearchResults
}) => {
  
  const navigate = useNavigate();
  const location = useLocation();
  
  // ✅ useMemo ব্যবহার করে userData optimize করুন
  const userData = useMemo(() => ({
    name: currentUser?.displayName || "User",
    badge: "Verified Elite",
    walletBalance: "",
    photoURL: currentUser?.photoURL || ""
  }), [currentUser]);
  
  const [showDesktopMenu, setShowDesktopMenu] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [showModeSwitcher, setShowModeSwitcher] = useState(false);
  const [showPostModal, setShowPostModal] = useState(false);
  const [showHeader, setShowHeader] = useState(true);
  const lastScrollY = useRef(0);
  
  const desktopMenuRef = useRef(null);
  const mobileMenuRef = useRef(null);
  const modeSwitcherRef = useRef(null);
  const searchRef = useRef(null);
  
  const [isDark, setIsDark] = useState(() => {
    const savedTheme = localStorage.getItem('theme');
    return savedTheme !== 'light';
  });

  const toggleTheme = () => {
    const newMode = !isDark;
    setIsDark(newMode);
    
    if (!newMode) {
      document.documentElement.classList.add('light-mode');
      document.documentElement.classList.remove('dark-mode');
      localStorage.setItem('theme', 'light');
    } else {
      document.documentElement.classList.add('dark-mode');
      document.documentElement.classList.remove('light-mode');
      localStorage.setItem('theme', 'dark');
    }
  };

  const [localSearchQuery, setLocalSearchQuery] = useState(propSearchQuery || '');
  const [showSearchResults, setShowSearchResults] = useState(false);
  const [searchResults, setSearchResults] = useState([]);

  const [isAdmin, setIsAdmin] = useState(false);
  const isHomePage = location.pathname === '/' || location.pathname.startsWith('/post/');

  const highlightText = (text, searchTerm) => {
    if (!searchTerm || !text || searchTerm.trim() === '') return text;
    try {
      const regex = new RegExp(`(${searchTerm.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
      const parts = text.split(regex);
      return parts.map((part, index) => 
        regex.test(part) ? 
          <mark key={index} className="search-highlight">{part}</mark> : 
          part
      );
    } catch (error) {
      return text;
    }
  };

  // ✅ Admin চেক
  useEffect(() => {
    const checkAdmin = () => {
      const adminEmails = ['hammanmusa362@gmail.com', 'hasanmahmudmd362@gmail.com'];
      if (currentUser && adminEmails.includes(currentUser.email)) {
        setIsAdmin(true);
      } else {
        setIsAdmin(false);
      }
    };
    checkAdmin();
  }, [currentUser]);

  useEffect(() => {
    setLocalSearchQuery(propSearchQuery || '');
  }, [propSearchQuery]);

  useEffect(() => {
    if (propSearchResults) {
      setSearchResults(propSearchResults);
    }
  }, [propSearchResults]);

  useEffect(() => {
    const path = location.pathname;
    if (path === '/') setActiveTab('dashboard');
    else if (path === '/inbox') setActiveTab('messages');
    else if (path === '/deal-manager') setActiveTab('jobs');
    else if (path === '/notifications') setActiveTab('notifications');
    else if (path === '/profile') setActiveTab('profile');
    else if (path === '/saved-jobs') setActiveTab('saved-jobs');
  }, [location.pathname, setActiveTab]);

  // ============================================================
  // 🎯 ড্রপডাউন ক্লোজ
  // ============================================================
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (desktopMenuRef.current && !desktopMenuRef.current.contains(event.target)) {
        const isDesktopBtn = event.target.closest('.dock-item')?.querySelector('.fa-user-gear');
        if (!isDesktopBtn) {
          setShowDesktopMenu(false);
        }
      }
      
      if (mobileMenuRef.current && !mobileMenuRef.current.contains(event.target)) {
        const isMobileBtn = event.target.closest('.cb-item')?.querySelector('.fa-user-gear');
        if (!isMobileBtn) {
          setShowMobileMenu(false);
        }
      }
      
      if (modeSwitcherRef.current && !modeSwitcherRef.current.contains(event.target)) {
        setShowModeSwitcher(false);
      }
      
      if (searchRef.current && !searchRef.current.contains(event.target)) {
        setShowSearchResults(false);
      }
    };

    const handleEscKey = (event) => {
      if (event.key === 'Escape') {
        setShowDesktopMenu(false);
        setShowMobileMenu(false);
        setShowModeSwitcher(false);
        setShowSearchResults(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleEscKey);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscKey);
    };
  }, []);

  // ============================================================
  // স্ক্রল হ্যান্ডলার
  // ============================================================
  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      if (currentScrollY < 10) {
        setShowHeader(true);
        return;
      }
      if (currentScrollY > lastScrollY.current) {
        setShowHeader(false);
      } else {
        setShowHeader(true);
      }
      lastScrollY.current = currentScrollY;
    };

    window.addEventListener('scroll', handleScroll, { passive: true });

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  // ============================================================
  // 🔥 ড্রপডাউন টগল
  // ============================================================
  const toggleDesktopMenu = (e) => {
    if (e) {
      e.stopPropagation();
      e.preventDefault();
    }
    setShowDesktopMenu(!showDesktopMenu);
  };

  const toggleMobileMenu = (e) => {
    if (e) {
      e.stopPropagation();
      e.preventDefault();
    }
    setShowMobileMenu(!showMobileMenu);
  };

  const toggleDropdown = (dropdownType, e) => {
    if (e) {
      e.stopPropagation();
      e.preventDefault();
    }
    
    setShowDesktopMenu(false);
    setShowMobileMenu(false);
    setShowModeSwitcher(false);
    setShowSearchResults(false);
    
    if (dropdownType === 'mode') {
      setShowModeSwitcher(prev => !prev);
    }
  };

  // ============================================================
  // সার্চ হ্যান্ডলার
  // ============================================================
  const handleSearch = (e) => {
    const value = e.target.value;
    setLocalSearchQuery(value);
    if (onSearch) onSearch(value);
    if (value.trim().length > 0) {
      setShowSearchResults(true);
    } else {
      setSearchResults([]);
      setShowSearchResults(false);
    }
  };

  const handleSearchKeyDown = (e) => {
    if (e.key === 'Enter' && localSearchQuery.trim()) {
      setShowSearchResults(false);
      navigate(`/search?q=${encodeURIComponent(localSearchQuery)}`);
    }
  };

  const handleSearchResultClick = (result) => {
    setLocalSearchQuery('');
    setShowSearchResults(false);
    if (onSearch) onSearch('');
    navigate(`/post/${result.id}`);
  };

  const handleModeSwitch = (e, mode) => {
    e.stopPropagation();
    setCurrentMode(mode);
    setShowModeSwitcher(false);
    localStorage.setItem('currentMode', mode);
  };

  const handleLogoutClick = (e) => {
    e.preventDefault();
    setShowDesktopMenu(false);
    setShowMobileMenu(false);
    if (onLogout) onLogout();
    navigate('/login');
  };

  // ==========================================
  // 📌 নেভিগেশন
  // ==========================================
  const handleNavigate = (path, tab) => {
    setActiveTab(tab);
    setShowDesktopMenu(false);
    setShowMobileMenu(false);
    setShowModeSwitcher(false);
    setShowSearchResults(false);
    navigate(path);
  };

  const handleWalletNavigate = () => {
    setShowDesktopMenu(false);
    setShowMobileMenu(false);
    setShowModeSwitcher(false);
    setShowSearchResults(false);
    navigate('/wallet');
  };

  const handleSettingsNavigate = () => {
    setShowDesktopMenu(false);
    setShowMobileMenu(false);
    setShowModeSwitcher(false);
    setShowSearchResults(false);
    navigate('/settings');
  };

  // ==========================================
  // 📌 Settings ড্রপডাউন
  // ==========================================
  const renderSettingsDropdown = () => (
    <div className="settings-dropdown">
      <button onClick={() => handleNavigate('/profile', 'profile')} className="drop-item">
        <div className="item-left">
          <i className="fa-solid fa-circle-user"></i>
          <span>My Profile</span>
        </div>
      </button>

      <button onClick={() => handleNavigate('/saved-jobs', 'saved-jobs')} className="drop-item">
        <div className="item-left">
          <i className="fa-solid fa-bookmark"></i>
          <span>Saved Jobs</span>
        </div>
      </button>

      <button onClick={handleWalletNavigate} className="drop-item wallet-highlight-row">
        <div className="item-left">
          <i className="fa-solid fa-wallet"></i>
          <span>My Wallet</span>
        </div>
        <span className="badge-usdt">{userData?.walletBalance || '$0'}</span>
      </button>

      {isAdmin && (
        <button onClick={() => handleNavigate('/admin', 'admin')} className="drop-item">
          <div className="item-left">
            <i className="fa-solid fa-shield-haltered"></i>
            <span>Admin Dashboard</span>
          </div>
        </button>
      )}

      <div className="drop-divider"></div>

      <button onClick={handleSettingsNavigate} className="drop-item">
        <div className="item-left">
          <i className="fa-solid fa-sliders"></i>
          <span>Settings</span>
        </div>
        <i className="fa-solid fa-chevron-right"></i>
      </button>

      {/* ✅ থিম টগল */}
      <button onClick={toggleTheme} className="drop-item">
        <div className="item-left">
          <i className={`fa-solid ${isDark ? 'fa-sun' : 'fa-moon'}`}></i>
          <span>{isDark ? 'Light Mode' : 'Dark Mode'}</span>
        </div>
        <span className="theme-toggle-indicator">
          {isDark ? '🌙' : '☀️'}
        </span>
      </button>

      <div className="drop-divider"></div>

      <button onClick={handleLogoutClick} className="drop-item logout-action">
        <div className="item-left">
          <i className="fa-solid fa-power-off"></i>
          <span>Log Out</span>
        </div>
      </button>
    </div>
  );

  return (
    <div className="dark-cyber-theme-container">
      
      {/* ডেস্কটপ সাইড বার */}
      <div className="cyber-side-dock">
        <div className="dock-logo" aria-label="Logo">
          <i className="fa-solid fa-cube"></i>
        </div>
        
        <nav className="dock-menu" aria-label="Desktop Navigation">
          <button className={`cb-item ${activeTab === 'dashboard' ? 'active' : ''}`} onClick={() => handleNavigate('/', 'dashboard')}>
            <i className="fa-solid fa-border-all"></i>
          </button>

                  <button className={`cb-item ${activeTab === 'messages' ? 'active' : ''}`} onClick={() => handleNavigate('/inbox', 'messages')}>
          <i className="fa-solid fa-paper-plane"></i>
          {totalUnread > 0 && <span className="unread-badge bottom">{totalUnread}</span>}
        </button>
          
          <button 
            className={`dock-item ${activeTab === 'jobs' ? 'active' : ''}`}
            onClick={() => handleNavigate('/deal-manager', 'jobs')}
          >
            <i className="fa-solid fa-briefcase"></i>
            {totalDeals > 0 && (
              <span className="unread-badge">{totalDeals}</span>
            )}
          </button>
          
          <button className={`cb-item ${activeTab === 'notifications' ? 'active' : ''}`} onClick={() => handleNavigate('/notifications', 'notifications')}>
            <i className="fa-solid fa-bell"></i>
            {unreadNotifications > 0 && (
              <span className="unread-badge bottom">{unreadNotifications}</span>
            )}
          </button>
          
          <button 
            className={`dock-item ${showDesktopMenu ? 'active-trigger' : ''}`} 
            onClick={toggleDesktopMenu}
          >
            <i className="fa-solid fa-user-gear"></i>
          </button>
        </nav>
        
        <div 
          className={`minimal-dropdown desktop-dropdown-pos ${showDesktopMenu ? 'show' : ''}`} 
          ref={desktopMenuRef}
          onClick={(e) => e.stopPropagation()}
        >
          <div className="drop-header">
            <div className="avatar-glow">
              {userData?.photoURL ? (
                <img 
                  src={userData.photoURL} 
                  alt="Profile" 
                  className="avatar-img"
                  key={userData.photoURL}
                  onError={(e) => {
                    e.target.src = '';
                    e.target.style.display = 'none';
                  }}
                />
              ) : (
                <i className="fa-solid fa-user-gear"></i>
              )}
            </div>
            <div className="user-meta">
              <h4>{userData?.name || 'User'}</h4>
              <p>{userData?.badge}</p>
            </div>
          </div>
          {renderSettingsDropdown()}
        </div>
      </div>

      <div className="content-container-wrapper">
        
        {isHomePage && (
          <header className={`floating-utility-hub ${showHeader ? 'header-visible' : 'header-hidden'}`}>
            
            <div 
              className={`page-intent-title ${showModeSwitcher ? 'active' : ''}`} 
              ref={modeSwitcherRef}
              onClick={(e) => {
                e.stopPropagation();
                toggleDropdown('mode', e);
              }}
            >
              <div className="title-flex-trigger">
                <h1>{currentMode === 'freelancer' ? 'Marketplace (Gigs)' : 'Job Board'}</h1>
                <i className="fa-solid fa-chevron-down"></i>
              </div>
              
              <div className={`mode-switcher-dropdown ${showModeSwitcher ? 'show' : ''}`}>
                <div className={`mode-opt ${currentMode === 'freelancer' ? 'selected' : ''}`} onClick={(e) => handleModeSwitch(e, 'freelancer')}>
                  <i className="fa-solid fa-laptop-code"></i>
                  <div className="opt-meta">Seller Mode</div>
                </div>
                <div className={`mode-opt ${currentMode === 'buyer' ? 'selected' : ''}`} onClick={(e) => handleModeSwitch(e, 'buyer')}>
                  <i className="fa-solid fa-briefcase"></i>
                  <div className="opt-meta">Buying Mode</div>
                </div>
              </div>
            </div>
            
            <div className="search-container" ref={searchRef}>
              <div className="search-pill">
                <i className="fa-solid fa-magnifying-glass"></i>
                <input 
                  type="text" 
                  placeholder="Search workers or hubs..." 
                  value={localSearchQuery}
                  onChange={handleSearch}
                  onKeyDown={handleSearchKeyDown}
                  onFocus={() => localSearchQuery.trim() && setShowSearchResults(true)}
                />
              </div>
              
              {showSearchResults && searchResults.length > 0 && (
                <div className="search-results-dropdown">
                  {searchResults.map((result) => (
                    <div key={result.id} className="search-result-item" onClick={() => handleSearchResultClick(result)}>
                      <div className="result-icon">
                        <i className={result.type === 'job' || result.type === 'hire' ? 'fa-solid fa-briefcase' : 'fa-solid fa-laptop-code'}></i>
                      </div>
                      <div className="result-info">
                        <h4>{highlightText(result.title || result.name, localSearchQuery)}</h4>
                        <p>{highlightText(result.category || (result.type === 'job' || result.type === 'hire' ? 'Job' : 'Service'), localSearchQuery)}</p>
                      </div>
                      <div className="result-badge">
                        <span className={result.type === 'job' || result.type === 'hire' ? 'badge-job' : 'badge-service'}>
                          {result.type === 'job' || result.type === 'hire' ? 'Job' : 'Service'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </header>
        )}

        <main className="content-body-real">
          {children} 
        </main>

        {/* মোবাইল ড্রপডাউন */}
        <div 
          className={`minimal-dropdown mobile-dropdown-pos ${showMobileMenu ? 'show' : ''}`} 
          ref={mobileMenuRef}
          onClick={(e) => e.stopPropagation()}
        >
          <div className="drop-header">
            <div className="avatar-glow">
              {userData?.photoURL ? (
                <img 
                  src={userData.photoURL} 
                  alt="Profile" 
                  className="avatar-img"
                  key={userData.photoURL}
                  onError={(e) => {
                    e.target.src = '';
                    e.target.style.display = 'none';
                  }}
                />
              ) : (
                <i className="fa-solid fa-user-gear"></i>
              )}
            </div>
            <div className="user-meta">
              <h4>{userData?.name || 'User'}</h4>
              <p>{userData?.badge}</p>
            </div>
          </div>
          {renderSettingsDropdown()}
        </div>
      </div>

      {/* প্লাস আইকন */}
      {isHomePage && (
        <button className="global-floating-fab" onClick={() => setShowPostModal(true)}>
          <i className={currentMode === 'freelancer' ? "fa-solid fa-plus" : "fa-solid fa-briefcase"}></i>
        </button>
      )}

      {/* মোবাইল বটম বার */}
      <nav className="cyber-bottom-bar">
        <button className={`cb-item ${activeTab === 'dashboard' ? 'active' : ''}`} onClick={() => handleNavigate('/', 'dashboard')}>
          <i className="fa-solid fa-border-all"></i>
        </button>

        <button className={`cb-item ${activeTab === 'messages' ? 'active' : ''}`} onClick={() => handleNavigate('/inbox', 'messages')}>
          <i className="fa-solid fa-paper-plane"></i>
          {totalUnread > 0 && <span className="unread-badge bottom">{totalUnread}</span>}
        </button>

        <button className={`cb-item ${activeTab === 'jobs' ? 'active' : ''}`} 
          onClick={() => handleNavigate('/deal-manager', 'jobs')}
        >
          <i className="fa-solid fa-briefcase"></i>
          {totalDeals > 0 && (
            <span className="unread-badge bottom">{totalDeals}</span>
          )}
        </button>

        <button className={`cb-item ${activeTab === 'notifications' ? 'active' : ''}`} onClick={() => handleNavigate('/notifications', 'notifications')}>
          <i className="fa-solid fa-bell"></i>
          {unreadNotifications > 0 && <span className="unread-badge bottom">{unreadNotifications}</span>}
        </button>

        <button 
          className={`cb-item ${showMobileMenu ? 'active' : ''}`} 
          onClick={toggleMobileMenu}
        >
          <i className="fa-solid fa-user-gear"></i>
        </button>
      </nav>

      {/* পোস্ট মডাল */}
      {showPostModal && (
        currentMode === 'buyer' ? (
          <PostJobBox 
            onClose={() => setShowPostModal(false)} 
            setActiveTab={setActiveTab} 
            onSilentPost={onSilentPost} 
            currentUser={currentUser}
          />
        ) : (
          <PostServiceBox 
            onClose={() => setShowPostModal(false)} 
            setActiveTab={setActiveTab} 
            onSilentPost={onSilentPost} 
            currentUser={currentUser}
          />
        )
      )}

    </div>
  );
};

export default Navbar;