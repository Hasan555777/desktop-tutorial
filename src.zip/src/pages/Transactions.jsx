// src/pages/Transactions.jsx
import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth, db } from '../firebase';
import { 
  collection, query, where, onSnapshot, orderBy, 
  doc, getDoc, updateDoc, Timestamp, limit, startAfter,
  getDocs
} from 'firebase/firestore';
import './Transactions.css';

const Transactions = () => {
  const navigate = useNavigate();
  const user = auth.currentUser;
  
  // ========== স্টেট ==========
  const [loading, setLoading] = useState(true);
  const [transactions, setTransactions] = useState([]);
  const [filterType, setFilterType] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all'); // ✅ নতুন: স্ট্যাটাস ফিল্টার
  const [searchQuery, setSearchQuery] = useState(''); // ✅ নতুন: সার্চ
  const [dateRange, setDateRange] = useState({ start: '', end: '' }); // ✅ নতুন: ডেট রেঞ্জ
  const [stats, setStats] = useState({
    totalCredit: 0,
    totalDebit: 0,
    totalWithdraw: 0,
    totalTransactions: 0,
    pendingCount: 0,
    completedCount: 0
  });

  // ========== ট্রানজেকশন লোড করা ==========
  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    const transactionsRef = collection(db, 'transactions');
    const q = query(
      transactionsRef,
      where('userId', '==', user.uid),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedTransactions = snapshot.docs.map(doc => {
        const data = doc.data();
        let date = new Date();
        let formattedDate = 'Just now';
        
        if (data.createdAt) {
          if (data.createdAt instanceof Timestamp) {
            date = data.createdAt.toDate();
          } else if (data.createdAt?.toDate) {
            date = data.createdAt.toDate();
          }
          formattedDate = formatDate(date);
        }
        
        return {
          id: doc.id,
          ...data,
          date: date,
          formattedDate: formattedDate,
          // ✅ নিরাপদ ডিফল্ট
          amount: data.amount || 0,
          type: data.type || 'debit',
          status: data.status || 'pending',
          title: data.title || getDefaultTitle(data.type),
          reference: data.reference || data.transactionId || data.id.slice(-8)
        };
      });
      
      setTransactions(fetchedTransactions);
      calculateStats(fetchedTransactions);
      setLoading(false);
    }, (error) => {
      console.error("❌ Error loading transactions:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user, navigate]);

  // ========== স্ট্যাটাস ক্যালকুলেশন ==========
  const calculateStats = (txns) => {
    const totalCredit = txns.filter(t => t.type === 'credit' || t.type === 'deposit' || t.type === 'earning')
      .reduce((sum, t) => sum + (t.amount || 0), 0);
    
    const totalDebit = txns.filter(t => t.type === 'debit')
      .reduce((sum, t) => sum + (t.amount || 0), 0);
    
    const totalWithdraw = txns.filter(t => t.type === 'withdraw')
      .reduce((sum, t) => sum + (t.amount || 0), 0);
    
    const pendingCount = txns.filter(t => t.status === 'pending').length;
    const completedCount = txns.filter(t => t.status === 'completed').length;
    
    setStats({
      totalCredit,
      totalDebit,
      totalWithdraw,
      totalTransactions: txns.length,
      pendingCount,
      completedCount
    });
  };

  // ========== ফিল্টার ও সার্চ করা ট্রানজেকশন ==========
  const filteredTransactions = useMemo(() => {
    let filtered = transactions;

    // ✅ টাইপ ফিল্টার
    if (filterType !== 'all') {
      if (filterType === 'credit') {
        filtered = filtered.filter(t => t.type === 'credit' || t.type === 'deposit' || t.type === 'earning');
      } else {
        filtered = filtered.filter(t => t.type === filterType);
      }
    }

    // ✅ স্ট্যাটাস ফিল্টার
    if (filterStatus !== 'all') {
      filtered = filtered.filter(t => t.status === filterStatus);
    }

    // ✅ সার্চ ফিল্টার
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase().trim();
      filtered = filtered.filter(t => 
        t.title?.toLowerCase().includes(query) ||
        t.reference?.toLowerCase().includes(query) ||
        t.id?.toLowerCase().includes(query) ||
        t.description?.toLowerCase().includes(query)
      );
    }

    // ✅ ডেট রেঞ্জ ফিল্টার
    if (dateRange.start && dateRange.end) {
      const start = new Date(dateRange.start);
      const end = new Date(dateRange.end);
      end.setHours(23, 59, 59, 999);
      
      filtered = filtered.filter(t => {
        const txDate = new Date(t.date);
        return txDate >= start && txDate <= end;
      });
    }

    return filtered;
  }, [transactions, filterType, filterStatus, searchQuery, dateRange]);

  // ========== ডেট ফরম্যাট ==========
  const formatDate = (date) => {
    if (!date) return 'Just now';
    const now = new Date();
    const diff = now - date;
    
    if (diff < 60000) return 'Just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    if (diff < 604800000) return `${Math.floor(diff / 86400000)}d ago`;
    
    return date.toLocaleDateString('en-BD', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // ========== ডিফল্ট টাইটেল ==========
  const getDefaultTitle = (type) => {
    const titles = {
      'credit': 'Payment Received',
      'debit': 'Payment Sent',
      'withdraw': 'Withdrawal Request',
      'deposit': 'Deposit',
      'earning': 'Earning',
      'bonus': 'Bonus Received'
    };
    return titles[type] || 'Transaction';
  };

  // ========== ট্রানজেকশন আইকন ==========
  const getTransactionIcon = (type) => {
    const icons = {
      'credit': 'fa-solid fa-arrow-down',
      'deposit': 'fa-solid fa-circle-dollar',
      'earning': 'fa-solid fa-chart-simple',
      'bonus': 'fa-solid fa-gift',
      'debit': 'fa-solid fa-arrow-up',
      'withdraw': 'fa-solid fa-money-bill-transfer'
    };
    return icons[type] || 'fa-solid fa-circle-dollar';
  };

  const getTransactionColor = (type) => {
    const colors = {
      'credit': '#10b981',
      'deposit': '#14b8a6',
      'earning': '#8b5cf6',
      'bonus': '#ec4899',
      'debit': '#ef4444',
      'withdraw': '#f59e0b'
    };
    return colors[type] || '#14b8a6';
  };

  const getTransactionBgColor = (type) => {
    const color = getTransactionColor(type);
    return `${color}15`;
  };

  // ========== স্ট্যাটাস কনফিগ ==========
  const getStatusConfig = (status) => {
    const configs = {
      'completed': { color: '#10b981', icon: 'fa-check-circle', bg: '#10b98115', label: 'Completed' },
      'pending': { color: '#f59e0b', icon: 'fa-clock', bg: '#f59e0b15', label: 'Pending' },
      'failed': { color: '#ef4444', icon: 'fa-times-circle', bg: '#ef444415', label: 'Failed' },
      'processing': { color: '#3b82f6', icon: 'fa-spinner fa-spin', bg: '#3b82f615', label: 'Processing' },
      'cancelled': { color: '#6b7280', icon: 'fa-ban', bg: '#6b728015', label: 'Cancelled' }
    };
    return configs[status] || configs['pending'];
  };

  // ========== ফরম্যাট টাকা ==========
  const formatMoney = (amount) => {
    return new Intl.NumberFormat('bn-BD', {
      style: 'currency',
      currency: 'BDT',
      minimumFractionDigits: 0
    }).format(amount || 0);
  };

  // ========== ক্লিয়ার ফিল্টার ==========
  const clearFilters = () => {
    setFilterType('all');
    setFilterStatus('all');
    setSearchQuery('');
    setDateRange({ start: '', end: '' });
  };

  // ========== এক্সপোর্ট CSV ==========
  const exportCSV = () => {
    const headers = ['Date', 'Title', 'Type', 'Amount', 'Status', 'Reference'];
    const rows = filteredTransactions.map(t => [
      t.formattedDate,
      getTransactionTitle(t),
      t.type,
      t.amount,
      t.status,
      t.reference || ''
    ]);
    
    const csvContent = [headers, ...rows]
      .map(row => row.join(','))
      .join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `transactions-${new Date().toISOString().slice(0,10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // ========== ট্রানজেকশন টাইটেল ==========
  const getTransactionTitle = (tx) => {
    if (tx.title) return tx.title;
    return getDefaultTitle(tx.type);
  };

  // ========== ট্রানজেকশন বিবরণ ==========
  const getTransactionDescription = (tx) => {
    if (tx.description) return tx.description;
    
    const details = [];
    if (tx.reference) details.push(`Ref: ${tx.reference}`);
    if (tx.paymentMethod) details.push(`Via: ${tx.paymentMethod}`);
    if (tx.dealId) details.push(`Deal: #${tx.dealId.slice(-8)}`);
    if (tx.mobileNumber) details.push(`Mobile: ${tx.mobileNumber}`);
    
    return details.join(' • ') || '—';
  };

  if (loading) {
    return (
      <div className="transactions-loading">
        <div className="loading-spinner"></div>
        <p>Loading transactions...</p>
      </div>
    );
  }

  return (
    <div className="transactions-container">
      <div className="transactions-wrapper">
        
        {/* ========== হেডার ========== */}
        <div className="transactions-header">
          <button className="back-btn" onClick={() => navigate(-1)}>
            <i className="fa-solid fa-arrow-left"></i> Back
          </button>
          <h1><i className="fa-solid fa-clock-rotate-left"></i> Transactions</h1>
          <button className="export-btn" onClick={exportCSV}>
            <i className="fa-solid fa-file-export"></i> Export
          </button>
        </div>

        {/* ========== সার্চ বার ========== */}
        <div className="search-bar">
          <i className="fa-solid fa-search"></i>
          <input
            type="text"
            placeholder="Search by title, reference, or ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          {searchQuery && (
            <button className="clear-search" onClick={() => setSearchQuery('')}>
              <i className="fa-solid fa-xmark"></i>
            </button>
          )}
        </div>

        {/* ========== স্ট্যাটাস কার্ড ========== */}
        <div className="stats-grid">
          <div className="stat-card credit">
            <div className="stat-icon">
              <i className="fa-solid fa-arrow-down"></i>
            </div>
            <div className="stat-info">
              <span className="stat-label">Total Received</span>
              <span className="stat-value">{formatMoney(stats.totalCredit)}</span>
            </div>
          </div>
          
          <div className="stat-card debit">
            <div className="stat-icon">
              <i className="fa-solid fa-arrow-up"></i>
            </div>
            <div className="stat-info">
              <span className="stat-label">Total Paid</span>
              <span className="stat-value">{formatMoney(stats.totalDebit)}</span>
            </div>
          </div>
          
          <div className="stat-card withdraw">
            <div className="stat-icon">
              <i className="fa-solid fa-money-bill-transfer"></i>
            </div>
            <div className="stat-info">
              <span className="stat-label">Total Withdrawn</span>
              <span className="stat-value">{formatMoney(stats.totalWithdraw)}</span>
            </div>
          </div>

          <div className="stat-card pending">
            <div className="stat-icon">
              <i className="fa-solid fa-clock"></i>
            </div>
            <div className="stat-info">
              <span className="stat-label">Pending</span>
              <span className="stat-value">{stats.pendingCount}</span>
            </div>
          </div>
        </div>

        {/* ========== ফিল্টার সেকশন ========== */}
        <div className="filter-section">
          <div className="filter-group">
            <label>Type</label>
            <div className="filter-buttons">
              <button 
                className={`filter-btn ${filterType === 'all' ? 'active' : ''}`}
                onClick={() => setFilterType('all')}
              >
                All <span className="filter-count">{transactions.length}</span>
              </button>
              <button 
                className={`filter-btn ${filterType === 'credit' ? 'active' : ''}`}
                onClick={() => setFilterType('credit')}
              >
                <i className="fa-solid fa-arrow-down"></i> Received
                <span className="filter-count">
                  {transactions.filter(t => t.type === 'credit' || t.type === 'deposit' || t.type === 'earning').length}
                </span>
              </button>
              <button 
                className={`filter-btn ${filterType === 'debit' ? 'active' : ''}`}
                onClick={() => setFilterType('debit')}
              >
                <i className="fa-solid fa-arrow-up"></i> Paid
                <span className="filter-count">
                  {transactions.filter(t => t.type === 'debit').length}
                </span>
              </button>
              <button 
                className={`filter-btn ${filterType === 'withdraw' ? 'active' : ''}`}
                onClick={() => setFilterType('withdraw')}
              >
                <i className="fa-solid fa-money-bill-transfer"></i> Withdrawn
                <span className="filter-count">
                  {transactions.filter(t => t.type === 'withdraw').length}
                </span>
              </button>
            </div>
          </div>

          <div className="filter-group">
            <label>Status</label>
            <div className="filter-buttons status-filters">
              <button 
                className={`filter-btn ${filterStatus === 'all' ? 'active' : ''}`}
                onClick={() => setFilterStatus('all')}
              >
                All
              </button>
              <button 
                className={`filter-btn ${filterStatus === 'completed' ? 'active' : ''}`}
                onClick={() => setFilterStatus('completed')}
              >
                <i className="fa-solid fa-check-circle" style={{ color: '#10b981' }}></i> Completed
              </button>
              <button 
                className={`filter-btn ${filterStatus === 'pending' ? 'active' : ''}`}
                onClick={() => setFilterStatus('pending')}
              >
                <i className="fa-solid fa-clock" style={{ color: '#f59e0b' }}></i> Pending
              </button>
              <button 
                className={`filter-btn ${filterStatus === 'failed' ? 'active' : ''}`}
                onClick={() => setFilterStatus('failed')}
              >
                <i className="fa-solid fa-times-circle" style={{ color: '#ef4444' }}></i> Failed
              </button>
            </div>
          </div>

          {/* ✅ ডেট রেঞ্জ ফিল্টার */}
          <div className="filter-group date-filter">
            <label>Date Range</label>
            <div className="date-inputs">
              <input
                type="date"
                value={dateRange.start}
                onChange={(e) => setDateRange({ ...dateRange, start: e.target.value })}
              />
              <span>to</span>
              <input
                type="date"
                value={dateRange.end}
                onChange={(e) => setDateRange({ ...dateRange, end: e.target.value })}
              />
            </div>
          </div>

          {/* ✅ ক্লিয়ার ফিল্টার */}
          {(filterType !== 'all' || filterStatus !== 'all' || searchQuery || dateRange.start || dateRange.end) && (
            <button className="clear-filters-btn" onClick={clearFilters}>
              <i className="fa-solid fa-eraser"></i> Clear Filters
            </button>
          )}
        </div>

        {/* ========== রেজাল্ট কাউন্ট ========== */}
        <div className="result-count">
          <span>
            Showing <strong>{filteredTransactions.length}</strong> of <strong>{transactions.length}</strong> transactions
          </span>
          {filteredTransactions.length !== transactions.length && (
            <span className="filtered-info">
              (filtered)
            </span>
          )}
        </div>

        {/* ========== ট্রানজেকশন লিস্ট ========== */}
        <div className="transactions-list">
          {filteredTransactions.length === 0 ? (
            <div className="no-transactions">
              <i className="fa-solid fa-receipt"></i>
              <h3>No Transactions Found</h3>
              <p>
                {searchQuery || filterType !== 'all' || filterStatus !== 'all' || dateRange.start || dateRange.end
                  ? 'No transactions match your filters. Try adjusting your search criteria.'
                  : 'You don\'t have any transactions yet.'}
              </p>
              {(searchQuery || filterType !== 'all' || filterStatus !== 'all' || dateRange.start || dateRange.end) && (
                <button className="clear-filters-btn" onClick={clearFilters}>
                  <i className="fa-solid fa-eraser"></i> Clear Filters
                </button>
              )}
              {!searchQuery && filterType === 'all' && filterStatus === 'all' && !dateRange.start && !dateRange.end && (
                <button className="browse-btn" onClick={() => navigate('/')}>
                  <i className="fa-solid fa-search"></i> Browse Jobs
                </button>
              )}
            </div>
          ) : (
            filteredTransactions.map((tx) => {
              const statusConfig = getStatusConfig(tx.status);
              const color = getTransactionColor(tx.type);
              const icon = getTransactionIcon(tx.type);

              return (
                <div key={tx.id} className="transaction-card">
                  <div className="tx-icon" style={{ background: getTransactionBgColor(tx.type) }}>
                    <i className={icon} style={{ color: color }}></i>
                  </div>
                  
                  <div className="tx-content">
                    <div className="tx-header">
                      <h4>{getTransactionTitle(tx)}</h4>
                      <span className="tx-time">{tx.formattedDate}</span>
                    </div>
                    
                    <p className="tx-description">{getTransactionDescription(tx)}</p>
                    
                    <div className="tx-footer">
                      <div className="tx-meta">
                        {tx.paymentMethod && (
                          <span className="tx-method">
                            <i className="fa-solid fa-credit-card"></i> {tx.paymentMethod}
                          </span>
                        )}
                        {tx.reference && (
                          <span className="tx-ref">
                            <i className="fa-solid fa-hashtag"></i> {tx.reference}
                          </span>
                        )}
                        <span className={`tx-status ${tx.status}`} style={{ 
                          color: statusConfig.color,
                          background: statusConfig.bg
                        }}>
                          <i className={`fa-solid ${statusConfig.icon}`}></i>
                          {statusConfig.label}
                        </span>
                      </div>
                      
                      <div className={`tx-amount ${tx.type === 'credit' || tx.type === 'deposit' || tx.type === 'earning' ? 'credit' : 'debit'}`}>
                        {tx.type === 'credit' || tx.type === 'deposit' || tx.type === 'earning' ? '+' : '-'} 
                        {formatMoney(tx.amount)}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* ========== পেজিনেশন ========== */}
        {filteredTransactions.length > 20 && (
          <div className="pagination">
            <button className="page-btn">
              <i className="fa-solid fa-chevron-left"></i> Previous
            </button>
            <span className="page-info">
              Page 1 of {Math.ceil(filteredTransactions.length / 20)}
            </span>
            <button className="page-btn">
              Next <i className="fa-solid fa-chevron-right"></i>
            </button>
          </div>
        )}

      </div>
    </div>
  );
};

export default Transactions;