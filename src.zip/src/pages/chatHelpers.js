import { db } from '../firebase';
import { 
  collection, addDoc, serverTimestamp, updateDoc, doc, 
  getDocs, query, where, increment, getDoc 
} from 'firebase/firestore';
import { generateDealId } from './dealIdHelper';

// Cloudinary কনফিগারেশন
const CLOUD_NAME = "drwex6tmf";
const UPLOAD_PRESET = "workhub_preset";

export const uploadToCloudinary = async (file) => {
  const formData = new FormData();
  formData.append("file", file);
  formData.append("upload_preset", UPLOAD_PRESET);
  
  try {
    const res = await fetch(`https://api.cloudinary.com/v1_1/${CLOUD_NAME}/image/upload`, { 
      method: "POST", 
      body: formData 
    });
    if (!res.ok) throw new Error(`Upload failed: ${res.status}`);
    const data = await res.json();
    return data.secure_url;
  } catch (error) {
    console.error("Upload Error:", error);
    return null;
  }
};

export const generateMilestones = (totalBudget) => {
  const budget = Number(totalBudget);
  return [
    { id: 1, title: 'Initial Project Setup & Planning', amount: Math.round(budget * 0.3), status: 'pending' },
    { id: 2, title: 'Core Development & Implementation', amount: Math.round(budget * 0.4), status: 'pending' },
    { id: 3, title: 'Final Testing & Handover', amount: Math.round(budget * 0.3), status: 'pending' }
  ];
};

export const formatLastSeen = (timestamp) => {
  if (!timestamp) return 'Offline';
  let date = timestamp.toDate ? timestamp.toDate() : 
             timestamp.seconds ? new Date(timestamp.seconds * 1000) : 
             new Date(timestamp);
  const now = new Date();
  const diffMin = Math.floor((now - date) / 60000);
  const diffHour = Math.floor(diffMin / 60);
  const diffDay = Math.floor(diffHour / 24);
  if (diffMin < 1) return 'Just now';
  if (diffMin < 60) return `${diffMin}m ago`;
  if (diffHour < 24) return `${diffHour}h ago`;
  if (diffDay < 7) return `${diffDay}d ago`;
  return date.toLocaleDateString();
};

export const getInitialsAvatar = (name) => {
  return `https://ui-avatars.com/api/?name=${encodeURIComponent(name || "User")}&background=random&size=150&bold=true`;
};

export const formatTime = (ts) => {
  if (!ts?.seconds) return 'Just now';
  try {
    return new Date(ts.seconds * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  } catch (error) {
    return 'Just now';
  }
};

export const sendProposal = async (proposalData, chatContext, currentUser, postType, userRole, safeChatId) => {
  if (!proposalData.budget || !proposalData.deadline || !proposalData.details) {
    alert('Please fill all fields!');
    return;
  }

  let buyerId, sellerId, buyerName, sellerName, buyerEmail, sellerEmail;
  
  if (postType === 'service') {
    buyerId = currentUser?.uid;
    sellerId = chatContext?.userId || chatContext?.ownerId || chatContext?.uid || chatContext?.sellerId;
    buyerName = currentUser?.displayName || currentUser?.email?.split('@')[0] || 'Buyer';
    buyerEmail = currentUser?.email || 'No email';
    sellerName = chatContext?.userName || chatContext?.displayName || chatContext?.name || 'Seller';
    sellerEmail = chatContext?.userEmail || chatContext?.email || 'No email';
  } else {
    buyerId = chatContext?.userId || chatContext?.buyerId || chatContext?.uid || chatContext?.ownerId;
    sellerId = currentUser?.uid;
    buyerName = chatContext?.userName || chatContext?.displayName || chatContext?.name || 'Buyer';
    buyerEmail = chatContext?.userEmail || chatContext?.email || 'No email';
    sellerName = currentUser?.displayName || currentUser?.email?.split('@')[0] || 'Seller';
    sellerEmail = currentUser?.email || 'No email';
  }

  if (!buyerId || !sellerId) {
    alert("System Error: Could not identify users.");
    return;
  }

  if (buyerId === sellerId) {
    alert("❌ You cannot send a proposal to yourself!");
    return;
  }

  const dealIdNumber = await generateDealId();
  const chatId = chatContext?.id || chatContext?.postId || `deal_${Date.now()}`;
  const milestones = generateMilestones(proposalData.budget);

  try {
    const dealPayload = {
      postId: chatContext?.id || chatContext?.postId || 'unknown_post',
      postTitle: chatContext?.title || 'Untitled Project',
      postType: postType,
      buyerId, buyerName, buyerEmail,
      sellerId, sellerName, sellerEmail,
      dealIdNumber,
      budget: Number(proposalData.budget),
      deadline: Number(proposalData.deadline),
      details: proposalData.details,
      milestones,
      status: 'pending',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      proposedBy: sellerId,
      proposedAt: serverTimestamp(),
      chatId: chatId
    };

    const dealRef = await addDoc(collection(db, 'deals'), dealPayload);

    await addDoc(collection(db, 'notifications'), {
      userId: buyerId,
      senderId: sellerId,
      senderName: sellerName,
      message: `${sellerName} sent you a new offer for: ${chatContext?.title || 'a project'}`,
      isUnread: true,
      createdAt: serverTimestamp(),
      type: 'new_offer',
      link: '/deal-manager',
      dealId: dealRef.id,
      dealIdNumber
    });

    if (chatId) {
      await addDoc(collection(db, 'chats', chatId, 'messages'), {
        text: `📄 **New Offer Sent!**\n\n💰 Budget: ${proposalData.budget} BDT\n⏱️ Deadline: ${proposalData.deadline} Days\n\n👤 From: ${sellerName}\n\n📋 Details: ${proposalData.details}`,
        sender: 'system',
        senderId: 'system',
        createdAt: serverTimestamp(),
        type: 'system',
        dealId: dealRef.id
      });

      await updateDoc(doc(db, 'chats', chatId), {
        dealId: dealRef.id,
        dealIdNumber: dealIdNumber,
        dealStatus: 'pending',
        updatedAt: serverTimestamp()
      });
    }

    alert('✅ Proposal sent successfully!');
    return true;
  } catch (error) {
    console.error("❌ Error sending proposal:", error);
    alert('Failed to send proposal.');
    return false;
  }
};

export const approveDeal = async (existingDeal, currentUser, safeChatId) => {
  if (!existingDeal || existingDeal.status !== 'pending') {
    alert('No pending offer!');
    return;
  }
  if (!window.confirm('✅ Are you sure you want to confirm this deal?')) return;

  try {
    const dealId = existingDeal.id || safeChatId;
    await updateDoc(doc(db, 'deals', dealId), {
      status: 'active',
      acceptedAt: serverTimestamp(),
      acceptedBy: currentUser?.uid,
      updatedAt: serverTimestamp()
    });

    await addDoc(collection(db, 'chats', safeChatId, 'messages'), {
      text: `✅ **Deal Confirmed!**\n\n💰 Budget: ${existingDeal.budget} BDT\n⏱️ Deadline: ${existingDeal.deadline} Days`,
      sender: 'system',
      senderId: 'system',
      createdAt: serverTimestamp(),
      type: 'system'
    });

    alert('🎉 Deal confirmed!');
  } catch (error) {
    console.error("Error:", error);
    alert('Failed to confirm deal.');
  }
};

export const rejectDeal = async (existingDeal, currentUser, safeChatId) => {
  if (!existingDeal || existingDeal.status !== 'pending') {
    alert('No pending offer to reject!');
    return;
  }
  if (!window.confirm('⚠️ Are you sure you want to reject this offer?')) return;

  try {
    const dealId = existingDeal.id || safeChatId;
    await updateDoc(doc(db, 'deals', dealId), {
      status: 'rejected',
      rejectedAt: serverTimestamp(),
      rejectedBy: currentUser?.uid,
      updatedAt: serverTimestamp()
    });

    await addDoc(collection(db, 'chats', safeChatId, 'messages'), {
      text: `❌ **Offer Rejected**\n\n${currentUser?.displayName || 'Someone'} has rejected the offer.`,
      sender: 'system',
      senderId: 'system',
      createdAt: serverTimestamp(),
      type: 'system'
    });

    alert('❌ Offer rejected successfully!');
  } catch (error) {
    console.error("❌ Error rejecting deal:", error);
    alert('Failed to reject offer.');
  }
};

export const reopenDeal = async (existingDeal, currentUser, safeChatId) => {
  if (!window.confirm("⚠️ Are you sure you want to re-open this cancelled deal?")) return;

  try {
    const dealId = existingDeal?.id || safeChatId;
    await updateDoc(doc(db, 'deals', dealId), {
      status: 'pending',
      cancelledAt: null,
      cancellationReason: null,
      reopenedAt: serverTimestamp(),
      reopenedBy: currentUser?.uid,
      updatedAt: serverTimestamp()
    });

    await addDoc(collection(db, 'chats', safeChatId, 'messages'), {
      text: `🔄 **Deal Re-opened**\n\n${currentUser?.displayName || 'Someone'} has re-opened this deal.`,
      sender: 'system',
      senderId: 'system',
      createdAt: serverTimestamp(),
      type: 'system'
    });

    alert("✅ Deal re-opened successfully!");
  } catch (error) {
    console.error("Error re-opening deal:", error);
    alert("Failed to re-open deal.");
  }
};