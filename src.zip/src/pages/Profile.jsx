// src/pages/Profile.jsx
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import './Profile.css';
import { auth, db } from '../firebase';
import { 
  doc, 
  getDoc, 
  updateDoc, 
  deleteDoc, 
  collection, 
  query, 
  where, 
  getDocs, 
  orderBy, 
  writeBatch,
  serverTimestamp,
  arrayUnion,
  arrayRemove
} from 'firebase/firestore';
import { updateProfile } from 'firebase/auth';
import ReviewModal from './ReviewModal';
import { useAuth } from '../context/AuthContext';
import ProfileProgress from "../components/ProfileProgress";



// Cloudinary আপলোড ফাংশন
const uploadToCloudinary = async (file) => {
  const formData = new FormData();
  formData.append("file", file);
  formData.append("upload_preset", "workhub_preset");

  try {
    const response = await fetch(
      "https://api.cloudinary.com/v1_1/drwex6tmf/image/upload",
      { method: "POST", body: formData }
    );
    const data = await response.json();
    return data.secure_url;
  } catch (error) {
    console.error("Cloudinary Upload Error:", error);
    return null;
  }
};

function Profile() {
  const navigate = useNavigate();
  const user = auth.currentUser;
  const { userData } = useAuth();

  // ========== স্টেট ==========
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [copySuccess, setCopySuccess] = useState(false);
  const [activeTab, setActiveTab] = useState('posts');
  const [userPosts, setUserPosts] = useState([]);
  const [savedPosts, setSavedPosts] = useState([]);
  const [savedPostIds, setSavedPostIds] = useState([]);
  const [postsLoading, setPostsLoading] = useState(true);
  const [savedPostsLoading, setSavedPostsLoading] = useState(false);
  const [editingPost, setEditingPost] = useState(null);
  const [editForm, setEditForm] = useState({
    title: '',
    description: '',
    budget: '',
    deadline: '',
    images: []
  });

  // ========== রিভিউ স্টেট ==========
  const [reviews, setReviews] = useState([]);
  const [reviewsLoading, setReviewsLoading] = useState(false);
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [userRating, setUserRating] = useState({ average: 0, total: 0 });

  const [editImages, setEditImages] = useState([]);
  const [editImagePreviews, setEditImagePreviews] = useState([]);
  const [editImageLoading, setEditImageLoading] = useState(false);
  const editFileInputRef = useRef(null);

  const [userIdNumber, setUserIdNumber] = useState('');
  const [isEditingId, setIsEditingId] = useState(false);

  // ========== ✅ ডকুমেন্ট ভেরিফিকেশন স্টেট (Register.jsx থেকে) ==========
  const [docStatus, setDocStatus] = useState({
    nidFront: false,
    nidBack: false,
    birth: false,
    faceVerified: false,
    documentsUploaded: false
  });
  const [uploadingDocs, setUploadingDocs] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [selectedVerify, setSelectedVerify] = useState('nid');
  const [isVerified, setIsVerified] = useState(false);
  const [verificationStatus, setVerificationStatus] = useState('pending'); // pending, verified, rejected

  // ========== ✅ ফেস ভেরিফিকেশন স্টেট ==========
  const [camStream, setCamStream] = useState(null);
  const [livenessComplete, setLivenessComplete] = useState(false);
  const [currentLivenessStep, setCurrentLivenessStep] = useState(0);
  const [livenessTimer, setLivenessTimer] = useState(null);
  const [faceVerified, setFaceVerified] = useState(false);
  const videoRef = useRef(null);
  const canvasRef = useRef(null);

  const [livenessState, setLivenessState] = useState([
    { id: 'eyeOpen', label: '👁️ চোখ খোলা', done: false },
    { id: 'eyeClose', label: '😌 চোখ বন্ধ', done: false },
    { id: 'mouthOpen', label: '👄 মুখ খোলা', done: false },
    { id: 'mouthClose', label: '😐 মুখ বন্ধ', done: false },
    { id: 'headRight', label: '👉 মাথা ডানে', done: false },
    { id: 'headLeft', label: '👈 মাথা বামে', done: false }
  ]);

  // ========== Mode স্টেট ==========
  const handleModeChange = (mode) => {
    setCurrentMode(mode);
    localStorage.setItem('profileMode', mode);
  };

  const [currentMode, setCurrentMode] = useState(() => {
    return localStorage.getItem('profileMode') || 'buyer';
  });

  // ========== প্রোফাইল ডেটা ==========
  const [profileData, setProfileData] = useState({
    name: '',
    headline: 'Full-Stack Developer | Architecting Scalable Digital Ecosystems',
    about: 'আমি একজন Full-Stack Developer যিনি স্কেলেবল ডিজিটাল ইকোসিস্টেম তৈরি করতে পছন্দ করেন।',
    skills: 'React, Vite, Firebase, Cloudinary, Tailwind CSS, Node.js',
    coverPhoto: 'https://images.unsplash.com/photo-1618401471353-b98afee0b2eb?w=1200',
    profilePic: 'https://ui-avatars.com/api/?name=User&background=14b8a6&color=fff&bold=true&size=120'
  });

  // ========== নতুন সেকশনের স্টেট ==========
  const [experience, setExperience] = useState([]);
  const [education, setEducation] = useState([]);
  const [certifications, setCertifications] = useState([]);
  const [socialLinks, setSocialLinks] = useState({
    linkedin: '',
    github: '',
    website: ''
  });
  const [testimonials, setTestimonials] = useState([]);
  const [isEditingExperience, setIsEditingExperience] = useState(false);
  const [isEditingEducation, setIsEditingEducation] = useState(false);
  const [isEditingCertifications, setIsEditingCertifications] = useState(false);
  const [isEditingSocial, setIsEditingSocial] = useState(false);
  const [newExperience, setNewExperience] = useState({
    company: '',
    role: '',
    startDate: '',
    endDate: '',
    description: ''
  });
  const [newEducation, setNewEducation] = useState({
    institution: '',
    degree: '',
    field: '',
    startDate: '',
    endDate: ''
  });
  const [newCertification, setNewCertification] = useState({
    name: '',
    issuer: '',
    date: '',
    link: ''
  });

  


  

  // ============================================================
  // ✅ রিভিউ ফেচ করা
  // ============================================================
  useEffect(() => {
    if (!user?.uid) return;

    const fetchReviews = async () => {
      setReviewsLoading(true);
      try {
        const q = query(
          collection(db, 'reviews'),
          where('userId', '==', user.uid)
        );
        const snapshot = await getDocs(q);
        const reviewsData = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        }));

        reviewsData.sort((a, b) => {
          const dateA = a.createdAt?.toDate?.() || new Date(0);
          const dateB = b.createdAt?.toDate?.() || new Date(0);
          return dateB - dateA;
        });

        setReviews(reviewsData);

        if (reviewsData.length > 0) {
          const total = reviewsData.reduce((sum, r) => sum + r.rating, 0);
          const average = total / reviewsData.length;
          setUserRating({
            average: Math.round(average * 10) / 10,
            total: reviewsData.length
          });
        }
      } catch (error) {
        console.error("Error fetching reviews:", error);
      } finally {
        setReviewsLoading(false);
      }
    };

    fetchReviews();
  }, [user?.uid]);

  // ============================================================
  // ✅ ইউজারের savedPosts আইডি লোড করা
  // ============================================================
  useEffect(() => {
    if (!user) return;

    const loadSavedPostIds = async () => {
      try {
        const userDoc = await getDoc(doc(db, "users", user.uid));
        if (userDoc.exists()) {
          const data = userDoc.data();
          setSavedPostIds(data.savedPosts || []);
          setExperience(data.experience || []);
          setEducation(data.education || []);
          setCertifications(data.certifications || []);
          setSocialLinks(data.socialLinks || { linkedin: '', github: '', website: '' });
          setTestimonials(data.testimonials || []);
          
          // ✅ ভেরিফিকেশন স্ট্যাটাস লোড
          setIsVerified(data.isVerified || false);
          setVerificationStatus(data.verificationStatus || 'pending');
          
          // ✅ ডকুমেন্ট স্ট্যাটাস লোড
          const docs = data.documents || {};
          setDocStatus({
            nidFront: !!docs.nidFront,
            nidBack: !!docs.nidBack,
            birth: !!docs.birthCert,
            faceVerified: !!data.facePhotoUrl,
            documentsUploaded: !!(docs.nidFront || docs.birthCert)
          });
          setFaceVerified(!!data.facePhotoUrl);
        }
      } catch (error) {
        console.error("Error loading saved posts:", error);
      }
    };

    loadSavedPostIds();
  }, [user]);

  // ============================================================
  // ✅ সেভ করা পোস্ট লোড করা
  // ============================================================
  useEffect(() => {
    if (activeTab !== 'saved' || !user) return;

    const loadSavedPosts = async () => {
      setSavedPostsLoading(true);
      try {
        const userDoc = await getDoc(doc(db, "users", user.uid));
        const savedIds = userDoc.data()?.savedPosts || [];

        if (savedIds.length === 0) {
          setSavedPosts([]);
          setSavedPostsLoading(false);
          return;
        }

        const postsRef = collection(db, "posts");
        const q = query(postsRef, where("__name__", "in", savedIds));
        const querySnapshot = await getDocs(q);

        const postsData = querySnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        }));

        setSavedPosts(postsData);
      } catch (error) {
        console.error("Error loading saved posts:", error);
        setSavedPosts([]);
      } finally {
        setSavedPostsLoading(false);
      }
    };

    loadSavedPosts();
  }, [activeTab, user]);

  // ============================================================
  // ✅ ইউজার ডাটা লোড করা
  // ============================================================
  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    const loadUserData = async () => {
      setLoading(true);
      try {
        const userDoc = await getDoc(doc(db, "users", user.uid));
        if (userDoc.exists()) {
          const data = userDoc.data();
          setProfileData(prev => ({
            ...prev,
            name: data.displayName || user.displayName || user.email?.split('@')[0] || 'User',
            headline: data.headline || prev.headline,
            about: data.about || prev.about,
            skills: data.skills || prev.skills,
            coverPhoto: data.coverPhoto || prev.coverPhoto,
            profilePic: data.photoURL || user.photoURL || prev.profilePic
          }));
          setUserIdNumber(data.userIdNumber || '');
          setSavedPostIds(data.savedPosts || []);
          setExperience(data.experience || []);
          setEducation(data.education || []);
          setCertifications(data.certifications || []);
          setSocialLinks(data.socialLinks || { linkedin: '', github: '', website: '' });
          setTestimonials(data.testimonials || []);
          
          // ✅ ভেরিফিকেশন স্ট্যাটাস লোড
          setIsVerified(data.isVerified || false);
          setVerificationStatus(data.verificationStatus || 'pending');
          
          // ✅ ডকুমেন্ট স্ট্যাটাস লোড
          const docs = data.documents || {};
          setDocStatus({
            nidFront: !!docs.nidFront,
            nidBack: !!docs.nidBack,
            birth: !!docs.birthCert,
            faceVerified: !!data.facePhotoUrl,
            documentsUploaded: !!(docs.nidFront || docs.birthCert)
          });
          setFaceVerified(!!data.facePhotoUrl);
        } else {
          setProfileData(prev => ({
            ...prev,
            name: user.displayName || user.email?.split('@')[0] || 'User'
          }));
        }
      } catch (error) {
        console.error("Error loading user data:", error);
      } finally {
        setLoading(false);
      }
    };

    loadUserData();
  }, [user, navigate]);

  // ============================================================
  // ✅ ইউজারের নিজের পোস্ট লোড করা
  // ============================================================
  useEffect(() => {
    if (!user?.uid) return;

    const loadPosts = async () => {
      setPostsLoading(true);
      try {
        const q = query(
          collection(db, 'posts'),
          where('userId', '==', user.uid),
          orderBy('createdAt', 'desc')
        );
        const snapshot = await getDocs(q);

        const uniquePostsMap = new Map();
        snapshot.docs.forEach(doc => {
          if (!uniquePostsMap.has(doc.id)) {
            uniquePostsMap.set(doc.id, {
              id: doc.id,
              ...doc.data(),
              createdAt: doc.data().createdAt || new Date().toISOString()
            });
          }
        });

        const posts = Array.from(uniquePostsMap.values());
        setUserPosts(posts);

      } catch (error) {
        console.error("Error loading posts:", error);
      } finally {
        setPostsLoading(false);
      }
    };

    loadPosts();
  }, [user?.uid]);

  // ============================================================
  // ✅ প্রোফাইল সেভ করা
  // ============================================================
  const handleSaveProfile = async () => {
    if (!user) return;

    if (!profileData.name?.trim()) {
      alert('Please enter your name!');
      return;
    }

    try {
      const batch = writeBatch(db);
      const userRef = doc(db, 'users', user.uid);

      batch.update(userRef, {
        displayName: profileData.name.trim(),
        headline: profileData.headline || '',
        about: profileData.about || '',
        skills: profileData.skills || '',
        photoURL: profileData.profilePic,
        updatedAt: serverTimestamp()
      });

      const chatsQuery = query(collection(db, 'chats'), where('participants', 'array-contains', user.uid));
      const snapshot = await getDocs(chatsQuery);

      snapshot.forEach((chatDoc) => {
        batch.update(chatDoc.ref, {
          [`participantsData.${user.uid}.name`]: profileData.name.trim(),
          [`participantsData.${user.uid}.photo`]: profileData.profilePic
        });
      });

      await batch.commit();

      await updateProfile(user, {
        displayName: profileData.name.trim(),
        photoURL: profileData.profilePic
      });

      alert('✅ Profile updated successfully!');
      setIsEditing(false);

    } catch (error) {
      console.error("Error saving profile:", error);
      alert('Failed to save profile: ' + error.message);
    }
  };

  // ============================================================
  // ✅ আইডি নাম্বার সেভ
  // ============================================================
  const handleSaveUserIdNumber = async () => {
    if (!user) return;

    const cleanedId = userIdNumber.trim();
    if (!cleanedId) {
      alert("Please enter a valid ID number!");
      return;
    }

    if (!/^[a-zA-Z0-9_\-]+$/.test(cleanedId)) {
      alert("ID number can only contain letters, numbers, underscore (_) and hyphen (-)!");
      return;
    }

    try {
      const userRef = doc(db, 'users', user.uid);
      await updateDoc(userRef, {
        userIdNumber: cleanedId,
        updatedAt: serverTimestamp()
      });

      alert('✅ ID Number saved successfully!');
      setIsEditingId(false);
    } catch (error) {
      console.error("Error saving ID number:", error);
      alert('Failed to save ID number: ' + error.message);
    }
  };

  // ============================================================
  // ✅ প্রোফাইল পিক আপলোড
  // ============================================================
  const handleProfilePicUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    try {
      const imageUrl = await uploadToCloudinary(file);
      if (imageUrl) {
        const batch = writeBatch(db);

        const userRef = doc(db, 'users', auth.currentUser.uid);
        batch.update(userRef, { photoURL: imageUrl });

        const q = query(collection(db, 'posts'), where('userId', '==', auth.currentUser.uid));
        const querySnapshot = await getDocs(q);

        querySnapshot.forEach((postDoc) => {
          batch.update(postDoc.ref, { userPhotoURL: imageUrl });
        });

        await batch.commit();
        await updateProfile(auth.currentUser, { photoURL: imageUrl });

        setProfileData(prev => ({ ...prev, profilePic: imageUrl }));
        alert('✅ প্রোফাইল এবং আপনার সব পোস্ট আপডেট হয়েছে!');
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  // ============================================================
  // ✅ ডকুমেন্ট আপলোড ফাংশন (Register.jsx থেকে)
  // ============================================================
  const uploadDocuments = async () => {
    setUploadingDocs(true);
    setUploadProgress(0);
    
    try {
      const uploadedDocs = {};
      let progress = 0;
      
      // NID Front
      const frontFile = document.getElementById('nidFront')?.files[0];
      if (frontFile) {
        const url = await uploadToCloudinary(frontFile);
        uploadedDocs.nidFront = { url };
        progress += 33;
        setUploadProgress(progress);
      }
      
      // NID Back
      const backFile = document.getElementById('nidBack')?.files[0];
      if (backFile) {
        const url = await uploadToCloudinary(backFile);
        uploadedDocs.nidBack = { url };
        progress += 33;
        setUploadProgress(progress);
      }
      
      // Birth Certificate
      const birthFile = document.getElementById('birthCert')?.files[0];
      if (birthFile) {
        const url = await uploadToCloudinary(birthFile);
        uploadedDocs.birthCert = { url };
        progress += 34;
        setUploadProgress(progress);
      }
      
      await updateDoc(doc(db, 'users', user.uid), {
        documents: uploadedDocs,
        documentVerified: false,
        verificationStatus: 'pending',
        documentSubmittedAt: serverTimestamp()
      });
      
      setDocStatus(prev => ({ ...prev, documentsUploaded: true }));
      setVerificationStatus('pending');
      setUploadProgress(100);
      alert('✅ ডকুমেন্ট আপলোড সম্পন্ন! অ্যাডমিন যাচাই করছে...');
      checkCompletion();
      
    } catch (error) {
      console.error('Document upload error:', error);
      alert('❌ ডকুমেন্ট আপলোড ব্যর্থ হয়েছে');
    } finally {
      setUploadingDocs(false);
    }
  };

  // ============================================================
  // ✅ ফেস ভেরিফিকেশন ফাংশন (Register.jsx থেকে)
  // ============================================================
  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } }
      });
      setCamStream(stream);
      if (videoRef.current) videoRef.current.srcObject = stream;
      
      document.getElementById('cameraBox')?.classList.add('camera-active');
      document.getElementById('camStartBtn').style.display = 'none';
      document.getElementById('captureBtn').style.display = '';
      document.getElementById('camStopBtn').style.display = '';
      
      alert('📷 ক্যামেরা চালু হয়েছে');
      resetLiveness();
      setTimeout(startLivenessDetection, 1000);
      
    } catch (e) {
      if (e.name === 'NotAllowedError') {
        alert('⚠️ ক্যামেরা অ্যাক্সেস ডিনাই করা হয়েছে');
      } else {
        alert('⚠️ ক্যামেরা চালু করা যায়নি');
      }
    }
  };

  const stopCamera = () => {
    if (camStream) {
      camStream.getTracks().forEach(t => t.stop());
      setCamStream(null);
    }
    document.getElementById('cameraBox')?.classList.remove('camera-active');
    document.getElementById('camStartBtn').style.display = '';
    document.getElementById('captureBtn').style.display = 'none';
    document.getElementById('camStopBtn').style.display = 'none';
    resetLiveness();
  };

  const startLivenessDetection = () => {
    if (livenessComplete) return;
    const resetState = livenessState.map(s => ({ ...s, done: false }));
    setLivenessState(resetState);
    setCurrentLivenessStep(0);
    setLivenessComplete(false);
    startLivenessTimer();
  };

  const startLivenessTimer = () => {
    clearInterval(livenessTimer);
    const interval = setInterval(() => {
      if (livenessComplete) { clearInterval(interval); return; }
      const current = livenessState[currentLivenessStep];
      if (current && !current.done) {
        const updated = [...livenessState];
        updated[currentLivenessStep].done = true;
        setLivenessState(updated);
        const nextStep = currentLivenessStep + 1;
        setCurrentLivenessStep(nextStep);
        if (nextStep >= livenessState.length) {
          clearInterval(interval);
        }
        updateLivenessUI(updated);
      }
    }, 3000);
    setLivenessTimer(interval);
  };

  const updateLivenessUI = (state) => {
    const doneCount = state.filter(s => s.done).length;
    const total = state.length;
    document.getElementById('livenessProgressText').textContent = `${doneCount}/${total} সম্পন্ন`;
    document.getElementById('livenessProgressFill').style.width = `${(doneCount/total)*100}%`;
    
    if (doneCount === total) {
      setLivenessComplete(true);
      clearInterval(livenessTimer);
      setTimeout(capturePhoto, 1000);
    }
  };

  const resetLiveness = () => {
    setLivenessComplete(false);
    setCurrentLivenessStep(0);
    const resetState = livenessState.map(s => ({ ...s, done: false }));
    setLivenessState(resetState);
    clearInterval(livenessTimer);
    updateLivenessUI(resetState);
  };

  const capturePhoto = async () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;
    
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0);
    
    const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg'));
    
    if (camStream) {
      camStream.getTracks().forEach(t => t.stop());
      setCamStream(null);
    }
    
    document.getElementById('cameraBox')?.classList.remove('camera-active');
    document.getElementById('captureBtn').style.display = 'none';
    document.getElementById('camStartBtn').style.display = '';
    
    try {
      const file = new File([blob], 'face_photo.jpg', { type: 'image/jpeg' });
      const url = await uploadToCloudinary(file);
      
      await updateDoc(doc(db, 'users', user.uid), {
        facePhotoUrl: url,
        faceVerified: true
      });
      
      setFaceVerified(true);
      setDocStatus(prev => ({ ...prev, faceVerified: true }));
      alert('✅ মুখমণ্ডল যাচাই সম্পন্ন!');
      checkCompletion();
      
    } catch (error) {
      console.error('Face photo upload error:', error);
      alert('❌ ফেস ফটো আপলোড ব্যর্থ হয়েছে');
    }
  };

  // ============================================================
  // ✅ কমপ্লিটনেস চেক (Register.jsx থেকে)
  // ============================================================
  const checkCompletion = async () => {
    if (!user) return;
    
    try {
      const userDoc = await getDoc(doc(db, 'users', user.uid));
      const data = userDoc.data();
      
      const isComplete = !!(
        data.firstName ||
        data.displayName &&
        data.email &&
        data.phone &&
        data.dob &&
        (data.documents?.nidFront || data.documents?.birthCert) &&
        data.facePhotoUrl
      );
      
      if (isComplete) {
        await updateDoc(doc(db, 'users', user.uid), {
          isComplete: true,
          completedAt: serverTimestamp()
        });
        alert('🎉 আপনার প্রোফাইল সম্পূর্ণ! এখন লেনদেন করতে পারবেন।');
      }
      
    } catch (error) {
      console.error('Completion check error:', error);
    }
  };

  // ============================================================
  // ✅ অভিজ্ঞতা সংরক্ষণ
  // ============================================================
  const handleAddExperience = async () => {
    if (!newExperience.company || !newExperience.role) {
      alert('Please fill company and role!');
      return;
    }

    try {
      const userRef = doc(db, 'users', user.uid);
      const updatedExperience = [...experience, { ...newExperience, id: Date.now() }];
      await updateDoc(userRef, { experience: updatedExperience });
      setExperience(updatedExperience);
      setNewExperience({ company: '', role: '', startDate: '', endDate: '', description: '' });
      setIsEditingExperience(false);
      alert('✅ Experience added!');
    } catch (error) {
      console.error("Error:", error);
      alert('Failed to add experience.');
    }
  };

  const handleDeleteExperience = async (id) => {
    if (!window.confirm('Delete this experience?')) return;
    try {
      const userRef = doc(db, 'users', user.uid);
      const updatedExperience = experience.filter(exp => exp.id !== id);
      await updateDoc(userRef, { experience: updatedExperience });
      setExperience(updatedExperience);
    } catch (error) {
      console.error("Error:", error);
    }
  };

  // ============================================================
  // ✅ শিক্ষা সংরক্ষণ
  // ============================================================
  const handleAddEducation = async () => {
    if (!newEducation.institution || !newEducation.degree) {
      alert('Please fill institution and degree!');
      return;
    }

    try {
      const userRef = doc(db, 'users', user.uid);
      const updatedEducation = [...education, { ...newEducation, id: Date.now() }];
      await updateDoc(userRef, { education: updatedEducation });
      setEducation(updatedEducation);
      setNewEducation({ institution: '', degree: '', field: '', startDate: '', endDate: '' });
      setIsEditingEducation(false);
      alert('✅ Education added!');
    } catch (error) {
      console.error("Error:", error);
      alert('Failed to add education.');
    }
  };

  const handleDeleteEducation = async (id) => {
    if (!window.confirm('Delete this education?')) return;
    try {
      const userRef = doc(db, 'users', user.uid);
      const updatedEducation = education.filter(edu => edu.id !== id);
      await updateDoc(userRef, { education: updatedEducation });
      setEducation(updatedEducation);
    } catch (error) {
      console.error("Error:", error);
    }
  };

  // ============================================================
  // ✅ সার্টিফিকেশন সংরক্ষণ
  // ============================================================
  const handleAddCertification = async () => {
    if (!newCertification.name || !newCertification.issuer) {
      alert('Please fill certification name and issuer!');
      return;
    }

    try {
      const userRef = doc(db, 'users', user.uid);
      const updatedCertifications = [...certifications, { ...newCertification, id: Date.now() }];
      await updateDoc(userRef, { certifications: updatedCertifications });
      setCertifications(updatedCertifications);
      setNewCertification({ name: '', issuer: '', date: '', link: '' });
      setIsEditingCertifications(false);
      alert('✅ Certification added!');
    } catch (error) {
      console.error("Error:", error);
      alert('Failed to add certification.');
    }
  };

  const handleDeleteCertification = async (id) => {
    if (!window.confirm('Delete this certification?')) return;
    try {
      const userRef = doc(db, 'users', user.uid);
      const updatedCertifications = certifications.filter(cert => cert.id !== id);
      await updateDoc(userRef, { certifications: updatedCertifications });
      setCertifications(updatedCertifications);
    } catch (error) {
      console.error("Error:", error);
    }
  };

  // ============================================================
  // ✅ সোশ্যাল লিংক সংরক্ষণ
  // ============================================================
  const handleSaveSocialLinks = async () => {
    try {
      const userRef = doc(db, 'users', user.uid);
      await updateDoc(userRef, { socialLinks });
      setIsEditingSocial(false);
      alert('✅ Social links updated!');
    } catch (error) {
      console.error("Error:", error);
      alert('Failed to update social links.');
    }
  };

  // ============================================================
  // ✅ পোস্ট সেভ/আনসেভ টগল
  // ============================================================
  const toggleSavePost = async (postId) => {
    if (!user) return;

    const userRef = doc(db, 'users', user.uid);
    const isCurrentlySaved = savedPostIds.includes(postId);

    try {
      if (isCurrentlySaved) {
        await updateDoc(userRef, {
          savedPosts: arrayRemove(postId)
        });
        setSavedPostIds(prev => prev.filter(id => id !== postId));
        setSavedPosts(prev => prev.filter(p => p.id !== postId));
      } else {
        await updateDoc(userRef, {
          savedPosts: arrayUnion(postId)
        });
        setSavedPostIds(prev => [...prev, postId]);
      }
    } catch (error) {
      console.error("Error toggling save:", error);
    }
  };

  // ============================================================
  // ✅ পোস্ট এডিট ফাংশন
  // ============================================================
  const handleEditPost = (post) => {
    setEditingPost(post);
    setEditForm({
      title: post.title || '',
      description: post.description || '',
      budget: post.budget || post.price || '',
      deadline: post.deadline || post.deliveryDays || '',
      images: post.images || []
    });
    setEditImagePreviews([...(post.images || [])]);
    setEditImages([]);
  };

  const handleEditImageChange = (e) => {
    const files = Array.from(e.target.files);
    const remainingSlots = 2 - editImagePreviews.length;

    if (files.length > remainingSlots) {
      alert(`⚠️ You can only add ${remainingSlots} more image(s). Maximum 2 images allowed!`);
      return;
    }

    const newPreviews = files.map(file => URL.createObjectURL(file));
    setEditImages(prev => [...prev, ...files]);
    setEditImagePreviews(prev => [...prev, ...newPreviews]);
  };

  const handleRemoveEditImage = (indexToRemove) => {
    const previewToRemove = editImagePreviews[indexToRemove];
    const isExistingImage = typeof previewToRemove === 'string' && previewToRemove.startsWith('http');

    if (isExistingImage) {
      const currentImages = [...editForm.images];
      const imageUrlToRemove = previewToRemove.split('?')[0];
      const imageIndex = currentImages.findIndex(img => img.split('?')[0] === imageUrlToRemove);

      if (imageIndex !== -1) {
        currentImages.splice(imageIndex, 1);
        setEditForm(prev => ({ ...prev, images: currentImages }));
      }
    } else {
      const fileIndex = indexToRemove - (editForm.images?.length || 0);
      if (fileIndex >= 0 && fileIndex < editImages.length) {
        setEditImages(prev => prev.filter((_, i) => i !== fileIndex));
      }
    }

    setEditImagePreviews(prev => prev.filter((_, i) => i !== indexToRemove));
  };

  const uploadEditImages = async () => {
    if (editImages.length === 0) return [];

    const uploadedUrls = [];
    for (const file of editImages) {
      const url = await uploadToCloudinary(file);
      if (url) uploadedUrls.push(url);
    }
    return uploadedUrls;
  };

  const handleUpdatePost = async () => {
    if (!editingPost) return;

    setEditImageLoading(true);

    try {
      const postRef = doc(db, 'posts', editingPost.id);
      const postSnap = await getDoc(postRef);

      if (!postSnap.exists()) {
        alert('❌ This post no longer exists.');
        setEditingPost(null);
        setEditImageLoading(false);
        return;
      }

      const existingImages = (editForm.images || []).filter(img => typeof img === 'string');
      let newImageUrls = [];

      if (editImages.length > 0) {
        newImageUrls = await uploadEditImages();
      }

      const finalImages = [...existingImages, ...newImageUrls];

      if (finalImages.length === 0) {
        alert('⚠️ Please keep at least one image for your post.');
        setEditImageLoading(false);
        return;
      }

      await updateDoc(postRef, {
        title: editForm.title,
        description: editForm.description,
        budget: editForm.budget,
        deadline: editForm.deadline,
        images: finalImages,
        updatedAt: serverTimestamp()
      });

      alert('✅ Post updated successfully!');

      setUserPosts(prev => prev.map(post =>
        post.id === editingPost.id
          ? {
            ...post,
            title: editForm.title,
            description: editForm.description,
            budget: editForm.budget,
            deadline: editForm.deadline,
            images: finalImages
          }
          : post
      ));

      setEditingPost(null);
      setEditForm({ title: '', description: '', budget: '', deadline: '', images: [] });
      setEditImages([]);
      setEditImagePreviews([]);

    } catch (error) {
      console.error("❌ Update error:", error);
      alert('Failed to update post: ' + error.message);
    } finally {
      setEditImageLoading(false);
    }
  };

  // ============================================================
  // ✅ পোস্ট ডিলিট
  // ============================================================
  const handleDeletePost = async (postId) => {
    if (!window.confirm('⚠️ Delete this post permanently?')) {
      return;
    }

    setPostsLoading(true);

    try {
      const batch = writeBatch(db);
      const postRef = doc(db, 'posts', postId);
      batch.delete(postRef);
      await batch.commit();

      setUserPosts(prev => prev.filter(p => p.id !== postId));
      alert('✅ Post deleted successfully!');

    } catch (error) {
      console.error("❌ Delete error:", error);
      alert('Failed to delete post: ' + error.message);
    } finally {
      setPostsLoading(false);
    }
  };

  // ============================================================
  // ✅ পোর্টফোলিও লিংক কপি
  // ============================================================
  const handleCopyLink = () => {
    const portfolioLink = `https://workhub.com/profile/${user?.uid}`;
    navigator.clipboard.writeText(portfolioLink);
    setCopySuccess(true);
    setTimeout(() => setCopySuccess(false), 2000);
  };

  // ============================================================
  // ✅ ফিল্টারিং
  // ============================================================
  const filteredPosts = userPosts.filter(post => {
    if (currentMode === 'buyer') {
      return post.type === 'hire';
    } else {
      return post.type === 'service';
    }
  });


  // ============================================================
  // ✅ রেন্ডার পোস্ট গ্রিড
  // ============================================================
  const renderPostGrid = (posts, isLoading, emptyMessage) => {
    if (isLoading) {
      return (
        <div className="loading-posts">
          <div className="loading-spinner-small"></div>
          <p>Loading posts...</p>
        </div>
      );
    }

    if (posts.length === 0) {
      return (
        <div className="no-posts">
          <i className="fa-solid fa-folder-open"></i>
          <p>{emptyMessage}</p>
          {activeTab === 'posts' && (
            <button className="create-post-btn" onClick={() => navigate('/')}>
              <i className="fa-solid fa-plus"></i> Create {currentMode === 'buyer' ? 'Job' : 'Service'}
            </button>
          )}
        </div>
      );
    }

    return (
      <div className="posts-grid">
        {posts.map((post, index) => (
          <div key={`${post.id}-${index}`} className="post-card">
            {post.images && post.images.length > 0 && (
              <div className={`post-images-container ${post.images.length > 1 ? 'two-images' : 'one-image'}`}>
                {post.images.slice(0, 2).map((img, imgIndex) => (
                  <img
                    key={imgIndex}
                    src={`${img.split('?')[0]}?v=${post._updatedAt || Date.now()}`}
                    alt={post.title}
                    className="post-image"
                  />
                ))}
                {post.images.length > 2 && (
                  <div className="post-image-badge">+{post.images.length - 2}</div>
                )}
              </div>
            )}

            <div className="post-content">
              <h4>{post.title}</h4>
              <p className="post-description">{post.description?.substring(0, 100)}...</p>
              <div className="post-meta">
                <span><i className="fa-solid fa-wallet"></i> {post.budget || post.price} BDT</span>
                <span><i className="fa-regular fa-clock"></i> {post.deadline || post.deliveryDays} Days</span>
                <span><i className="fa-solid fa-tag"></i> {post.type === 'hire' ? 'Job' : 'Service'}</span>
              </div>
              {activeTab === 'posts' && (
                <div className="post-actions">
                  <button className="edit-post-btn" onClick={() => handleEditPost(post)}>
                    <i className="fa-solid fa-pen"></i> Edit
                  </button>
                  <button className="force-delete-btn" onClick={() => handleDeletePost(post.id)}>
                    <i className="fa-solid fa-trash"></i> Delete
                  </button>
                </div>
              )}
              {activeTab === 'saved' && (
                <button
                  className="unsave-btn"
                  onClick={() => toggleSavePost(post.id)}
                >
                  <i className="fa-solid fa-bookmark"></i> Unsave
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    );
  };

  // ============================================================
  // ✅ ডকুমেন্ট ট্যাব রেন্ডার
  // ============================================================
  const renderDocumentsTab = () => (
    <div className="tab-panel documents-panel">
      <h3><i className="fa-solid fa-file"></i> ডকুমেন্ট যাচাই</h3>
      <p className="tab-subtitle">আপনার পরিচয় প্রমাণের জন্য ডকুমেন্ট আপলোড করুন</p>
      
      {/* ✅ ভেরিফিকেশন স্ট্যাটাস দেখানো */}
      <div className="verification-status-box">
        <div className={`status-badge-large ${verificationStatus}`}>
          {verificationStatus === 'verified' && '✅ যাচাইকৃত'}
          {verificationStatus === 'pending' && '⏳ যাচাই বাকি'}
          {verificationStatus === 'rejected' && '❌ প্রত্যাখ্যাত'}
        </div>
        {isVerified && (
          <div className="verified-badge">
            <i className="fa-solid fa-check-circle"></i> আপনার অ্যাকাউন্ট যাচাই করা হয়েছে
          </div>
        )}
      </div>
      
      {docStatus.documentsUploaded ? (
        <div className="info-box success">
          <span className="info-icon">✅</span>
          <div>
            <strong>ডকুমেন্ট আপলোড সম্পন্ন!</strong>
            <p>আপনার ডকুমেন্ট অ্যাডমিন দ্বারা যাচাই করা হচ্ছে।</p>
          </div>
        </div>
      ) : (
        <>
          <div className="upload-row">
            <div className="form-group">
              <label>NID কার্ড (সামনে) <span className="required">*</span></label>
              <div className="upload-area" id="nidFrontArea">
                <input type="file" id="nidFront" accept="image/*" />
                <div className="upload-default">
                  <div className="upload-icon">🪪</div>
                  <div className="upload-label">সামনের ছবি</div>
                </div>
              </div>
            </div>
            <div className="form-group">
              <label>NID কার্ড (পিছনে) <span className="required">*</span></label>
              <div className="upload-area" id="nidBackArea">
                <input type="file" id="nidBack" accept="image/*" />
                <div className="upload-default">
                  <div className="upload-icon">🔄</div>
                  <div className="upload-label">পিছনের ছবি</div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="form-group">
            <label>জন্ম নিবন্ধন সনদ</label>
            <div className="upload-area" id="birthArea">
              <input type="file" id="birthCert" accept="image/*,application/pdf" />
              <div className="upload-default">
                <div className="upload-icon">📄</div>
                <div className="upload-label">সনদের ছবি বা PDF</div>
              </div>
            </div>
          </div>
          
          {uploadingDocs && (
            <div className="upload-progress">
              <div className="progress-text">আপলোড হচ্ছে... {Math.round(uploadProgress)}%</div>
              <div className="progress-bar-small">
                <div className="progress-fill-small" style={{ width: `${uploadProgress}%` }}></div>
              </div>
            </div>
          )}
          
          <button className="save-btn" onClick={uploadDocuments} disabled={uploadingDocs}>
            {uploadingDocs ? '⏳ আপলোড হচ্ছে...' : '📤 ডকুমেন্ট আপলোড করুন'}
          </button>
        </>
      )}
    </div>
  );

  // ============================================================
  // ✅ ফেস ভেরিফিকেশন ট্যাব রেন্ডার
  // ============================================================
  const renderFaceVerificationTab = () => (
    <div className="tab-panel face-panel">
      <h3><i className="fa-solid fa-camera"></i> মুখমণ্ডল যাচাই</h3>
      <p className="tab-subtitle">নিচের নির্দেশনা অনুসরণ করুন</p>
      
      {docStatus.faceVerified ? (
        <div className="info-box success">
          <span className="info-icon">✅</span>
          <div>
            <strong>মুখমণ্ডল যাচাই সম্পন্ন!</strong>
            <p>আপনার ফেস ভেরিফিকেশন সফলভাবে সম্পন্ন হয়েছে।</p>
          </div>
        </div>
      ) : (
        <>
          <div className="liveness-instructions">
            {livenessState.map((step) => (
              <div key={step.id} className={`instruction-step ${step.done ? 'done' : ''}`}>
                <div className="inst-text">{step.label}</div>
                <div className="inst-status">{step.done ? '✅' : '⬜'}</div>
              </div>
            ))}
          </div>
          
          <div className="camera-box" id="cameraBox">
            <video ref={videoRef} autoPlay muted playsInline></video>
            <canvas ref={canvasRef}></canvas>
            <div className="camera-placeholder">
              <span>📷</span>
              <div>ক্যামেরা চালু করুন</div>
            </div>
          </div>
          
          <div className="liveness-progress">
            <div className="progress-text" id="livenessProgressText">০/৬ সম্পন্ন</div>
            <div className="progress-bar-small">
              <div className="progress-fill-small" id="livenessProgressFill" style={{ width: '0%' }}></div>
            </div>
          </div>
          
          <div className="btn-row">
            <button className="btn btn-ghost" id="camStartBtn" onClick={startCamera}>📷 ক্যামেরা চালু</button>
            <button className="btn btn-primary" id="captureBtn" onClick={capturePhoto} style={{ display: 'none' }}>📸 ছবি তুলুন</button>
            <button className="btn btn-danger" id="camStopBtn" onClick={stopCamera} style={{ display: 'none' }}>⏹ বন্ধ</button>
          </div>
        </>
      )}
    </div>
  );

  // ============================================================
  // ✅ লোডিং চেক
  // ============================================================
  if (loading) {
    return (
      <div className="loading-screen">
        <div className="loading-spinner"></div>
        <p>Loading profile...</p>
      </div>
    );
  }

  // ============================================================
  // ✅ রেন্ডার
  // ============================================================
  return (
    <div className="profile-page">
{/* ===== প্রোফাইল হেডার ===== */}
<div className="profile-header-wrapper">
  <div className="profile-avatar-wrapper">
    <img src={profileData.profilePic} alt="Profile" className="profile-avatar" />
    <label htmlFor="avatar-upload" className="avatar-upload-btn">
      <i className="fa-solid fa-camera"></i>
    </label>
    <input type="file" id="avatar-upload" hidden accept="image/*" onChange={handleProfilePicUpload} />
  </div>

  {/* ✅ প্রগ্রেস সেকশন */}
  <div className="progress-section" style={{ padding: '0 20px' }}>
    <ProfileProgress />
  </div>

  <div className="profile-info-wrapper">
    <div className="profile-name-section">
      <h1>{profileData.name}</h1>
      <button className="copy-link-btn" onClick={handleCopyLink}>
        <i className="fa-solid fa-copy"></i>
        {copySuccess ? 'Copied!' : 'Copy Link'}
      </button>
    </div>

    {/* ✅ ভেরিফিকেশন ব্যাজ */}
    <div className="verification-badge-wrapper">
      {isVerified ? (
        <span className="verified-badge">
          <i className="fa-solid fa-check-circle"></i> যাচাইকৃত
        </span>
      ) : verificationStatus === 'pending' ? (
        <span className="pending-badge">
          <i className="fa-solid fa-clock"></i> যাচাই বাকি
        </span>
      ) : verificationStatus === 'rejected' ? (
        <span className="rejected-badge">
          <i className="fa-solid fa-times-circle"></i> প্রত্যাখ্যাত
        </span>
      ) : (
        <span className="unverified-badge">
          <i className="fa-solid fa-exclamation-circle"></i> যাচাই করা হয়নি
        </span>
      )}
    </div>

    <p className="profile-headline">{profileData.headline}</p>
    <p className="profile-email">
      <i className="fa-solid fa-envelope"></i> {user?.email}
    </p>

    {/* ✅ ইউজার আইডি নাম্বার সেকশন */}
    <div className="user-id-section">
      {userIdNumber ? (
        <div className="user-id-display">
          <i className="fa-solid fa-id-card"></i>
          <span>ID: {userIdNumber}</span>
          <button className="edit-id-btn" onClick={() => setIsEditingId(true)}>
            <i className="fa-solid fa-pen"></i>
          </button>
        </div>
      ) : (
        <div className="user-id-missing">
          <i className="fa-solid fa-exclamation-triangle"></i>
          <span>No ID number set</span>
          <button className="add-id-btn" onClick={() => setIsEditingId(true)}>
            <i className="fa-solid fa-plus"></i> Add ID Number
          </button>
        </div>
      )}
    </div>

    {/* ✅✅✅ নতুন: ইউনিক আইডি, ওয়ালেট আইডি, রেফারেল কোড ✅✅✅ */}
    <div className="profile-unique-ids">
      <div className="unique-id-item">
        <span className="id-label">🆔 ইউজার আইডি</span>
        <span className="id-value">{userData?.uniqueId || 'Loading...'}</span>
        <button 
          className="copy-id-btn"
          onClick={() => {
            navigator.clipboard.writeText(userData?.uniqueId || '');
            alert('📋 ইউজার আইডি কপি করা হয়েছে!');
          }}
          title="কপি করুন"
        >
          <i className="fa-solid fa-copy"></i>
        </button>
      </div>
      
      <div className="unique-id-item">
        <span className="id-label">💳 ওয়ালেট আইডি</span>
        <span className="id-value">{userData?.walletId || 'Loading...'}</span>
        <button 
          className="copy-id-btn"
          onClick={() => {
            navigator.clipboard.writeText(userData?.walletId || '');
            alert('📋 ওয়ালেট আইডি কপি করা হয়েছে!');
          }}
          title="কপি করুন"
        >
          <i className="fa-solid fa-copy"></i>
        </button>
      </div>
      
      <div className="unique-id-item">
        <span className="id-label">🔗 রেফারেল কোড</span>
        <span className="id-value">{userData?.referralCode || 'Loading...'}</span>
        <button 
          className="copy-id-btn"
          onClick={() => {
            navigator.clipboard.writeText(userData?.referralCode || '');
            alert('📋 রেফারেল কোড কপি করা হয়েছে!');
          }}
          title="কপি করুন"
        >
          <i className="fa-solid fa-copy"></i>
        </button>
      </div>
    </div>

    <button className="edit-profile-btn" onClick={() => setIsEditing(true)}>
      <i className="fa-solid fa-pen"></i> Edit Profile
    </button>
  </div>
</div>

{/* ===== আইডি নাম্বার এডিট মোডাল ===== */}
{isEditingId && (
  <div className="modal-overlay" onClick={() => setIsEditingId(false)}>
    <div className="edit-modal" onClick={(e) => e.stopPropagation()}>
      <h3><i className="fa-solid fa-id-card"></i> Set Your ID Number</h3>
      <div className="edit-form">
        <p className="id-info-text">This ID will be used for sending and receiving money.</p>
        <input
          type="text"
          value={userIdNumber}
          onChange={(e) => setUserIdNumber(e.target.value)}
          placeholder="Enter your unique ID number"
          maxLength="20"
        />
        <div className="edit-actions">
          <button className="cancel-btn" onClick={() => setIsEditingId(false)}>Cancel</button>
          <button className="save-btn" onClick={handleSaveUserIdNumber}>Save ID Number</button>
        </div>
      </div>
    </div>
  </div>
)}

      {/* ===== এডিট প্রোফাইল মোডাল ===== */}
      {isEditing && (
        <div className="modal-overlay" onClick={() => setIsEditing(false)}>
          <div className="edit-modal" onClick={(e) => e.stopPropagation()}>
            <h3><i className="fa-solid fa-user-pen"></i> Edit Profile</h3>
            <div className="edit-form">
              <input type="text" value={profileData.name} onChange={(e) => setProfileData({ ...profileData, name: e.target.value })} placeholder="Full Name" />
              <input type="text" value={profileData.headline} onChange={(e) => setProfileData({ ...profileData, headline: e.target.value })} placeholder="Headline" />
              <textarea value={profileData.about} onChange={(e) => setProfileData({ ...profileData, about: e.target.value })} placeholder="About Me" rows="4" />
              <input type="text" value={profileData.skills} onChange={(e) => setProfileData({ ...profileData, skills: e.target.value })} placeholder="Skills (comma separated)" />
              <div className="edit-actions">
                <button className="cancel-btn" onClick={() => setIsEditing(false)}>Cancel</button>
                <button className="save-btn" onClick={handleSaveProfile}>Save Changes</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===== পোস্ট এডিট মোডাল ===== */}
      {editingPost && (
        <div className="modal-overlay" onClick={() => setEditingPost(null)}>
          <div className="edit-modal edit-post-modal" onClick={(e) => e.stopPropagation()}>
            <div className="edit-modal-header">
              <h3>
                <i className="fa-solid fa-pen-to-square" style={{ color: '#fbbf24' }}></i>
                Edit Post
              </h3>
              <button className="modal-close-btn" onClick={() => setEditingPost(null)}>
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>

            <div className="edit-form">
              <div className="pb-group">
                <label>Post Title <span className="required-star">*</span></label>
                <input
                  type="text"
                  value={editForm.title}
                  onChange={(e) => setEditForm({ ...editForm, title: e.target.value })}
                  placeholder="Enter post title..."
                  className="edit-input"
                  maxLength="100"
                />
                <small className="char-count">{editForm.title?.length || 0}/100</small>
              </div>

              <div className="pb-group">
                <label>Description <span className="required-star">*</span></label>
                <textarea
                  value={editForm.description}
                  onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                  placeholder="Describe your post in detail..."
                  rows="4"
                  className="edit-textarea"
                  maxLength="2000"
                />
                <small className="char-count">{editForm.description?.length || 0}/2000</small>
              </div>

              <div className="pb-row-twin">
                <div className="pb-group">
                  <label>Budget / Price <span className="required-star">*</span></label>
                  <div className="input-with-icon">
                    <span className="input-icon">৳</span>
                    <input
                      type="number"
                      value={editForm.budget}
                      onChange={(e) => setEditForm({ ...editForm, budget: e.target.value })}
                      placeholder="Enter amount"
                      className="edit-input with-icon"
                      min="0"
                    />
                  </div>
                </div>
                <div className="pb-group">
                  <label>Deadline / Delivery Days <span className="required-star">*</span></label>
                  <div className="input-with-icon">
                    <input
                      type="number"
                      value={editForm.deadline}
                      onChange={(e) => setEditForm({ ...editForm, deadline: e.target.value })}
                      placeholder="Enter days"
                      className="edit-input with-icon"
                      min="1"
                    />
                    <span className="input-icon-right">Days</span>
                  </div>
                </div>
              </div>

              {editingPost?.images?.length > 0 && (
                <div className="pb-group">
                  <label>Images ({editImagePreviews.length}/2)</label>
                  <div className="edit-images-section">
                    {editImagePreviews.length > 0 && (
                      <div className="edit-images-grid">
                        {editImagePreviews.map((img, idx) => (
                          <div key={idx} className="edit-image-item">
                            <img src={img} alt={`Preview ${idx}`} />
                            <button
                              type="button"
                              className="remove-image-btn"
                              onClick={() => handleRemoveEditImage(idx)}
                            >
                              <i className="fa-solid fa-xmark"></i>
                            </button>
                            <div className="image-order-badge">{idx + 1}</div>
                          </div>
                        ))}
                      </div>
                    )}

                    {editImagePreviews.length < 2 && (
                      <div
                        className="upload-drop-zone-small"
                        onClick={() => editFileInputRef.current?.click()}
                      >
                        <i className="fa-solid fa-cloud-arrow-up"></i>
                        <p>Drop or click to add image</p>
                        <span>({editImagePreviews.length}/2 used)</span>
                      </div>
                    )}

                    <input
                      type="file"
                      ref={editFileInputRef}
                      hidden
                      accept="image/*"
                      onChange={handleEditImageChange}
                      multiple={editImagePreviews.length < 2}
                    />
                  </div>
                  <small className="image-hint">
                    <i className="fa-solid fa-info-circle"></i>
                    Supported: JPG, PNG, WebP (Max 5MB each)
                  </small>
                </div>
              )}

              <div className="edit-actions">
                <button className="cancel-btn" onClick={() => setEditingPost(null)}>
                  <i className="fa-solid fa-times"></i> Cancel
                </button>
                <button
                  className="save-btn"
                  onClick={handleUpdatePost}
                  disabled={editImageLoading || !editForm.title.trim() || !editForm.description.trim()}
                >
                  {editImageLoading ? (
                    <><i className="fa-solid fa-spinner fa-spin"></i> Updating...</>
                  ) : (
                    <><i className="fa-solid fa-check"></i> Update Post</>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===== Mode Switcher ===== */}
      <div className="profile-mode-switcher">
        <button
          className={`profile-mode-btn ${currentMode === 'buyer' ? 'active' : ''}`}
          onClick={() => handleModeChange('buyer')}
        >
          <i className="fa-solid fa-briefcase"></i> Buyer Mode
        </button>
        <button
          className={`profile-mode-btn ${currentMode === 'seller' ? 'active' : ''}`}
          onClick={() => handleModeChange('seller')}
        >
          <i className="fa-solid fa-laptop-code"></i> Seller Mode
        </button>
      </div>

      {/* ===== Tabs ===== */}
      <div className="profile-tabs-wrapper">
        <div className="profile-tabs">
          <button className={`tab-btn ${activeTab === 'posts' ? 'active' : ''}`} onClick={() => setActiveTab('posts')}>
            <i className="fa-solid fa-file-alt"></i> My {currentMode === 'buyer' ? 'Jobs' : 'Services'}
          </button>
          <button className={`tab-btn ${activeTab === 'saved' ? 'active' : ''}`} onClick={() => setActiveTab('saved')}>
            <i className="fa-solid fa-bookmark"></i> Saved
            {savedPostIds.length > 0 && <span className="saved-count-badge">{savedPostIds.length}</span>}
          </button>
          <button className={`tab-btn ${activeTab === 'reviews' ? 'active' : ''}`} onClick={() => setActiveTab('reviews')}>
            <i className="fa-solid fa-star" style={{ color: '#fbbf24' }}></i> Reviews
            {userRating.total > 0 && <span className="tab-badge">{userRating.average}★</span>}
          </button>
          <button className={`tab-btn ${activeTab === 'documents' ? 'active' : ''}`} onClick={() => setActiveTab('documents')}>
            <i className="fa-solid fa-file"></i> ডকুমেন্ট
            {!docStatus.documentsUploaded && <span className="tab-badge warning">!</span>}
          </button>
          <button className={`tab-btn ${activeTab === 'face' ? 'active' : ''}`} onClick={() => setActiveTab('face')}>
            <i className="fa-solid fa-camera"></i> ফেস
            {!docStatus.faceVerified && <span className="tab-badge warning">!</span>}
          </button>
          <button className={`tab-btn ${activeTab === 'experience' ? 'active' : ''}`} onClick={() => setActiveTab('experience')}>
            <i className="fa-solid fa-briefcase"></i> Experience
          </button>
          <button className={`tab-btn ${activeTab === 'education' ? 'active' : ''}`} onClick={() => setActiveTab('education')}>
            <i className="fa-solid fa-graduation-cap"></i> Education
          </button>
          <button className={`tab-btn ${activeTab === 'certifications' ? 'active' : ''}`} onClick={() => setActiveTab('certifications')}>
            <i className="fa-solid fa-award"></i> Certifications
          </button>
          <button className={`tab-btn ${activeTab === 'social' ? 'active' : ''}`} onClick={() => setActiveTab('social')}>
            <i className="fa-solid fa-share-nodes"></i> Connect
          </button>
          <button className={`tab-btn ${activeTab === 'about' ? 'active' : ''}`} onClick={() => setActiveTab('about')}>
            <i className="fa-solid fa-user"></i> About
          </button>
          <button className={`tab-btn ${activeTab === 'skills' ? 'active' : ''}`} onClick={() => setActiveTab('skills')}>
            <i className="fa-solid fa-code"></i> Skills
          </button>
        </div>
      </div>

      {/* ===== ট্যাব কন্টেন্ট ===== */}
      <div className="profile-content">

        {/* পোস্ট ট্যাব */}
        {activeTab === 'posts' && (
          <div className="user-posts-section">
            <h3>
              <i className="fa-solid fa-file-alt"></i>
              My {currentMode === 'buyer' ? 'Jobs' : 'Services'} ({filteredPosts.length})
            </h3>
            {renderPostGrid(
              filteredPosts,
              postsLoading,
              `No ${currentMode === 'buyer' ? 'jobs' : 'services'} posted yet.`
            )}
          </div>
        )}

        {/* Saved Posts ট্যাব */}
        {activeTab === 'saved' && (
          <div className="user-posts-section">
            <h3>
              <i className="fa-solid fa-bookmark"></i>
              Saved Posts ({savedPosts.length})
            </h3>
            {renderPostGrid(
              savedPosts,
              savedPostsLoading,
              'No saved posts yet. Save posts you like!'
            )}
          </div>
        )}

        {/* Reviews Tab */}
        {activeTab === 'reviews' && (
          <div className="tab-panel reviews-panel">
            <div className="reviews-header">
              <h3>
                <i className="fa-solid fa-star" style={{ color: '#fbbf24' }}></i>
                Reviews ({reviews.length})
              </h3>
              {reviews.length > 0 && (
                <div className="average-rating">
                  <span className="rating-number">{userRating.average}</span>
                  <div className="rating-stars">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <i key={star} className={`fa-solid fa-star ${star <= Math.round(userRating.average) ? 'filled' : ''}`}></i>
                    ))}
                  </div>
                  <span className="rating-total">({userRating.total} reviews)</span>
                </div>
              )}
            </div>

            {reviewsLoading ? (
              <div className="loading-reviews">
                <div className="loading-spinner-small"></div>
                <p>Loading reviews...</p>
              </div>
            ) : reviews.length === 0 ? (
              <div className="no-reviews">
                <i className="fa-solid fa-star-half-stroke"></i>
                <p>No reviews yet.</p>
                <button className="btn-review" onClick={() => navigate(`/profile/${user.uid}`)}>
                  <i className="fa-solid fa-star"></i> Share your profile to get reviews
                </button>
              </div>
            ) : (
              <div className="reviews-list">
                {reviews.map((review) => (
                  <div key={review.id} className="review-card">
                    <div className="review-header">
                      <div className="reviewer-info">
                        <img
                          src={review.reviewerPhoto || `https://ui-avatars.com/api/?name=${review.reviewerName || 'User'}&background=14b8a6&color=fff&bold=true&size=40`}
                          alt={review.reviewerName}
                          className="reviewer-avatar"
                          onError={(e) => {
                            e.target.src = `https://ui-avatars.com/api/?name=${review.reviewerName || 'User'}&background=14b8a6&color=fff&bold=true&size=40`;
                          }}
                        />
                        <div>
                          <h4>{review.reviewerName || 'Anonymous'}</h4>
                          <div className="review-stars">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <i key={star} className={`fa-solid fa-star ${star <= review.rating ? 'filled' : ''}`}></i>
                            ))}
                          </div>
                        </div>
                      </div>
                      <span className="review-date">
                        {review.createdAt?.toDate?.()?.toLocaleDateString() ||
                          review.createdAt?.split?.('T')?.[0] ||
                          'Recently'}
                      </span>
                    </div>
                    <p className="review-text">{review.text}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ডকুমেন্ট ট্যাব */}
        {activeTab === 'documents' && renderDocumentsTab()}

        {/* ফেস ভেরিফিকেশন ট্যাব */}
        {activeTab === 'face' && renderFaceVerificationTab()}

        {/* Experience Tab */}
        {activeTab === 'experience' && (
          <div className="tab-panel experience-panel">
            <div className="section-header">
              <h3><i className="fa-solid fa-briefcase"></i> Work Experience</h3>
              {!isEditingExperience && (
                <button className="add-btn" onClick={() => setIsEditingExperience(true)}>
                  <i className="fa-solid fa-plus"></i> Add Experience
                </button>
              )}
            </div>

            {isEditingExperience && (
              <div className="add-form">
                <input type="text" placeholder="Company" value={newExperience.company} onChange={(e) => setNewExperience({ ...newExperience, company: e.target.value })} />
                <input type="text" placeholder="Role / Position" value={newExperience.role} onChange={(e) => setNewExperience({ ...newExperience, role: e.target.value })} />
                <input type="text" placeholder="Start Date" value={newExperience.startDate} onChange={(e) => setNewExperience({ ...newExperience, startDate: e.target.value })} />
                <input type="text" placeholder="End Date (or Present)" value={newExperience.endDate} onChange={(e) => setNewExperience({ ...newExperience, endDate: e.target.value })} />
                <textarea placeholder="Description" value={newExperience.description} onChange={(e) => setNewExperience({ ...newExperience, description: e.target.value })} rows="3" />
                <div className="form-actions">
                  <button className="cancel-btn" onClick={() => setIsEditingExperience(false)}>Cancel</button>
                  <button className="save-btn" onClick={handleAddExperience}>Add</button>
                </div>
              </div>
            )}

            {experience.length === 0 && !isEditingExperience ? (
              <div className="empty-state">
                <i className="fa-solid fa-briefcase"></i>
                <p>No experience added yet</p>
              </div>
            ) : (
              experience.map(exp => (
                <div key={exp.id} className="item-card">
                  <div className="item-header">
                    <h4>{exp.role} at {exp.company}</h4>
                    <button className="delete-btn" onClick={() => handleDeleteExperience(exp.id)}>
                      <i className="fa-solid fa-trash"></i>
                    </button>
                  </div>
                  <p className="item-date">{exp.startDate} - {exp.endDate || 'Present'}</p>
                  <p className="item-description">{exp.description}</p>
                </div>
              ))
            )}
          </div>
        )}

        {/* Education Tab */}
        {activeTab === 'education' && (
          <div className="tab-panel education-panel">
            <div className="section-header">
              <h3><i className="fa-solid fa-graduation-cap"></i> Education</h3>
              {!isEditingEducation && (
                <button className="add-btn" onClick={() => setIsEditingEducation(true)}>
                  <i className="fa-solid fa-plus"></i> Add Education
                </button>
              )}
            </div>

            {isEditingEducation && (
              <div className="add-form">
                <input type="text" placeholder="Institution" value={newEducation.institution} onChange={(e) => setNewEducation({ ...newEducation, institution: e.target.value })} />
                <input type="text" placeholder="Degree" value={newEducation.degree} onChange={(e) => setNewEducation({ ...newEducation, degree: e.target.value })} />
                <input type="text" placeholder="Field of Study" value={newEducation.field} onChange={(e) => setNewEducation({ ...newEducation, field: e.target.value })} />
                <input type="text" placeholder="Start Date" value={newEducation.startDate} onChange={(e) => setNewEducation({ ...newEducation, startDate: e.target.value })} />
                <input type="text" placeholder="End Date" value={newEducation.endDate} onChange={(e) => setNewEducation({ ...newEducation, endDate: e.target.value })} />
                <div className="form-actions">
                  <button className="cancel-btn" onClick={() => setIsEditingEducation(false)}>Cancel</button>
                  <button className="save-btn" onClick={handleAddEducation}>Add</button>
                </div>
              </div>
            )}

            {education.length === 0 && !isEditingEducation ? (
              <div className="empty-state">
                <i className="fa-solid fa-graduation-cap"></i>
                <p>No education added yet</p>
              </div>
            ) : (
              education.map(edu => (
                <div key={edu.id} className="item-card">
                  <div className="item-header">
                    <h4>{edu.degree} - {edu.field}</h4>
                    <button className="delete-btn" onClick={() => handleDeleteEducation(edu.id)}>
                      <i className="fa-solid fa-trash"></i>
                    </button>
                  </div>
                  <p className="item-institution">{edu.institution}</p>
                  <p className="item-date">{edu.startDate} - {edu.endDate || 'Present'}</p>
                </div>
              ))
            )}
          </div>
        )}

        {/* Certifications Tab */}
        {activeTab === 'certifications' && (
          <div className="tab-panel certifications-panel">
            <div className="section-header">
              <h3><i className="fa-solid fa-award"></i> Certifications</h3>
              {!isEditingCertifications && (
                <button className="add-btn" onClick={() => setIsEditingCertifications(true)}>
                  <i className="fa-solid fa-plus"></i> Add Certification
                </button>
              )}
            </div>

            {isEditingCertifications && (
              <div className="add-form">
                <input type="text" placeholder="Certification Name" value={newCertification.name} onChange={(e) => setNewCertification({ ...newCertification, name: e.target.value })} />
                <input type="text" placeholder="Issuer" value={newCertification.issuer} onChange={(e) => setNewCertification({ ...newCertification, issuer: e.target.value })} />
                <input type="text" placeholder="Date" value={newCertification.date} onChange={(e) => setNewCertification({ ...newCertification, date: e.target.value })} />
                <input type="url" placeholder="Certificate Link (Optional)" value={newCertification.link} onChange={(e) => setNewCertification({ ...newCertification, link: e.target.value })} />
                <div className="form-actions">
                  <button className="cancel-btn" onClick={() => setIsEditingCertifications(false)}>Cancel</button>
                  <button className="save-btn" onClick={handleAddCertification}>Add</button>
                </div>
              </div>
            )}

            {certifications.length === 0 && !isEditingCertifications ? (
              <div className="empty-state">
                <i className="fa-solid fa-award"></i>
                <p>No certifications added yet</p>
              </div>
            ) : (
              certifications.map(cert => (
                <div key={cert.id} className="item-card">
                  <div className="item-header">
                    <h4>{cert.name}</h4>
                    <button className="delete-btn" onClick={() => handleDeleteCertification(cert.id)}>
                      <i className="fa-solid fa-trash"></i>
                    </button>
                  </div>
                  <p className="item-issuer">Issued by: {cert.issuer}</p>
                  <p className="item-date">{cert.date}</p>
                  {cert.link && <a href={cert.link} target="_blank" rel="noopener noreferrer" className="cert-link">🔗 View Certificate</a>}
                </div>
              ))
            )}
          </div>
        )}

        {/* Social Links Tab */}
        {activeTab === 'social' && (
          <div className="tab-panel social-panel">
            <h3><i className="fa-solid fa-share-nodes"></i> Connect</h3>

            <div className="social-form">
              <div className="form-group">
                <label><i className="fa-brands fa-linkedin"></i> LinkedIn</label>
                <input type="url" placeholder="https://linkedin.com/in/yourprofile" value={socialLinks.linkedin} onChange={(e) => setSocialLinks({ ...socialLinks, linkedin: e.target.value })} />
              </div>
              <div className="form-group">
                <label><i className="fa-brands fa-github"></i> GitHub</label>
                <input type="url" placeholder="https://github.com/yourusername" value={socialLinks.github} onChange={(e) => setSocialLinks({ ...socialLinks, github: e.target.value })} />
              </div>
              <div className="form-group">
                <label><i className="fa-solid fa-globe"></i> Website / Portfolio</label>
                <input type="url" placeholder="https://yourwebsite.com" value={socialLinks.website} onChange={(e) => setSocialLinks({ ...socialLinks, website: e.target.value })} />
              </div>
              <button className="save-btn" onClick={handleSaveSocialLinks}>
                <i className="fa-solid fa-check"></i> Save Links
              </button>
            </div>

            <div className="social-preview">
              {socialLinks.linkedin && <a href={socialLinks.linkedin} target="_blank" rel="noopener noreferrer"><i className="fa-brands fa-linkedin"></i> LinkedIn</a>}
              {socialLinks.github && <a href={socialLinks.github} target="_blank" rel="noopener noreferrer"><i className="fa-brands fa-github"></i> GitHub</a>}
              {socialLinks.website && <a href={socialLinks.website} target="_blank" rel="noopener noreferrer"><i className="fa-solid fa-globe"></i> Website</a>}
            </div>
          </div>
        )}

        {/* About Tab */}
        {activeTab === 'about' && (
          <div className="about-section">
            <div className="about-card">
              <h3><i className="fa-solid fa-user-pen"></i> About Me</h3>
              <p>{profileData.about}</p>
            </div>
          </div>
        )}

        {/* Skills Tab */}
        {activeTab === 'skills' && (
          <div className="skills-section">
            <div className="skills-card">
              <h3><i className="fa-solid fa-code"></i> Core Skills</h3>
              <div className="skills-chip-container">
                {skillsArray.map((skill, idx) => (
                  <span key={idx} className="skill-chip">{skill}</span>
                ))}
              </div>
            </div>
          </div>
        )}

      </div>

    </div>
  );
}

export default Profile;