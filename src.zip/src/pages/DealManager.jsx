import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { db, auth } from '../firebase';
import { 
  doc, getDoc, updateDoc, collection, query, 
  where, onSnapshot, addDoc, deleteDoc, getDocs, writeBatch 
} from 'firebase/firestore';
import './DealManager.css';
import { 
  sendMilestoneNotification, sendDealNotification, 
  sendPaymentNotification, sendDeadlinePassedNotification 
} from './notificationHelper';
import Swal from 'sweetalert2';

// ============================================================
// ✅ নোটিফিকেশন ফাংশন - শুধু একবার ডিক্লেয়ার করা হয়েছে
// ============================================================
const sendCancellationRequestNotification = async (userId, postTitle, dealId, requesterName, reason, budget) => {
  try {
    const safePostTitle = postTitle || 'Untitled Deal';
    const safeRequesterName = requesterName || 'Someone';
    const safeReason = reason || 'No reason provided';
    const safeDealId = dealId || '';
    const safeBudget = budget || 0;
    
    const notificationRef = collection(db, 'notifications');
    await addDoc(notificationRef, {
      userId: userId,
      type: 'cancellation_request',
      title: 'Deal Cancellation Request',
      message: `${safeRequesterName} has requested to cancel the deal "${safePostTitle}" (Budget: ${safeBudget} BDT). Reason: ${safeReason}`,
      dealId: safeDealId,
      postTitle: safePostTitle,
      isRead: false,
      createdAt: new Date().toISOString(),
      actionRequired: true,
      actionType: 'cancel_respond'
    });
    console.log("✅ Cancellation request notification sent to:", userId);
  } catch (error) {
    console.error("Error sending cancellation notification:", error);
  }
};

const sendCancellationApprovedNotification = async (buyerId, sellerId, postTitle, dealId) => {
  try {
    const safePostTitle = postTitle || 'Untitled Deal';
    const safeDealId = dealId || '';
    
    console.log("📤 Sending cancellation approved:", { buyerId, sellerId, postTitle: safePostTitle });
    
    const notificationRef = collection(db, 'notifications');
    
    await addDoc(notificationRef, {
      userId: buyerId,
      type: 'cancellation_approved',
      title: 'Deal Cancelled',
      message: `The deal "${safePostTitle}" has been cancelled by mutual agreement.`,
      dealId: safeDealId,
      postTitle: safePostTitle,
      isRead: false,
      createdAt: new Date().toISOString()
    });
    
    await addDoc(notificationRef, {
      userId: sellerId,
      type: 'cancellation_approved',
      title: 'Deal Cancelled',
      message: `The deal "${safePostTitle}" has been cancelled by mutual agreement.`,
      dealId: safeDealId,
      postTitle: safePostTitle,
      isRead: false,
      createdAt: new Date().toISOString()
    });
    
    console.log("✅ Cancellation approved notifications sent!");
  } catch (error) {
    console.error("Error sending cancellation approved notification:", error);
  }
};

const deleteCancelNotifications = async (dealId) => {
  try {
    const notifRef = collection(db, 'notifications');
    const q = query(notifRef, where("dealId", "==", dealId), where("type", "in", ['cancellation_request', 'cancellation_approved', 'cancellation_rejected']));
    const snapshot = await getDocs(q);
    
    if (snapshot.size > 0) {
      const batch = writeBatch(db);
      snapshot.docs.forEach(doc => batch.delete(doc.ref));
      await batch.commit();
      console.log("✅ Notifications cleaned up");
    }
  } catch (error) {
    console.error("Error cleaning notifications:", error);
  }
};

const DealManager = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const dealId = searchParams.get('dealId') || searchParams.get('postId');
  
  const [currentMode, setCurrentMode] = useState(() => {
    return localStorage.getItem('dealMode') || 'buyer';
  });
  const [deals, setDeals] = useState([]);
  const [selectedDeal, setSelectedDeal] = useState(null);
  const [loading, setLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showCancelledDeals, setShowCancelledDeals] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState({});

  // ============================================================
  // ✅ Auth Check
  // ============================================================
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      setCurrentUser(user);
    });
    return () => unsubscribe();
  }, []);

  // ============================================================
  // ✅ Mode Change Handler
  // ============================================================
  const handleModeChange = (mode) => {
    setCurrentMode(mode);
    localStorage.setItem('dealMode', mode);
    setSelectedDeal(null);
  };

  // ============================================================
  // ✅ Load User Deals
  // ============================================================
  useEffect(() => {
    if (!currentUser?.uid) return;

    setLoading(true);
    const userField = currentMode === 'buyer' ? 'buyerId' : 'sellerId';
    const dealsRef = collection(db, 'deals');
    const q = query(dealsRef, where(userField, '==', currentUser.uid));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedDeals = snapshot.docs
        .map(doc => ({
          id: doc.id,
          ...doc.data()
        }));
      
      setDeals(fetchedDeals);
      
      console.log("📊 Deals loaded:", {
        total: fetchedDeals.length,
        active: fetchedDeals.filter(d => d.status === 'active').length,
        pending: fetchedDeals.filter(d => d.status === 'pending').length,
        completed: fetchedDeals.filter(d => d.status === 'completed').length,
        cancelled: fetchedDeals.filter(d => d.status === 'cancelled').length
      });
      
      setLoading(false);
    }, (error) => {
      console.error("Error loading deals:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [currentMode, currentUser?.uid]);

  // ============================================================
  // ✅ Timer Effect - ফিক্সড
  // ============================================================
  useEffect(() => {
    if (!selectedDeal || selectedDeal.status !== 'active') return;
    
    const deadlineDays = selectedDeal.deadline || 0;
    const createdAt = selectedDeal.startedAt || selectedDeal.createdAt;
    
    if (!createdAt) return;
    
    const startDate = new Date(createdAt);
    const deadlineDate = new Date(startDate);
    deadlineDate.setDate(deadlineDate.getDate() + deadlineDays);
    
    const updateTimer = () => {
      const now = new Date();
      const diff = deadlineDate - now;
      
      if (diff <= 0) {
        setTimeRemaining(prev => ({ 
          ...prev, 
          [selectedDeal.id]: '⏰ Deadline Passed' 
        }));
        
        (async () => {
          if (!selectedDeal.deadlineNotified) {
            try {
              await sendDeadlinePassedNotification(
                selectedDeal.sellerId,
                selectedDeal.buyerId,
                selectedDeal.postTitle || 'Untitled Deal',
                selectedDeal.id
              );
              
              const dealRef = doc(db, 'deals', selectedDeal.id);
              await updateDoc(dealRef, {
                deadlineNotified: true,
                deadlineNotifiedAt: new Date().toISOString()
              });
            } catch (error) {
              console.error("Error sending deadline notification:", error);
            }
          }
        })();
        
        return;
      }
      
      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      
      setTimeRemaining(prev => ({
        ...prev,
        [selectedDeal.id]: `${days}d ${hours}h ${minutes}m`
      }));
    };
    
    updateTimer();
    const interval = setInterval(updateTimer, 60000);
    
    return () => clearInterval(interval);
  }, [selectedDeal]);

  // ============================================================
  // ✅ Fetch Specific Deal
  // ============================================================
  useEffect(() => {
    const fetchDeal = async () => {
      if (!dealId) return;
      try {
        const dealRef = doc(db, 'deals', dealId);
        const dealSnap = await getDoc(dealRef);
        if (dealSnap.exists()) {
          setSelectedDeal({ id: dealSnap.id, ...dealSnap.data() });
        } else {
          setSelectedDeal(null);
        }
      } catch (error) {
        console.error("Error fetching deal:", error);
        setSelectedDeal(null);
      }
      setLoading(false);
    };
    fetchDeal();
  }, [dealId]);

  // ============================================================
  // ✅ Extend Deadline Function
  // ============================================================
  const handleExtendDeadline = async () => {
    if (!selectedDeal || selectedDeal.status !== 'active') return;
    
    const extraDays = prompt("How many extra days do you want to add?");
    if (!extraDays || isNaN(extraDays) || Number(extraDays) <= 0) {
      alert("Please enter a valid number of days!");
      return;
    }
    
    try {
      const dealRef = doc(db, 'deals', selectedDeal.id);
      const newDeadline = selectedDeal.deadline + Number(extraDays);
      
      await updateDoc(dealRef, {
        deadline: newDeadline,
        extendedAt: new Date().toISOString(),
        extendedBy: currentUser?.uid,
        deadlineNotified: false
      });
      
      setSelectedDeal(prev => ({ 
        ...prev, 
        deadline: newDeadline 
      }));
      
      alert(`✅ Deadline extended by ${extraDays} days. New deadline: ${newDeadline} days.`);
      
    } catch (error) {
      console.error("Error extending deadline:", error);
      alert("Failed to extend deadline.");
    }
  };

  // ============================================================
  // ✅ Request Review (Seller)
  // ============================================================
  const handleRequestReview = async (milestoneId) => {
    if (!selectedDeal) return;
    
    const milestone = selectedDeal.milestones.find(m => m.id === milestoneId);
    if (!milestone || milestone.status !== 'funded') {
      alert("This milestone is not ready for review!");
      return;
    }

    try {
      const dealRef = doc(db, 'deals', selectedDeal.id);
      const updatedMilestones = selectedDeal.milestones.map((m) => {
        if (m.id === milestoneId) {
          return { ...m, status: 'review' };
        }
        return m;
      });

      await updateDoc(dealRef, { milestones: updatedMilestones });
      setSelectedDeal({ ...selectedDeal, milestones: updatedMilestones });
      
      await sendMilestoneNotification(
        selectedDeal.buyerId,
        selectedDeal.sellerId,
        milestone.title,
        selectedDeal.postTitle || 'Untitled Deal',
        selectedDeal.id,
        currentUser?.displayName || 'Someone'
      );
      
      alert("✅ Review requested! Buyer will check your work.");
    } catch (error) {
      console.error("Error:", error);
      alert("Failed to request review.");
    }
  };

  // ============================================================
  // ✅ Update Milestone Status
  // ============================================================
  const updateMilestoneStatus = async (milestoneId, newStatus) => {
    if (!selectedDeal || !selectedDeal.id) {
      alert("No deal selected!");
      return;
    }
    
    try {
      const dealRef = doc(db, 'deals', selectedDeal.id);
      const milestone = selectedDeal.milestones.find(m => m.id === milestoneId);
      
      const updatedMilestones = selectedDeal.milestones.map((m) => {
        if (m.id === milestoneId) {
          return { ...m, status: newStatus };
        }
        return m;
      });

      const allReleased = updatedMilestones.every(m => m.status === 'released');
      const updateData = { milestones: updatedMilestones };
      
      if (allReleased) {
        updateData.status = 'completed';
        updateData.completedAt = new Date().toISOString();
        alert("🎉 All milestones completed! Deal is now finished.");
      }
      
      if (newStatus === 'funded' && selectedDeal.status === 'pending') {
        updateData.status = 'active';
        updateData.startedAt = new Date().toISOString();
      }
      
      await updateDoc(dealRef, updateData);
      setSelectedDeal({ 
        ...selectedDeal, 
        milestones: updatedMilestones,
        ...(updateData.status && { status: updateData.status })
      });
      
      if (newStatus === 'released') {
        await sendPaymentNotification(
          selectedDeal.sellerId,
          milestone.amount,
          'seller',
          selectedDeal.postTitle || 'Untitled Deal',
          selectedDeal.id
        );
      }
      
      alert(`✅ Milestone status updated to ${newStatus}!`);
    } catch (error) {
      console.error("Error updating milestone:", error);
      alert("Failed to update milestone.");
    }
  };

  // ============================================================
  // ✅ Confirm Deal (Buyer ONLY)
  // ============================================================
  const handleConfirmDeal = async () => {
    if (!selectedDeal || selectedDeal.status !== 'pending') {
      alert("No pending deal to confirm!");
      return;
    }

    // 🔥 পারমিশন চেক - শুধুমাত্র বায়ার কনফার্ম করতে পারে
    if (currentMode !== 'buyer') {
      alert("⚠️ Only the buyer can confirm a deal!");
      return;
    }

    // 🔥 চেক করুন বর্তমান ইউজার বায়ার কিনা
    if (selectedDeal.buyerId !== currentUser?.uid) {
      alert("⚠️ You are not the buyer of this deal!");
      return;
    }

    try {
      const dealRef = doc(db, 'deals', selectedDeal.id);
      await updateDoc(dealRef, { 
        status: 'active',
        confirmedAt: new Date().toISOString(),
        startedAt: new Date().toISOString()
      });
      setSelectedDeal(prev => ({ ...prev, status: 'active', startedAt: new Date().toISOString() }));
      
      await sendDealNotification(
        selectedDeal.buyerId,
        selectedDeal.sellerId,
        selectedDeal.postTitle || 'Untitled Deal',
        selectedDeal.id
      );
      
      alert("🎉 Deal confirmed! Work can now begin.");
    } catch (error) {
      console.error("Error:", error);
      alert("Failed to confirm deal.");
    }
  };

  // ============================================================
  // ✅ Cancel Deal Request - ফিক্সড
  // ============================================================
  const handleCancelDeal = async () => {
    if (!selectedDeal || isProcessing) return; 

    if (selectedDeal.status === 'completed') {
      alert("Cannot cancel a completed deal!");
      return;
    }
    
    if (selectedDeal.status === 'cancelled') {
      alert("This deal is already cancelled!");
      return;
    }
    
    if (selectedDeal.cancelRequestedBy) {
      alert("A cancellation request is already pending.");
      return;
    }

    const hasPayment = selectedDeal.milestones?.some(m => m.status === 'funded' || m.status === 'released');
    if (hasPayment) {
      alert("⚠️ This deal has payments made. Cannot cancel. Please contact support.");
      return;
    }
    
    const isBuyer = currentMode === 'buyer';
    const otherPartyName = isBuyer ? 'Seller' : 'Buyer';
    
    if (!window.confirm(`⚠️ Are you sure you want to request cancellation?\n\nYou are the ${isBuyer ? 'Buyer' : 'Seller'}.`)) {
      return;
    }
    
    const reason = prompt("Please provide a reason for cancellation:");
    if (!reason || reason.trim() === '') {
      alert("Cancellation reason is required!");
      return;
    }

    setIsProcessing(true);
    
    try {
      const dealRef = doc(db, 'deals', selectedDeal.id);
      const now = new Date().toISOString();
      
      await updateDoc(dealRef, {
        cancelRequestedBy: currentUser?.uid,
        cancelRequestedAt: now,
        cancelReason: reason.trim(),
        cancelRequestStatus: 'pending',
        cancelExpiryAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
      });
      
      const otherPartyId = isBuyer ? selectedDeal.sellerId : selectedDeal.buyerId;
      await sendCancellationRequestNotification(
        otherPartyId,
        selectedDeal.postTitle || 'Untitled Deal',
        selectedDeal.id || '',
        currentUser?.displayName || currentUser?.email || 'Someone',
        reason.trim(),
        selectedDeal.budget
      );
      
      setSelectedDeal(prev => ({ 
        ...prev, 
        cancelRequestedBy: currentUser?.uid,
        cancelRequestedAt: now,
        cancelReason: reason.trim(),
        cancelRequestStatus: 'pending'
      }));
      
      alert(`✅ Cancellation request sent to ${otherPartyName}.`);
      
    } catch (error) {
      console.error("Error requesting cancellation:", error);
      alert("Failed to request cancellation.");
    } finally {
      setIsProcessing(false);
    }
  };

  // ============================================================
  // ✅ Cancel Response - ফিক্সড (সিঙ্গেল ফাংশন)
  // ============================================================
  const handleCancelResponse = async (response) => {
    if (!selectedDeal || !selectedDeal.id) return;

    const dealRef = doc(db, 'deals', selectedDeal.id);
    const isBuyer = currentMode === 'buyer';

    // --- REJECT ---
    if (response === 'reject') {
      const isCancelRequest = selectedDeal.cancelRequestStatus === 'pending';
      
      const result = await Swal.fire({
        title: 'আপনি কি নিশ্চিত?',
        text: isCancelRequest ? "ক্যানসেল রিকোয়েস্ট রিজেক্ট করলে ডিলটি অ্যাক্টিভ থাকবে।" : "অফারটি রিজেক্ট এবং ডিলিট করতে চান?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'হ্যাঁ, রিজেক্ট করুন'
      });

      if (!result.isConfirmed) return;

      try {
        if (isCancelRequest) {
          await updateDoc(dealRef, {
            cancelRequestedBy: null,
            cancelRequestedAt: null,
            cancelReason: null,
            cancelRequestStatus: null,
            cancelExpiryAt: null
          });

          await deleteCancelNotifications(selectedDeal.id);

          setSelectedDeal(prev => ({ 
            ...prev, 
            cancelRequestedBy: null, 
            cancelRequestStatus: null 
          }));
          
          Swal.fire('সফল!', 'ক্যানসেল রিকোয়েস্ট রিজেক্ট করা হয়েছে।', 'success');
        } else {
          await deleteDoc(dealRef);
          setDeals(prev => prev.filter(d => d.id !== selectedDeal.id));
          setSelectedDeal(null);
          navigate('/deal-manager');
          Swal.fire('মুছে ফেলা হয়েছে!', 'অফারটি ডিলিট করা হয়েছে।', 'error');
        }
      } catch (error) {
        console.error("Error in reject:", error);
        Swal.fire('ত্রুটি!', 'অপারেশনটি ব্যর্থ হয়েছে।', 'error');
      }
    }

    // --- APPROVE ---
    if (response === 'approve') {
      try {
        // 🔥 A: নতুন অফার (Pending -> Active) - শুধুমাত্র বায়ার কনফার্ম করতে পারে
        if (selectedDeal.status === 'pending' && !selectedDeal.cancelRequestStatus) {
          // পারমিশন চেক
          if (currentMode !== 'buyer' || selectedDeal.buyerId !== currentUser?.uid) {
            Swal.fire('সতর্কতা', 'শুধুমাত্র বায়ার ডিল কনফার্ম করতে পারে!', 'warning');
            return;
          }
          
          await updateDoc(dealRef, { 
            status: 'active', 
            startedAt: new Date().toISOString() 
          });
          
          setSelectedDeal(prev => ({ ...prev, status: 'active' }));
          Swal.fire('সফল!', 'ডিলটি এখন অ্যাক্টিভ!', 'success');
          return;
        }

        // 🔥 B: ক্যানসেল রিকোয়েস্ট এপ্রুভ - অন্য পক্ষ অ্যাপ্রুভ করতে পারে
        if (selectedDeal.cancelRequestStatus === 'pending') {
          // চেক করুন নিজের রিকোয়েস্ট নিজে অ্যাপ্রুভ করতে পারবে না
          if (selectedDeal.cancelRequestedBy === currentUser?.uid) {
            Swal.fire('সতর্কতা', "আপনি নিজের রিকোয়েস্ট নিজে এপ্রুভ করতে পারবেন না।", 'warning');
            return;
          }

          // চেক করুন অন্য পক্ষ অ্যাপ্রুভ করতে পারে কিনা
          const isOtherParty = (isBuyer && selectedDeal.buyerId === currentUser?.uid) ||
                              (!isBuyer && selectedDeal.sellerId === currentUser?.uid);
          
          if (!isOtherParty) {
            Swal.fire('সতর্কতা', "আপনি এই ডিলের সাথে সম্পর্কিত নন!", 'warning');
            return;
          }

          await updateDoc(dealRef, {
            status: 'cancelled',
            cancelRequestStatus: 'approved',
            cancelledAt: new Date().toISOString(),
            cancelledBy: currentUser?.uid
          });

          await deleteCancelNotifications(selectedDeal.id);

          await sendCancellationApprovedNotification(
            selectedDeal.buyerId,
            selectedDeal.sellerId,
            selectedDeal.postTitle || 'Untitled Deal',
            selectedDeal.id
          );

          setSelectedDeal(prev => ({ ...prev, status: 'cancelled' }));
          Swal.fire('সফল!', 'ডিলটি ক্যানসেল করা হয়েছে।', 'success');
          
          setTimeout(() => navigate('/deal-manager'), 1500);
        }
      } catch (error) {
        console.error("Error in approve:", error);
        Swal.fire('ত্রুটি!', 'সিস্টেম এরর ঘটেছে।', 'error');
      }
    }
  };

  // ============================================================
  // ✅ Helper Functions
  // ============================================================
  const getMilestoneStatusBadge = (status) => {
    switch(status) {
      case 'pending': return { text: '⏳ Pending', class: 'status-pending' };
      case 'funded': return { text: '💰 Funded', class: 'status-funded' };
      case 'review': return { text: '📝 Under Review', class: 'status-review' };
      case 'released': return { text: '✅ Released', class: 'status-released' };
      default: return { text: '📌 New', class: 'status-pending' };
    }
  };

  const getDealStatusBadge = (status) => {
    switch(status) {
      case 'pending': return { text: '⏳ Pending Confirmation', class: 'status-pending-deal' };
      case 'active': return { text: '⚡ Active Deal', class: 'status-active' };
      case 'completed': return { text: '✅ Completed', class: 'status-completed' };
      case 'cancelled': return { text: '❌ Cancelled', class: 'status-cancelled' };
      default: return { text: '📌 New', class: 'status-pending' };
    }
  };

  // ============================================================
  // ✅ Render Functions
  // ============================================================
  const renderMilestones = () => {
    if (!selectedDeal?.milestones) return null;
    
    const isBuyer = currentMode === 'buyer';
    const isSeller = currentMode === 'seller';
    const isActive = selectedDeal.status === 'active';
    const isPending = selectedDeal.status === 'pending';
    const isCancelled = selectedDeal.status === 'cancelled';

    if (isCancelled) {
      return (
        <div className="deal-cancelled-banner">
          <i className="fa-solid fa-ban"></i>
          <h4>Deal Cancelled</h4>
          <p>Cancelled on: {selectedDeal.cancelledAt ? new Date(selectedDeal.cancelledAt).toLocaleDateString() : 'N/A'}</p>
          <p>Reason: {selectedDeal.cancellationReason || 'No reason provided'}</p>
        </div>
      );
    }

    return (
      <div className="milestone-container">
        {isPending && (
          <div className="confirm-deal-banner">
            <p><i className="fa-solid fa-gavel"></i> A proposal has been sent to you!</p>
            
            <div style={{ display: 'flex', gap: '10px' }}>
              {/* 🔥 শুধুমাত্র বায়ার কনফার্ম করতে পারে */}
              {currentMode === 'buyer' && selectedDeal.buyerId === currentUser?.uid ? (
                <>
                  <button className="btn-confirm-deal" onClick={handleConfirmDeal}>
                    <i className="fa-solid fa-check-circle"></i> Confirm & Start Deal
                  </button>
                  <button 
                    className="btn-cancel-deal" 
                    style={{ backgroundColor: '#ef4444', color: 'white' }} 
                    onClick={() => handleCancelResponse('reject')} 
                  >
                    <i className="fa-solid fa-times-circle"></i> Reject Offer
                  </button>
                </>
              ) : (
                <span className="pending-message">⏳ Waiting for buyer to confirm...</span>
              )}
            </div>
          </div>
        )}

        {selectedDeal.milestones.map((milestone, index) => {
          const statusBadge = getMilestoneStatusBadge(milestone.status);
          
          return (
            <div key={milestone.id} className={`milestone-row ${milestone.status}`}>
              <div className="m-info-block">
                <div className="m-number">{String(index + 1).padStart(2, '0')}</div>
                <div className="m-details">
                  <h4>{milestone.title}</h4>
                  <p className="m-amount">💰 Amount: {milestone.amount?.toLocaleString()} BDT</p>
                </div>
              </div>
              
              <div className="m-status-side">
                <span className={`status-badge ${statusBadge.class}`}>
                  {statusBadge.text}
                </span>
                
                {isActive && isBuyer && milestone.status === 'pending' && (
                  <button 
                    className="btn-fund" 
                    onClick={() => navigate(`/payment/${selectedDeal.id}/${milestone.id}`)}
                  >
                    <i className="fa-solid fa-credit-card"></i> Pay & Fund
                  </button>
                )}
                
                {isActive && isSeller && milestone.status === 'funded' && (
                  <button className="btn-request-review" onClick={() => handleRequestReview(milestone.id)}>
                    <i className="fa-solid fa-check-double"></i> Request Review
                  </button>
                )}
                
                {isActive && isBuyer && milestone.status === 'review' && (
                  <button className="btn-release" onClick={() => updateMilestoneStatus(milestone.id, 'released')}>
                    <i className="fa-solid fa-money-bill-wave"></i> Release Payment
                  </button>
                )}
                
                {milestone.status === 'released' && (
                  <span className="badge-completed">
                    <i className="fa-solid fa-check-circle"></i> Payment Released
                  </span>
                )}
              </div>
            </div>
          );
        })}
        
        {selectedDeal.status === 'completed' && (
          <div className="deal-completed-banner">
            <i className="fa-solid fa-trophy"></i>
            <h4>Deal Completed!</h4>
            <p>All milestones have been completed and payments released.</p>
          </div>
        )}
      </div>
    );
  };

  // ============================================================
  // ✅ Main Render
  // ============================================================
  if (loading) {
    return (
      <div className="dashboard-container-wrapper">
        <div className="loading-state">
          <div className="loading-spinner"></div>
          <p>Loading deals...</p>
        </div>
      </div>
    );
  }

  const cancelledDeals = deals.filter(deal => deal.status === 'cancelled');
  const activeDeals = deals.filter(deal => deal.status !== 'cancelled');
  const pendingCount = deals.filter(d => d.status === 'pending').length;
  const activeCount = deals.filter(d => d.status === 'active').length;
  const completedCount = deals.filter(d => d.status === 'completed').length;
  const totalDeals = deals.length;

  return (
    <div className="dashboard-container-wrapper">
      <div className="dashboard-wrapper">
        
        {/* Mode Switcher */}
        <div className="deal-mode-switcher">
          <button 
            className={`mode-switch-btn ${currentMode === 'buyer' ? 'active' : ''}`}
            onClick={() => handleModeChange('buyer')}
          >
            <i className="fa-solid fa-briefcase"></i> Buyer Mode
            {pendingCount > 0 && currentMode === 'buyer' && (
              <span className="mode-badge-count">{pendingCount}</span>
            )}
          </button>
          <button 
            className={`mode-switch-btn ${currentMode === 'seller' ? 'active' : ''}`}
            onClick={() => handleModeChange('seller')}
          >
            <i className="fa-solid fa-laptop-code"></i> Seller Mode
            {pendingCount > 0 && currentMode === 'seller' && (
              <span className="mode-badge-count">{pendingCount}</span>
            )}
          </button>
          
          <button 
            className={`mode-switch-btn ${showCancelledDeals ? 'active cancelled-active' : 'cancelled-btn'}`}
            onClick={() => setShowCancelledDeals(!showCancelledDeals)}
          >
            <i className="fa-solid fa-ban"></i> Cancelled ({cancelledDeals.length})
          </button>
        </div>

        {/* Deals Stats */}
        <div className="deals-stats">
          <span className="stat-item total">📊 Total: {totalDeals}</span>
          <span className="stat-item pending">⏳ Pending: {pendingCount}</span>
          <span className="stat-item active">⚡ Active: {activeCount}</span>
          <span className="stat-item completed">✅ Completed: {completedCount}</span>
          <span className="stat-item cancelled">❌ Cancelled: {cancelledDeals.length}</span>
        </div>

        {/* Specific Deal Selected */}
        {dealId && selectedDeal ? (
          <>
            <div className="dash-header">
              <div className="project-meta">
                <button className="back-to-list" onClick={() => navigate('/deal-manager')}>
                  <i className="fa-solid fa-arrow-left"></i> Back
                </button>
                
                <div className="deal-title-section">
                  <h2>{selectedDeal.postTitle || 'Deal Dashboard'}</h2>
                  
                  <div className="deal-partner-info">
                    <span className="partner-label">
                      {currentMode === 'buyer' ? '🤝 Seller' : '🤝 Buyer'}:
                    </span>
                    <span className="partner-name">
                      {currentMode === 'buyer' 
                        ? (selectedDeal.sellerName || selectedDeal.sellerDisplayName || 'Unknown Seller')
                        : (selectedDeal.buyerName || selectedDeal.buyerDisplayName || 'Unknown Buyer')}
                    </span>
                  </div>
                  
                  <div className="deal-id-display">
                    <span className="deal-id-label">Deal ID:</span>
                    <span className="deal-id-number">
                      #{selectedDeal.dealIdNumber || selectedDeal.id?.slice(-8)}
                    </span>
                    <button className="copy-id-btn" onClick={() => {
                      navigator.clipboard.writeText(selectedDeal.dealIdNumber || selectedDeal.id);
                      alert('✅ Deal ID copied!');
                    }}>
                      <i className="fa-regular fa-copy"></i>
                    </button>
                  </div>
                </div>
                
                <span className={`mode-badge ${selectedDeal.status}`}>
                  {getDealStatusBadge(selectedDeal.status).text}
                </span>
                {selectedDeal.status === 'active' && timeRemaining[selectedDeal.id] && (
                  <span className="timer-badge">
                    <i className="fa-solid fa-clock"></i> {timeRemaining[selectedDeal.id]}
                  </span>
                )}
              </div>
            </div>

            {/* Extend Deadline */}
            {selectedDeal.status === 'active' && (
              <div className="extend-deadline-section">
                <button className="btn-extend-deadline" onClick={handleExtendDeadline}>
                  <i className="fa-solid fa-clock"></i> Extend Deadline
                </button>
              </div>
            )}

            {/* Cancellation Request Banner */}
            {selectedDeal.cancelRequestStatus === 'pending' && (
              <div className="cancel-request-banner pending">
                <i className="fa-solid fa-clock"></i>
                <div>
                  <h4>Cancellation Request Pending</h4>
                  <p>
                    {selectedDeal.cancelRequestedBy === currentUser?.uid 
                      ? `Waiting for ${currentMode === 'buyer' ? 'Seller' : 'Buyer'} to respond...` 
                      : `The ${currentMode === 'buyer' ? 'Seller' : 'Buyer'} has requested to cancel this deal.`}
                  </p>
                  <p className="cancel-reason"><strong>Reason:</strong> {selectedDeal.cancelReason || 'No reason provided'}</p>
                </div>
                {selectedDeal.cancelRequestedBy !== currentUser?.uid && (
                  <div className="cancel-response-btns">
                    <button className="btn-agree" onClick={() => handleCancelResponse('approve')}>
                      <i className="fa-solid fa-check"></i> Agree to Cancel
                    </button>
                    <button className="btn-reject" onClick={() => handleCancelResponse('reject')}>
                      <i className="fa-solid fa-times"></i> Reject
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* Deal Info */}
            <div className="deal-info-card">
              <div className="deal-info-row">
                <span><i className="fa-solid fa-hashtag"></i> Deal ID:</span>
                <strong className="deal-id-highlight">
                  #{selectedDeal.dealIdNumber || selectedDeal.id?.slice(-8)}
                </strong>
              </div>
              
              <div className="deal-info-row partner-row">
                <span><i className="fa-solid fa-user"></i> {currentMode === 'buyer' ? 'Seller' : 'Buyer'}:</span>
                <strong>
                  {currentMode === 'buyer' 
                    ? (selectedDeal.sellerName || selectedDeal.sellerDisplayName || 'Unknown Seller')
                    : (selectedDeal.buyerName || selectedDeal.buyerDisplayName || 'Unknown Buyer')}
                </strong>
              </div>
              
              <div className="deal-info-row">
                <span><i className="fa-solid fa-wallet"></i> Total Budget:</span>
                <strong>{selectedDeal.budget?.toLocaleString()} BDT</strong>
              </div>
              <div className="deal-info-row">
                <span><i className="fa-regular fa-calendar"></i> Deadline:</span>
                <strong>{selectedDeal.deadline} Days</strong>
              </div>
              {selectedDeal.status === 'active' && (
                <div className="deal-info-row">
                  <span><i className="fa-solid fa-clock"></i> Time Remaining:</span>
                  <strong className="timer-display">
                    {timeRemaining[selectedDeal.id] || 'Calculating...'}
                  </strong>
                </div>
              )}
              <div className="deal-info-row">
                <span><i className="fa-solid fa-file-lines"></i> Details:</span>
                <p>{selectedDeal.details || 'No details provided'}</p>
              </div>
            </div>

            {/* Milestones */}
            {renderMilestones()}

            {/* Cancel Button */}
            {(selectedDeal.status === 'pending' || selectedDeal.status === 'active') && 
             !selectedDeal.cancelRequestedBy && (
              <div className="cancel-deal-section">
                <button className="btn-cancel-deal" onClick={handleCancelDeal}>
                  <i className="fa-solid fa-ban"></i> Request Cancellation
                </button>
                <p className="cancel-warning">
                  <i className="fa-solid fa-info-circle"></i> 
                  Your request must be approved by the other party.
                </p>
              </div>
            )}

          </>
        ) : (
          // Deal List
          <div className="deals-list">
            {showCancelledDeals ? (
              cancelledDeals.length === 0 ? (
                <div className="no-deal-selected">
                  <i className="fa-solid fa-check-circle"></i>
                  <p>No cancelled deals</p>
                </div>
              ) : (
                cancelledDeals.map(deal => (
                  <div key={deal.id} className="deal-list-item cancelled" onClick={() => navigate(`/deal-manager?dealId=${deal.id}`)}>
                    <div className="deal-list-info">
                      <h4>
                        {deal.postTitle || 'Untitled Deal'}
                        <span className="deal-id-badge">#{deal.dealIdNumber || deal.id?.slice(-8)}</span>
                      </h4>
                      <p className="deal-partner cancelled">
                        <i className="fa-solid fa-user"></i> 
                        {currentMode === 'buyer' ? 'Seller' : 'Buyer'}: <strong>
                          {currentMode === 'buyer' 
                            ? (deal.sellerName || deal.sellerDisplayName || 'Unknown Seller')
                            : (deal.buyerName || deal.buyerDisplayName || 'Unknown Buyer')}
                        </strong>
                      </p>
                      <p>
                        <i className="fa-solid fa-ban" style={{color: '#ef4444'}}></i>
                        {deal.cancellationReason || 'No reason provided'}
                      </p>
                      <p className="deal-cancelled-date">
                        <i className="fa-regular fa-calendar"></i>
                        {deal.cancelledAt ? new Date(deal.cancelledAt).toLocaleDateString() : 'Unknown'}
                      </p>
                    </div>
                    <div className="deal-list-status">
                      <span className="status-badge cancelled">❌ Cancelled</span>
                    </div>
                  </div>
                ))
              )
            ) : (
              activeDeals.length === 0 ? (
                <div className="no-deal-selected">
                  <i className="fa-solid fa-folder-open"></i>
                  <p>You don't have any {currentMode === 'buyer' ? 'buyer' : 'seller'} deals yet.</p>
                </div>
              ) : (
                activeDeals.map(deal => (
                  <div key={deal.id} className="deal-list-item" onClick={() => navigate(`/deal-manager?dealId=${deal.id}`)}>
                    <div className="deal-list-info">
                      <h4>
                        {deal.postTitle || 'Untitled Deal'}
                        <span className="deal-id-badge">#{deal.dealIdNumber || deal.id?.slice(-8)}</span>
                      </h4>
                      <p className="deal-partner">
                        <i className="fa-solid fa-user"></i> 
                        {currentMode === 'buyer' ? 'Seller' : 'Buyer'}: <strong>
                          {currentMode === 'buyer' 
                            ? (deal.sellerName || deal.sellerDisplayName || 'Unknown Seller')
                            : (deal.buyerName || deal.buyerDisplayName || 'Unknown Buyer')}
                        </strong>
                      </p>
                      <p>Budget: {deal.budget?.toLocaleString()} BDT</p>
                      {deal.status === 'active' && timeRemaining[deal.id] && (
                        <p className="deal-timer">
                          <i className="fa-solid fa-clock"></i> {timeRemaining[deal.id]}
                        </p>
                      )}
                    </div>
                    <div className="deal-list-status">
                      <span className={`status-badge ${deal.status}`}>
                        {deal.status === 'pending' && '⏳ Pending'}
                        {deal.status === 'active' && '⚡ Active'}
                        {deal.status === 'completed' && '✅ Completed'}
                      </span>
                    </div>
                  </div>
                ))
              )
            )}
          </div>
        )}
      </div>
    </div> 
  );
};

export default DealManager;