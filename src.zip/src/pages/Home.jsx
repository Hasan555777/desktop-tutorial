// src/pages/Home.jsx
import React, { useState, useEffect, useMemo } from 'react';
import { useParams, useLocation, useNavigate } from 'react-router-dom';
import { db } from '../firebase';
import { collection, query, where, orderBy, onSnapshot } from 'firebase/firestore';
import JobCard from './JobCard';
import './Home.css';

function Home({ 
  currentMode, 
  currentUser, 
  searchTerm = '', 
  highlightText: propHighlightText, 
  onBidAndChatClick 
}) {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // URL থেকে postId বের করুন
  const { postId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  
  const searchParams = new URLSearchParams(location.search);
  const postIdFromQuery = searchParams.get('postId');
  const targetPostId = postId || postIdFromQuery;
  const [highlightedPostId, setHighlightedPostId] = useState(targetPostId);

  const highlightText = propHighlightText || ((text, searchTerm) => {
    if (!searchTerm || !text || searchTerm.trim() === '') return text;
    try {
      const regex = new RegExp(`(${searchTerm.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
      const parts = text.split(regex);
      return parts.map((part, index) => 
        regex.test(part) ? 
          <mark key={index} className="search-highlight">{part}</mark> : 
          part
      );
    } catch (error) {
      return text;
    }
  });

  // ============================================================
  // ✅ Firebase রিয়েল-টাইম লিসেনার (ক্লিন এবং ফিক্সড)
  // ============================================================
  useEffect(() => {
    console.log("🔥 Home: Setting up posts listener for mode:", currentMode);
    setLoading(true);
    
    const postsRef = collection(db, 'posts');
    let q;
    
    if (currentMode === 'freelancer') {
      q = query(postsRef, 
        where('type', 'in', ['service', 'freelancer']),
        orderBy('createdAt', 'desc')
      );
    } else if (currentMode === 'buyer') {
      q = query(postsRef, 
        where('type', 'in', ['hire', 'buyer']),
        orderBy('createdAt', 'desc')
      );
    } else {
      q = query(postsRef, orderBy('createdAt', 'desc'));
    }

    const unsubscribe = onSnapshot(q, 
      (snapshot) => {
        console.log("🔥 Home: Real-time update received! Docs:", snapshot.docs.length);
        
        // ডকুমেন্টগুলো ম্যাপ করুন
        const postsArray = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        }));

        // ✅ createdAt অনুযায়ী সর্ট করুন (নতুন উপরে)
        postsArray.sort((a, b) => {
          const timeA = a.createdAt?.toDate ? a.createdAt.toDate() : new Date(a.createdAt || 0);
          const timeB = b.createdAt?.toDate ? b.createdAt.toDate() : new Date(b.createdAt || 0);
          return timeB - timeA;
        });

        console.log("📊 Home: Posts loaded:", postsArray.length);
        setPosts(postsArray);
        setLoading(false);
      }, 
      (error) => {
        console.error("❌ Home: Error fetching posts:", error);
        setLoading(false);
      }
    );

    // ✅ ক্লিনআপ - লিসেনার বন্ধ করুন
    return () => {
      console.log("🔥 Home: Cleaning up posts listener");
      unsubscribe();
    };
  }, [currentMode]);

  // ============================================================
  // ✅ হাইলাইটেড পোস্টে স্ক্রল করুন
  // ============================================================
  useEffect(() => {
    if (!loading && highlightedPostId && posts.length > 0) {
      const postExists = posts.some(p => p.id === highlightedPostId);
      
      if (!postExists) {
        console.log("⚠️ Post not found in current list");
        return;
      }
      
      setTimeout(() => {
        const postElement = document.getElementById(`post-${highlightedPostId}`);
        
        if (postElement) {
          console.log("✅ Found post element, scrolling...");
          postElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
          postElement.classList.add('highlight-post');
          
          setTimeout(() => {
            postElement.classList.remove('highlight-post');
          }, 3000);
        }
      }, 1000);
    }
  }, [loading, highlightedPostId, posts]);

  // ============================================================
  // ✅ সার্চ ফিল্টার
  // ============================================================
  const filteredBySearch = useMemo(() => {
    if (!searchTerm || searchTerm.trim() === '') {
      return posts;
    }
    
    const term = searchTerm.toLowerCase();
    return posts.filter(post => 
      post.title?.toLowerCase().includes(term) ||
      post.description?.toLowerCase().includes(term) ||
      post.clientName?.toLowerCase().includes(term)
    );
  }, [posts, searchTerm]);

  // ============================================================
  // ✅ পোস্ট ফরম্যাটিং + ডুপ্লিকেট রিমুভ
  // ============================================================
  const uniquePosts = useMemo(() => {
    const formatted = filteredBySearch
      .filter(post => post && post.id)
      .map(post => ({
        id: post.id,
        clientName: post.clientName || post.sender || (post.type === 'hire' ? "Job Poster" : "Service Provider"),
        clientPhoto: post.userPhotoURL || post.clientPhoto || post.photoURL || null,
        avatarBg: "linear-gradient(135deg, #f59e0b, #d97706)",
        avatarInitial: (post.clientName || post.sender || "U").charAt(0).toUpperCase(),
        verified: post.verified || false,
        time: post.createdAt, // ✅ Firebase Timestamp পাঠান
        createdAt: post.createdAt,
        title: post.title || "Untitled",
        description: post.description || "No description provided",
        budget: post.budget || post.price || 0,
        deadline: post.deadline || (post.deliveryDays ? `${post.deliveryDays} Days` : "N/A"),
        proposals: post.proposals || 0,
        images: post.images && post.images.length > 0 ? post.images : [],
        postImage: (post.images && post.images[0]) || post.postImage || null,
        type: post.type || (currentMode === 'freelancer' ? 'service' : 'hire'),
        userId: post.userId,
        clientEmail: post.clientEmail
      }));

    // ডুপ্লিকেট রিমুভ
    const map = new Map();
    formatted.forEach(post => {
      if (!map.has(post.id)) {
        map.set(post.id, post);
      }
    });
    
    return Array.from(map.values());
  }, [filteredBySearch, currentMode]);

  // ============================================================
  // ✅ লোডিং স্টেট
  // ============================================================
  if (loading) {
    return (
      <div className="home-wrapper">
        <main className="home-content">
          <div className="loading-feed-state">
            <div className="loading-spinner"></div>
            <p>Loading posts...</p>
          </div>
        </main>
      </div>
    );
  }

  // ============================================================
  // ✅ রেন্ডার
  // ============================================================
  return (
    <div className="home-wrapper">
      <main className="home-content">
        <div className="home-feed-posts-list">
          {uniquePosts.length === 0 ? (
            <div className="empty-feed-state">
              <i className="fa-solid fa-folder-open"></i>
              <p>
                {searchTerm 
                  ? `No posts found for "${searchTerm}"` 
                  : 'No posts available in this category right now.'}
              </p>
              <small>
                {searchTerm 
                  ? 'Try a different search term' 
                  : 'Be the first to create a post!'}
              </small>
              {searchTerm && (
                <button 
                  className="clear-search-btn"
                  onClick={() => navigate('/')}
                >
                  <i className="fa-solid fa-times"></i> Clear Search
                </button>
              )}
            </div>
          ) : (
            <>
              {/* পোস্ট কাউন্ট */}
              {/* <div className="posts-count-indicator">
                <span>
                  <i className="fa-solid fa-file-alt"></i> 
                  {uniquePosts.length} {uniquePosts.length === 1 ? 'Post' : 'Posts'} found
                </span>
                {searchTerm && (
                  <span className="search-term-badge">
                    <i className="fa-solid fa-search"></i> {searchTerm}
                  </span>
                )}
              </div>
               */}
              {/* পোস্ট লিস্ট */}
              {uniquePosts.map((post) => (
                <JobCard 
                  key={post.id}
                  id={`post-${post.id}`}
                  job={post} 
                  userId={post.userId}
                  currentUser={currentUser}
                  searchTerm={searchTerm}
                  highlightText={highlightText}
                  onBidAndChatClick={() => {
                    if (onBidAndChatClick) {
                      onBidAndChatClick(post);
                    }
                  }}
                />
              ))}
            </>
          )}
        </div>
      </main>
    </div>
  );
}

export default Home;