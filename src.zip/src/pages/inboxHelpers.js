import { serverTimestamp } from 'firebase/firestore';

// ============================================================
// ✅ টাইম ফরম্যাট ফাংশন
// ============================================================
export const formatLastSeen = (timestamp) => {
  if (!timestamp) return 'Offline';
  
  let date;
  if (timestamp.toDate) {
    date = timestamp.toDate();
  } else if (timestamp.seconds) {
    date = new Date(timestamp.seconds * 1000);
  } else {
    date = new Date(timestamp);
  }
  
  const now = new Date();
  const diffMs = now - date;
  const diffSec = Math.floor(diffMs / 1000);
  const diffMin = Math.floor(diffSec / 60);
  const diffHour = Math.floor(diffMin / 60);
  const diffDay = Math.floor(diffHour / 24);
  
  if (diffSec < 60) return 'Just now';
  if (diffMin < 60) return `${diffMin}m ago`;
  if (diffHour < 24) return `${diffHour}h ago`;
  if (diffDay < 7) return `${diffDay}d ago`;
  return date.toLocaleDateString();
};

// ============================================================
// ✅ নরমালাইজড চ্যাট অবজেক্ট তৈরি (সঠিক ডেটা সহ)
// ============================================================
export const createNormalizedChatObject = (chat, currentUser) => {
  if (!chat || !currentUser) return null;
  
  // ✅ অন্য পক্ষের আইডি সঠিকভাবে বের করুন
  let otherId = chat.participants?.find(p => p !== currentUser?.uid);
  
  if (!otherId) {
    if (chat.buyerId === currentUser.uid) {
      otherId = chat.sellerId;
    } else if (chat.sellerId === currentUser.uid) {
      otherId = chat.buyerId;
    } else {
      otherId = chat.otherPartyId || chat.userId || chat.ownerId;
    }
  }
  
  // ✅ বর্তমান ইউজার কে?
  const isBuyer = chat.buyerId === currentUser?.uid;
  const isSeller = chat.sellerId === currentUser?.uid;
  
  // ✅ অন্য পক্ষের নাম সঠিকভাবে বের করুন
  let otherPartyName = chat.otherPartyName;
  if (!otherPartyName) {
    if (isBuyer) {
      otherPartyName = chat.sellerName || chat.otherPartyName || 'Seller';
    } else if (isSeller) {
      otherPartyName = chat.buyerName || chat.otherPartyName || 'Buyer';
    } else {
      otherPartyName = chat.clientName || chat.userName || chat.sender || 'User';
    }
  }
  
  // ✅ অন্য পক্ষের ফটো সঠিকভাবে বের করুন
  let otherPartyPhoto = chat.otherPartyPhoto;
  if (!otherPartyPhoto) {
    if (isBuyer) {
      otherPartyPhoto = chat.sellerPhoto || chat.otherPartyPhoto || null;
    } else if (isSeller) {
      otherPartyPhoto = chat.buyerPhoto || chat.otherPartyPhoto || null;
    } else {
      otherPartyPhoto = chat.clientPhoto || chat.userPhoto || chat.senderPhoto || null;
    }
  }
  
  // ✅ পোস্ট টাইটেল সঠিকভাবে বের করুন
  const postTitle = chat.postTitle || chat.title || chat.tag || 'Untitled';
  
  // ✅ পোস্ট টাইপ সঠিকভাবে বের করুন
  const postType = chat.postType || chat.type || 'hire';
  
  // ✅ ডিল স্ট্যাটাস সঠিকভাবে বের করুন
  const isActiveDeal = chat.status === 'active' || chat.isActiveDeal || false;
  const dealStatus = chat.dealStatus || chat.status || 'pending';
  
  // ✅ আনরিড কাউন্ট সঠিকভাবে বের করুন
  let unreadCount = 0;
  if (chat.unreadCount && typeof chat.unreadCount === 'object') {
    unreadCount = chat.unreadCount[currentUser.uid] || 0;
  } else if (typeof chat.unreadCount === 'number') {
    unreadCount = chat.unreadCount;
  }
  
  // ✅ ব্লক স্ট্যাটাস সঠিকভাবে বের করুন
  const isBlocked = chat.isBlocked === true && chat.blockedBy === currentUser?.uid;
  const blockedBy = chat.blockedBy || null;
  
  // ✅ ✅ ✅ নরমালাইজড অবজেক্ট
  return {
    // মৌলিক তথ্য
    id: chat.id || chat.chatId,
    chatId: chat.id || chat.chatId,
    postId: chat.postId || chat.id,
    
    // পোস্ট সম্পর্কিত তথ্য
    title: postTitle,
    postTitle: postTitle,
    description: chat.description || '',
    budget: chat.budget || 0,
    deadline: chat.deadline || 0,
    postType: postType,
    postImage: chat.postImage || chat.image || null,
    images: chat.images || [],
    
    // ইউজার আইডি
    buyerId: chat.buyerId || null,
    sellerId: chat.sellerId || null,
    userId: chat.userId || chat.buyerId || chat.sellerId || null,
    ownerId: chat.ownerId || chat.userId || chat.buyerId || chat.sellerId || null,
    otherPartyId: otherId || null,
    
    // ইউজার নাম
    buyerName: chat.buyerName || 'Buyer',
    sellerName: chat.sellerName || 'Seller',
    clientName: chat.clientName || chat.buyerName || 'Client',
    otherPartyName: otherPartyName || 'User',
    
    // ইউজার ফটো
    buyerPhoto: chat.buyerPhoto || null,
    sellerPhoto: chat.sellerPhoto || null,
    clientPhoto: chat.clientPhoto || null,
    otherPartyPhoto: otherPartyPhoto || null,
    
    // চ্যাট স্ট্যাটাস
    participants: chat.participants || [currentUser?.uid, otherId].filter(Boolean),
    unreadCount: chat.unreadCount || {},
    userUnreadCount: unreadCount,
    isUnread: unreadCount > 0,
    lastMessage: chat.lastMessage || 'Start conversation',
    updatedAt: chat.updatedAt || serverTimestamp(),
    createdAt: chat.createdAt || serverTimestamp(),
    
    // ডিল স্ট্যাটাস
    status: dealStatus,
    isActiveDeal: isActiveDeal,
    dealStatus: dealStatus,
    
    // ব্লক স্ট্যাটাস
    isBlocked: isBlocked,
    blockedBy: blockedBy,
    blockedAt: chat.blockedAt || null,
    
    // অনলাইন স্ট্যাটাস
    isOnline: chat.isOnline || false,
    
    // ট্যাগ ও প্রিভিউ
    tag: chat.tag || postTitle || 'Chat',
    preview: chat.preview || chat.lastMessage || 'Start conversation',
    time: chat.time || 'Just now',
    initial: (otherPartyName || 'U').charAt(0).toUpperCase(),
    gradient: chat.gradient || "linear-gradient(135deg, #f59e0b, #d97706)",
    
    // ✅ গুরুত্বপূর্ণ: fullData হিসেবে সম্পূর্ণ chat
    fullData: chat,
    
    // ✅ আসল chat ডেটা (রেফারেন্সের জন্য)
    _original: chat
  };
};

// ============================================================
// ✅ নতুন চ্যাট তৈরি
// ============================================================
export const createNewChatObject = (chatContext, currentUser) => {
  const postType = chatContext.type || 'hire';
  let buyerId, sellerId, buyerName, sellerName, buyerPhoto, sellerPhoto;
  
  const currentUserPhoto = currentUser.photoURL || null;
  
  if (postType === 'service') {
    sellerId = chatContext.userId || chatContext.ownerId || chatContext.uid;
    buyerId = currentUser.uid;
    sellerName = chatContext.clientName || chatContext.userName || chatContext.sender || 'Seller';
    buyerName = currentUser.displayName || currentUser.email?.split('@')[0] || 'Buyer';
    sellerPhoto = chatContext.sellerPhoto || chatContext.clientPhoto || chatContext.userPhoto || null;
    buyerPhoto = currentUserPhoto;
  } else {
    buyerId = chatContext.userId || chatContext.ownerId || chatContext.uid;
    sellerId = currentUser.uid;
    buyerName = chatContext.clientName || chatContext.userName || chatContext.sender || 'Buyer';
    sellerName = currentUser.displayName || currentUser.email?.split('@')[0] || 'Seller';
    buyerPhoto = chatContext.clientPhoto || chatContext.userPhoto || chatContext.senderPhoto || null;
    sellerPhoto = currentUserPhoto;
  }
  
  const otherPartyId = postType === 'service' ? sellerId : buyerId;
  const otherPartyName = postType === 'service' ? sellerName : buyerName;
  const otherPartyPhoto = postType === 'service' ? sellerPhoto : buyerPhoto;
  
  const chatId = chatContext.id || chatContext.postId || `chat_${Date.now()}`;
  const participants = [currentUser.uid, otherPartyId].filter(Boolean);
  const unreadCountObj = {
    [currentUser.uid]: 0,
    [otherPartyId]: 1
  };

  return {
    id: chatId,
    chatId: chatId,
    postId: chatContext.id || chatContext.postId || chatId,
    participants: participants,
    buyerId: buyerId,
    sellerId: sellerId,
    buyerName: buyerName,
    sellerName: sellerName,
    buyerPhoto: buyerPhoto,
    sellerPhoto: sellerPhoto,
    otherPartyId: otherPartyId,
    otherPartyName: otherPartyName || 'User',
    otherPartyPhoto: otherPartyPhoto || null,
    initial: (otherPartyName || "U").charAt(0).toUpperCase(),
    gradient: "linear-gradient(135deg, #f59e0b, #d97706)",
    time: "Just Now",
    tag: chatContext.title || chatContext.postTitle || "New Job Post",
    preview: "চ্যাট শুরু হয়েছে। আপনার বার্তা লিখুন...",
    isUnread: true,
    unreadCount: unreadCountObj,
    userUnreadCount: 1,
    isActiveDeal: false,
    isOnline: false,
    budget: chatContext.budget || 0,
    deadline: chatContext.deadline || 0,
    fullData: chatContext || {},
    postTitle: chatContext.title || chatContext.postTitle || "Untitled Post",
    postType: postType,
    postImage: chatContext.postImage || chatContext.image || null,
    description: chatContext.description || chatContext.details || '',
    updatedAt: serverTimestamp(),
    createdAt: serverTimestamp(),
    lastMessage: "Start conversation",
    status: 'pending',
    dealStatus: 'pending',
    isBlocked: false,
    blockedBy: null,
    blockedAt: null,
    ownerId: chatContext.userId || chatContext.ownerId || chatContext.uid
  };
};