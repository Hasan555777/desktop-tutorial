// NotificationListener.java
package com.example.paymentverifier;

import android.app.Notification;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NotificationListener extends NotificationListenerService {

    private static final String TAG = "PaymentVerifier";
    private static final String PREF_NAME = "PaymentVerifierPrefs";
    private static final String KEY_SERVER_URL = "server_url";
    private static final String DEFAULT_SERVER_URL = "https://your-server.com/api/verify-payment";
    
    private RequestQueue requestQueue;
    private SharedPreferences sharedPreferences;
    private String serverUrl;

    @Override
    public void onCreate() {
        super.onCreate();
        requestQueue = Volley.newRequestQueue(this);
        sharedPreferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        serverUrl = sharedPreferences.getString(KEY_SERVER_URL, DEFAULT_SERVER_URL);
        
        Log.d(TAG, "✅ Notification Listener Started");
        Log.d(TAG, "📍 Server URL: " + serverUrl);
        
        // টোস্ট মেসেজ (শুধু ডিবাগের জন্য)
        Toast.makeText(this, "Payment Verifier Started", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            Notification notification = sbn.getNotification();
            Bundle extras = notification.extras;
            
            String title = extras.getString(Notification.EXTRA_TITLE);
            String text = extras.getString(Notification.EXTRA_TEXT);
            String packageName = sbn.getPackageName();

            Log.d(TAG, "📱 Notification from: " + packageName);
            Log.d(TAG, "📱 Title: " + title);
            Log.d(TAG, "📱 Text: " + text);

            // ✅ bKash/Nagad/Rocket নোটিফিকেশন চিনুন
            if (title != null) {
                String lowerTitle = title.toLowerCase();
                if (lowerTitle.contains("bkash") || 
                    lowerTitle.contains("nagad") || 
                    lowerTitle.contains("rocket") ||
                    lowerTitle.contains("payment") ||
                    lowerTitle.contains("transaction")) {
                    parseAndSendTransaction(text, packageName);
                }
            }

        } catch (Exception e) {
            Log.e(TAG, "❌ Error processing notification", e);
        }
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        Log.d(TAG, "🔔 Notification removed: " + sbn.getPackageName());
    }

    private void parseAndSendTransaction(String text, String packageName) {
        try {
            Log.d(TAG, "🔍 Parsing notification text: " + text);
            
            // 🔍 TrxID খুঁজুন - bKash/Nagad/Rocket
            Pattern trxPattern = Pattern.compile(
                "(?:TRXID|TrxID|TXNID|Transaction ID|Txn ID)[:\\s]*([A-Za-z0-9]{8,20})", 
                Pattern.CASE_INSENSITIVE
            );
            Matcher trxMatcher = trxPattern.matcher(text);
            
            // 🔍 Amount খুঁজুন
            Pattern amountPattern = Pattern.compile(
                "(?:৳|BDT|Tk|Taka|Amount)[:\\s]*([0-9,]+(?:\\.[0-9]{2})?)", 
                Pattern.CASE_INSENSITIVE
            );
            Matcher amountMatcher = amountPattern.matcher(text);

            // 🔍 Sender Number খুঁজুন
            Pattern senderPattern = Pattern.compile(
                "(?:from|sender|sent by)[:\\s]*(\\+?[0-9]{11,14})", 
                Pattern.CASE_INSENSITIVE
            );
            Matcher senderMatcher = senderPattern.matcher(text);

            String trxId = null;
            String amount = null;
            String senderNumber = null;

            if (trxMatcher.find()) {
                trxId = trxMatcher.group(1).trim();
                Log.d(TAG, "✅ Found TrxID: " + trxId);
            }

            if (amountMatcher.find()) {
                amount = amountMatcher.group(1).replace(",", "").trim();
                Log.d(TAG, "✅ Found Amount: " + amount);
            }

            if (senderMatcher.find()) {
                senderNumber = senderMatcher.group(1).trim();
                Log.d(TAG, "✅ Found Sender: " + senderNumber);
            }

            // 📱 মোবাইল নাম্বার খোঁজা (যদি sender না পাওয়া যায়)
            if (senderNumber == null) {
                Pattern mobilePattern = Pattern.compile("\\+?[0-9]{11,14}");
                Matcher mobileMatcher = mobilePattern.matcher(text);
                if (mobileMatcher.find()) {
                    senderNumber = mobileMatcher.group();
                    Log.d(TAG, "✅ Found Mobile: " + senderNumber);
                }
            }

            // Method নির্ধারণ
            String method = "bKash";
            if (packageName != null) {
                if (packageName.contains("nagad")) method = "Nagad";
                else if (packageName.contains("rocket")) method = "Rocket";
                else if (packageName.contains("bkash")) method = "bKash";
            }

            if (trxId != null && amount != null) {
                sendToServer(trxId, amount, senderNumber, method);
            } else {
                Log.w(TAG, "⚠️ Could not parse TrxID or Amount from notification");
                Log.w(TAG, "📝 TrxID: " + trxId + ", Amount: " + amount);
            }

        } catch (Exception e) {
            Log.e(TAG, "❌ Error parsing notification", e);
        }
    }

    private void sendToServer(String trxId, String amount, String senderNumber, String method) {
        try {
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("trxId", trxId);
            jsonBody.put("amount", amount);
            jsonBody.put("senderNumber", senderNumber != null ? senderNumber : "Unknown");
            jsonBody.put("method", method);
            jsonBody.put("timestamp", System.currentTimeMillis());
            jsonBody.put("source", "android_notification");

            Log.d(TAG, "📤 Sending to server:");
            Log.d(TAG, "   TrxID: " + trxId);
            Log.d(TAG, "   Amount: " + amount);
            Log.d(TAG, "   Sender: " + senderNumber);
            Log.d(TAG, "   Method: " + method);

            JsonObjectRequest request = new JsonObjectRequest(
                Request.Method.POST,
                serverUrl,
                jsonBody,
                response -> {
                    Log.d(TAG, "✅ Server response: " + response.toString());
                    
                    // সফল হলে টোস্ট দেখান
                    try {
                        boolean success = response.getBoolean("success");
                        if (success) {
                            Toast.makeText(this, "✅ Payment Verified: " + amount + " BDT", Toast.LENGTH_SHORT).show();
                        } else {
                            String message = response.optString("message", "Verification failed");
                            Toast.makeText(this, "⚠️ " + message, Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        Toast.makeText(this, "✅ Payment sent for verification", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    Log.e(TAG, "❌ Server error: " + error.getMessage());
                    if (error.networkResponse != null) {
                        Log.e(TAG, "   Status Code: " + error.networkResponse.statusCode);
                    }
                    Toast.makeText(this, "❌ Server error. Check connection.", Toast.LENGTH_SHORT).show();
                }
            );

            // রিট্রাই লজিক
            request.setRetryPolicy(new com.android.volley.DefaultRetryPolicy(
                10000, // timeout (10 seconds)
                2,     // max retries
                1.0f   // backoff multiplier
            ));

            requestQueue.add(request);

        } catch (Exception e) {
            Log.e(TAG, "❌ Error sending to server", e);
        }
    }

    // Server URL আপডেট করার মেথড
    public void updateServerUrl(String newUrl) {
        if (newUrl != null && !newUrl.isEmpty()) {
            serverUrl = newUrl;
            sharedPreferences.edit().putString(KEY_SERVER_URL, newUrl).apply();
            Log.d(TAG, "✅ Server URL updated to: " + serverUrl);
        }
    }
}