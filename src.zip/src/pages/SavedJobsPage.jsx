// src/pages/SavedJobsPage.jsx
import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { db, auth } from '../firebase';
import { 
  doc, 
  getDoc,
  collection, 
  query, 
  where, 
  getDocs, 
  updateDoc,
  arrayRemove,
  onSnapshot
} from 'firebase/firestore';
import JobCard from './JobCard';
import './SavedJobsPage.css';

function SavedJobsPage({ onBidAndChatClick }) {
  const navigate = useNavigate();
  const [savedIds, setSavedIds] = useState([]);
  const [savedPosts, setSavedPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [debug, setDebug] = useState('');
  const [error, setError] = useState('');

  // ============================================================
  // ✅ রিয়েল-টাইম savedIds লোড করা
  // ============================================================
  useEffect(() => {
    if (!auth.currentUser) {
      navigate('/login');
      return;
    }

    const userRef = doc(db, 'users', auth.currentUser.uid);
    
    // 🔥 রিয়েল-টাইম লিসেনার
    const unsubscribe = onSnapshot(userRef, (docSnapshot) => {
      if (docSnapshot.exists()) {
        const ids = docSnapshot.data().savedPosts || [];
        console.log("📌 Real-time saved IDs updated:", ids);
        setSavedIds(ids);
        setError('');
      } else {
        setSavedIds([]);
        setError('User data not found');
      }
    }, (error) => {
      console.error("Error listening to user data:", error);
      setError('Failed to load user data');
    });

    return () => unsubscribe();
  }, [navigate]);

  // ============================================================
  // ✅ savedIds পরিবর্তিত হলে পোস্ট ফেচ করুন
  // ============================================================
  useEffect(() => {
    const fetchSavedPosts = async () => {
      if (!savedIds || savedIds.length === 0) {
        console.log("🟡 No saved IDs, setting empty posts");
        setSavedPosts([]);
        setLoading(false);
        setDebug('No saved posts');
        return;
      }

      console.log("🔵 Fetching posts for IDs:", savedIds);
      setLoading(true);
      setDebug(`Fetching ${savedIds.length} posts...`);
      
      try {
        const postsRef = collection(db, 'posts');
        const batchSize = 30;
        let allPosts = [];
        
        // 🔥 ব্যাচে ভাগ করে ফেচ করুন
        for (let i = 0; i < savedIds.length; i += batchSize) {
          const batch = savedIds.slice(i, i + batchSize);
          console.log(`🔵 Fetching batch ${Math.floor(i/batchSize) + 1}:`, batch);
          
          const q = query(postsRef, where("__name__", "in", batch));
          const querySnapshot = await getDocs(q);
          
          const posts = querySnapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
          }));
          
          console.log(`✅ Batch returned ${posts.length} posts`);
          allPosts = [...allPosts, ...posts];
        }
        
        console.log("✅ Total posts fetched:", allPosts.length);
        setSavedPosts(allPosts);
        setDebug(`Loaded ${allPosts.length} posts`);
        setError('');
        
      } catch (error) {
        console.error("🔴 Error fetching posts:", error);
        setDebug('Error: ' + error.message);
        setError('Failed to load saved posts');
        setSavedPosts([]);
      } finally {
        setLoading(false);
      }
    };

    fetchSavedPosts();
  }, [savedIds]);

  // ============================================================
  // ✅ রিফ্রেশ ফাংশন
  // ============================================================
  const handleRefresh = useCallback(async () => {
    console.log("🔄 Manual refresh triggered...");
    setLoading(true);
    setError('');
    
    try {
      const userRef = doc(db, 'users', auth.currentUser.uid);
      const userSnap = await getDoc(userRef);
      
      if (userSnap.exists()) {
        const ids = userSnap.data().savedPosts || [];
        console.log("📌 Reloaded saved IDs:", ids);
        setSavedIds(ids);
        setDebug('Refreshed');
      } else {
        setSavedIds([]);
        setError('User data not found');
      }
    } catch (error) {
      console.error("Error refreshing:", error);
      setError('Failed to refresh');
    } finally {
      setLoading(false);
    }
  }, []);

  // ============================================================
  // ✅ পেজ ফোকাস করলে রিফ্রেশ
  // ============================================================
  useEffect(() => {
    const handleFocus = () => {
      console.log("🔄 Page focused - refreshing...");
      handleRefresh();
    };

    window.addEventListener('focus', handleFocus);
    return () => window.removeEventListener('focus', handleFocus);
  }, [handleRefresh]);

  // ============================================================
  // ✅ আনসেভ ফাংশন
  // ============================================================
  const handleUnsavePost = useCallback(async (postId) => {
    if (!auth.currentUser) {
      alert('Please login first!');
      return;
    }
    
    if (!window.confirm('Remove this post from saved list?')) {
      return;
    }
    
    const userRef = doc(db, 'users', auth.currentUser.uid);
    
    try {
      await updateDoc(userRef, {
        savedPosts: arrayRemove(postId)
      });
      
      // লোকাল স্টেট আপডেট
      setSavedPosts(prev => prev.filter(post => post.id !== postId));
      setSavedIds(prev => prev.filter(id => id !== postId));
      
      console.log("✅ Post unsaved successfully!");
      
    } catch (error) {
      console.error("❌ Error unsaving post:", error);
      alert('Failed to unsave post. Please try again.');
    }
  }, []);

  // ============================================================
  // ✅ বিড হ্যান্ডলার
  // ============================================================
  const handleBidAndChat = useCallback((job) => {
    if (onBidAndChatClick) {
      onBidAndChatClick(job);
    } else {
      navigate('/inbox', { state: { job } });
    }
  }, [onBidAndChatClick, navigate]);

  // ============================================================
  // ✅ খালি স্টেট UI
  // ============================================================
  const renderEmptyState = () => (
    <div className="empty-saved-container">
      <div className="empty-saved-icon">
        <i className="fa-regular fa-bookmark"></i>
      </div>
      <h3>No Saved Jobs Yet</h3>
      <p>Start saving jobs you're interested in! Click the bookmark icon on any job card to save it.</p>
      <button className="browse-jobs-btn" onClick={() => navigate('/')}>
        <i className="fa-solid fa-search"></i> Browse Jobs
      </button>
    </div>
  );

  // ============================================================
  // ✅ লোডিং UI
  // ============================================================
  const renderLoading = () => (
    <div className="saved-loading-container">
      <div className="saved-loading-spinner"></div>
      <p>Loading your saved jobs...</p>
      {debug && <p className="debug-text">{debug}</p>}
    </div>
  );

  // ============================================================
  // ✅ Error UI
  // ============================================================
  if (error) {
    return (
      <div className="saved-error-container">
        <i className="fa-solid fa-triangle-exclamation"></i>
        <h3>Something went wrong</h3>
        <p>{error}</p>
        <button className="retry-btn" onClick={handleRefresh}>
          <i className="fa-solid fa-rotate-right"></i> Retry
        </button>
      </div>
    );
  }

  // ============================================================
  // ✅ রেন্ডার
  // ============================================================
  return (
    <div className="saved-jobs-page">
      
      {/* ডিবাগ বার (শুধু ডেভেলপমেন্টে) */}
      {process.env.NODE_ENV === 'development' && (
        <div className="debug-bar">
          <span>
            <strong>📊 Debug:</strong> {savedPosts.length} posts | {debug} | IDs: {savedIds.length}
          </span>
          <button className="refresh-btn-small" onClick={handleRefresh}>
            <i className="fa-solid fa-rotate-right"></i> Refresh
          </button>
        </div>
      )}

      {/* হেডার */}
      <div className="saved-jobs-header">
        <div className="header-left">
          <h1>
            <i className="fa-solid fa-bookmark" style={{ color: '#fbbf24' }}></i>
            Saved Jobs
          </h1>
          <span className="saved-count">
            {savedPosts.length} {savedPosts.length === 1 ? 'Job' : 'Jobs'}
          </span>
        </div>
        <button className="back-to-home-btn" onClick={() => navigate('/')}>
          <i className="fa-solid fa-arrow-left"></i> Back to Home
        </button>
      </div>

      {/* কন্টেন্ট */}
      <div className="saved-jobs-grid">
        {loading ? (
          renderLoading()
        ) : savedPosts.length > 0 ? (
          savedPosts.map((post) => (
            <JobCard
              key={post.id}
              id={post.id}
              job={post}
              isSavedExternally={true}
              onUnsave={() => handleUnsavePost(post.id)}
              onBidAndChatClick={handleBidAndChat}
              searchTerm=""
              highlightText={(text) => text}
            />
          ))
        ) : (
          renderEmptyState()
        )}
      </div>
    </div>
  );
}

export default SavedJobsPage;