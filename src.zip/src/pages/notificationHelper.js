import { db } from '../firebase';
import { collection, addDoc, serverTimestamp, doc, getDoc } from 'firebase/firestore';

// 🎯 নোটিফিকেশন টাইপ কনস্ট্যান্ট
export const NOTIFICATION_TYPES = {
  BID_RECEIVED: 'bid_received',
  BID_ACCEPTED: 'bid_accepted',
  PAYMENT_RECEIVED: 'payment_received',
  PAYMENT_RELEASED: 'payment_released',
  MILESTONE_COMPLETED: 'milestone_completed',
  DEAL_CONFIRMED: 'deal_confirmed',
  MESSAGE_RECEIVED: 'message_received',
  DEAL_COMPLETED: 'deal_completed',
  DEAL_CANCELLED: 'deal_cancelled',          // 🆕
  DEADLINE_PASSED: 'deadline_passed',        // 🆕
  CANCELLATION_REQUEST: 'cancellation_request', // 🆕
  CANCELLATION_APPROVED: 'cancellation_approved', // 🆕
  CANCELLATION_REJECTED: 'cancellation_rejected'  // 🆕
};

// 🎯 ইউজারের নাম বের করার ফাংশন
const getUserName = async (userId) => {
  if (!userId) return 'Someone';
  try {
    const userRef = doc(db, 'users', userId);
    const userSnap = await getDoc(userRef);
    if (userSnap.exists()) {
      const data = userSnap.data();
      return data.displayName || data.name || userId.slice(0, 8);
    }
    return userId.slice(0, 8);
  } catch (error) {
    console.error("Error getting user name:", error);
    return userId.slice(0, 8);
  }
};

// 🎯 মূল নোটিফিকেশন পাঠানোর ফাংশন
export const sendNotification = async (userId, title, message, mode, options = {}) => {
  if (!userId) {
    console.error("❌ No userId provided for notification");
    return null;
  }

  try {
    const notificationData = {
      userId: userId,
      title: title,
      message: message,
      mode: mode, // 'buyer' বা 'seller'
      isUnread: true,
      icon: options.icon || 'fa-solid fa-bell',
      colorClass: options.colorClass || 'noti-system',
      type: options.type || 'system',
      createdAt: serverTimestamp(),
      readAt: null
    };
    
    if (options.relatedId) {
      notificationData.relatedId = options.relatedId;
    }
    
    // 🔥 ডিল আইডি থাকলে যোগ করুন
    if (options.dealId) {
      notificationData.dealId = options.dealId;
    }
    
    // 🔥 পোস্ট টাইটেল থাকলে যোগ করুন
    if (options.postTitle) {
      notificationData.postTitle = options.postTitle;
    }
    
    // 🔥 অ্যাকশন রিকোয়ার্ড থাকলে যোগ করুন
    if (options.actionRequired) {
      notificationData.actionRequired = options.actionRequired;
      notificationData.actionType = options.actionType || 'respond';
    }
    
    const docRef = await addDoc(collection(db, 'notifications'), notificationData);
    console.log("✅ Notification sent to:", userId, "Doc ID:", docRef.id);
    return docRef.id;
  } catch (error) {
    console.error("❌ Error sending notification:", error);
    return null;
  }
};

// 🎯 ১. বিড সংক্রান্ত নোটিফিকেশন
export const sendBidNotification = async (sellerId, buyerId, projectTitle, projectId, sellerName, bidAmount) => {
  const displayName = sellerName || await getUserName(sellerId);
  
  // বায়ারের জন্য নোটিফিকেশন
  await sendNotification(
    buyerId,
    '📋 নতুন বিড এসেছে',
    `${displayName} আপনার "${projectTitle}" প্রজেক্টে ${bidAmount} BDT তে বিড করেছেন`,
    'buyer',
    { 
      icon: 'fa-solid fa-gavel', 
      colorClass: 'noti-project', 
      type: NOTIFICATION_TYPES.BID_RECEIVED,
      relatedId: projectId,
      dealId: projectId,
      postTitle: projectTitle
    }
  );
  
  // সেলারের জন্য নোটিফিকেশন
  await sendNotification(
    sellerId,
    '✅ বিড সফল হয়েছে',
    `আপনার বিড "${projectTitle}" প্রজেক্টে সফলভাবে জমা হয়েছে`,
    'seller',
    { 
      icon: 'fa-solid fa-paper-plane', 
      colorClass: 'noti-project', 
      type: NOTIFICATION_TYPES.BID_RECEIVED,
      relatedId: projectId,
      dealId: projectId,
      postTitle: projectTitle
    }
  );
};

// 🎯 ২. ডিল সংক্রান্ত নোটিফিকেশন
export const sendDealNotification = async (buyerId, sellerId, dealTitle, dealId) => {
  // বায়ারের জন্য
  await sendNotification(
    buyerId,
    '🎉 ডিল কনফার্ম হয়েছে',
    `আপনার "${dealTitle}" ডিলটি কনফার্ম হয়েছে। এখন কাজ শুরু করতে পারেন।`,
    'buyer',
    { 
      icon: 'fa-solid fa-handshake', 
      colorClass: 'noti-project', 
      type: NOTIFICATION_TYPES.DEAL_CONFIRMED,
      relatedId: dealId,
      dealId: dealId,
      postTitle: dealTitle
    }
  );
  
  // সেলারের জন্য
  await sendNotification(
    sellerId,
    '🚀 ডিল স্টার্ট হয়েছে',
    `ক্লায়েন্ট "${dealTitle}" ডিলটি কনফার্ম করেছেন। আপনি কাজ শুরু করতে পারেন!`,
    'seller',
    { 
      icon: 'fa-solid fa-rocket', 
      colorClass: 'noti-project', 
      type: NOTIFICATION_TYPES.DEAL_CONFIRMED,
      relatedId: dealId,
      dealId: dealId,
      postTitle: dealTitle
    }
  );
};

// 🎯 ৩. পেমেন্ট সংক্রান্ত নোটিফিকেশন
export const sendPaymentNotification = async (userId, amount, mode, dealTitle, dealId) => {
  await sendNotification(
    userId,
    '💰 পেমেন্ট সফল হয়েছে',
    `আপনার ওয়ালেটে ${amount} BDT জমা হয়েছে "${dealTitle}" এর জন্য`,
    mode,
    { 
      icon: 'fa-solid fa-wallet', 
      colorClass: 'noti-payment', 
      type: NOTIFICATION_TYPES.PAYMENT_RECEIVED,
      relatedId: dealId,
      dealId: dealId,
      postTitle: dealTitle
    }
  );
};

// 🎯 ৪. মাইলস্টোন সংক্রান্ত নোটিফিকেশন
export const sendMilestoneNotification = async (buyerId, sellerId, milestoneTitle, dealTitle, dealId, sellerName) => {
  const displayName = sellerName || await getUserName(sellerId);
  
  // বায়ারের জন্য
  await sendNotification(
    buyerId,
    '📝 মাইলস্টোন রিভিউ রিকোয়েস্ট',
    `${displayName} "${milestoneTitle}" মাইলস্টোনটি সম্পন্ন করেছেন। রিভিউ করে পেমেন্ট রিলিজ করুন।`,
    'buyer',
    { 
      icon: 'fa-solid fa-check-circle', 
      colorClass: 'noti-project', 
      type: NOTIFICATION_TYPES.MILESTONE_COMPLETED,
      relatedId: dealId,
      dealId: dealId,
      postTitle: dealTitle,
      actionRequired: true,
      actionType: 'review_milestone'
    }
  );
  
  // সেলারের জন্য
  await sendNotification(
    sellerId,
    '✅ মাইলস্টোন জমা হয়েছে',
    `আপনার "${milestoneTitle}" মাইলস্টোনটি রিভিউয়ের জন্য জমা হয়েছে।`,
    'seller',
    { 
      icon: 'fa-solid fa-clock', 
      colorClass: 'noti-project', 
      type: NOTIFICATION_TYPES.MILESTONE_COMPLETED,
      relatedId: dealId,
      dealId: dealId,
      postTitle: dealTitle
    }
  );
};

// 🎯 ৫. মেসেজ সংক্রান্ত নোটিফিকেশন
export const sendMessageNotification = async (receiverId, receiverMode, senderName, chatId) => {
  await sendNotification(
    receiverId,
    '💬 নতুন মেসেজ',
    `${senderName} আপনাকে একটি নতুন মেসেজ পাঠিয়েছেন`,
    receiverMode,
    { 
      icon: 'fa-solid fa-comment-dots', 
      colorClass: 'noti-system', 
      type: NOTIFICATION_TYPES.MESSAGE_RECEIVED,
      relatedId: chatId
    }
  );
};

// 🎯 ৬. ডিল কমপ্লিট নোটিফিকেশন
export const sendDealCompleteNotification = async (buyerId, sellerId, dealTitle, dealId) => {
  await sendNotification(
    buyerId,
    '🏆 ডিল সম্পূর্ণ হয়েছে',
    `"${dealTitle}" ডিলটি সফলভাবে সম্পূর্ণ হয়েছে। সেলারকে রেটিং দিন।`,
    'buyer',
    { 
      icon: 'fa-solid fa-trophy', 
      colorClass: 'noti-project', 
      type: NOTIFICATION_TYPES.DEAL_COMPLETED,
      relatedId: dealId,
      dealId: dealId,
      postTitle: dealTitle
    }
  );
  
  await sendNotification(
    sellerId,
    '🏆 ডিল সম্পূর্ণ হয়েছে',
    `"${dealTitle}" ডিলটি সফলভাবে সম্পূর্ণ হয়েছে। ক্লায়েন্টকে রেটিং দিন।`,
    'seller',
    { 
      icon: 'fa-solid fa-trophy', 
      colorClass: 'noti-project', 
      type: NOTIFICATION_TYPES.DEAL_COMPLETED,
      relatedId: dealId,
      dealId: dealId,
      postTitle: dealTitle
    }
  );
};

// 🆕 ৭. ডিল ক্যানসেল রিকোয়েস্ট নোটিফিকেশন
export const sendCancellationRequestNotification = async (userId, postTitle, dealId, requesterName, reason, budget) => {
  const safePostTitle = postTitle || 'Untitled Deal';
  const safeRequesterName = requesterName || 'Someone';
  const safeReason = reason || 'No reason provided';
  const safeBudget = budget || 0;
  
  await sendNotification(
    userId,
    '⚠️ ডিল ক্যানসেল রিকোয়েস্ট',
    `${safeRequesterName} "${safePostTitle}" (Budget: ${safeBudget} BDT) ডিলটি ক্যানসেল করতে চান। কারণ: ${safeReason}`,
    userId.includes('buyer') ? 'buyer' : 'seller',
    {
      icon: 'fa-solid fa-clock',
      colorClass: 'noti-warning',
      type: NOTIFICATION_TYPES.CANCELLATION_REQUEST,
      dealId: dealId,
      postTitle: safePostTitle,
      actionRequired: true,
      actionType: 'cancel_respond'
    }
  );
};

// 🆕 ৮. ডিল ক্যানসেল অ্যাপ্রুভ নোটিফিকেশন
export const sendCancellationApprovedNotification = async (buyerId, sellerId, postTitle, dealId) => {
  const safePostTitle = postTitle || 'Untitled Deal';
  
  // Buyer কে নোটিফিকেশন
  await sendNotification(
    buyerId,
    '❌ ডিল ক্যানসেল হয়েছে',
    `"${safePostTitle}" ডিলটি উভয় পক্ষের সম্মতিতে ক্যানসেল করা হয়েছে।`,
    'buyer',
    {
      icon: 'fa-solid fa-ban',
      colorClass: 'noti-danger',
      type: NOTIFICATION_TYPES.CANCELLATION_APPROVED,
      dealId: dealId,
      postTitle: safePostTitle
    }
  );
  
  // Seller কে নোটিফিকেশন
  await sendNotification(
    sellerId,
    '❌ ডিল ক্যানসেল হয়েছে',
    `"${safePostTitle}" ডিলটি উভয় পক্ষের সম্মতিতে ক্যানসেল করা হয়েছে।`,
    'seller',
    {
      icon: 'fa-solid fa-ban',
      colorClass: 'noti-danger',
      type: NOTIFICATION_TYPES.CANCELLATION_APPROVED,
      dealId: dealId,
      postTitle: safePostTitle
    }
  );
};

// 🆕 ৯. ডিল ক্যানসেল রিজেক্ট নোটিফিকেশন
export const sendCancellationRejectedNotification = async (userId, postTitle, dealId) => {
  const safePostTitle = postTitle || 'Untitled Deal';
  
  await sendNotification(
    userId,
    '✅ ক্যানসেল রিকোয়েস্ট রিজেক্ট',
    `"${safePostTitle}" ডিলের ক্যানসেল রিকোয়েস্টটি রিজেক্ট করা হয়েছে। ডিল অ্যাক্টিভ আছে।`,
    userId.includes('buyer') ? 'buyer' : 'seller',
    {
      icon: 'fa-solid fa-check-circle',
      colorClass: 'noti-system',
      type: NOTIFICATION_TYPES.CANCELLATION_REJECTED,
      dealId: dealId,
      postTitle: safePostTitle
    }
  );
};

// 🆕 ১০. ডেডলাইন শেষ হওয়ার নোটিফিকেশন
export const sendDeadlinePassedNotification = async (sellerId, buyerId, postTitle, dealId) => {
  const safePostTitle = postTitle || 'Untitled Deal';
  
  // Seller কে নোটিফিকেশন
  await sendNotification(
    sellerId,
    '⏰ ডেডলাইন শেষ হয়েছে',
    `"${safePostTitle}" ডিলের ডেডলাইন শেষ হয়েছে। অনুগ্রহ করে ক্লায়েন্টকে আপডেট দিন।`,
    'seller',
    {
      icon: 'fa-solid fa-clock',
      colorClass: 'noti-warning',
      type: NOTIFICATION_TYPES.DEADLINE_PASSED,
      dealId: dealId,
      postTitle: safePostTitle,
      actionRequired: true,
      actionType: 'update_progress'
    }
  );
  
  // Buyer কে নোটি�ফিকেশন
  await sendNotification(
    buyerId,
    '⏰ ডেডলাইন শেষ হয়েছে',
    `"${safePostTitle}" ডিলের ডেডলাইন শেষ হয়েছে। সেলারের সাথে যোগাযোগ করতে পারেন।`,
    'buyer',
    {
      icon: 'fa-solid fa-clock',
      colorClass: 'noti-warning',
      type: NOTIFICATION_TYPES.DEADLINE_PASSED,
      dealId: dealId,
      postTitle: safePostTitle
    }
  );
};

// 🆕 ১১. ডিল ক্যানসেল ডাইরেক্ট নোটিফিকেশন (সিঙ্গেল-স্টেপ)
export const sendDealCancelledNotification = async (userId, postTitle, dealId, cancelledBy, reason) => {
  const safePostTitle = postTitle || 'Untitled Deal';
  const safeCancelledBy = cancelledBy || 'Someone';
  const safeReason = reason || 'No reason provided';
  
  await sendNotification(
    userId,
    '❌ ডিল ক্যানসেল হয়েছে',
    `${safeCancelledBy} "${safePostTitle}" ডিলটি ক্যানসেল করেছেন। কারণ: ${safeReason}`,
    userId.includes('buyer') ? 'buyer' : 'seller',
    {
      icon: 'fa-solid fa-ban',
      colorClass: 'noti-danger',
      type: NOTIFICATION_TYPES.DEAL_CANCELLED,
      dealId: dealId,
      postTitle: safePostTitle
    }
  );
};