import React from 'react';

export const ProposalModal = ({ show, onClose, proposalData, setProposalData, onSend }) => {
  if (!show) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="proposal-modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h3><i className="fa-solid fa-file-signature"></i> Send Proposal</h3>
          <button className="modal-close" onClick={onClose}>✕</button>
        </div>
        <div className="modal-body">
          <div className="form-group">
            <label><i className="fa-solid fa-wallet"></i> Budget (BDT)</label>
            <input 
              type="number" 
              value={proposalData.budget} 
              onChange={(e) => setProposalData({...proposalData, budget: e.target.value})} 
              placeholder="Enter budget" 
            />
          </div>
          <div className="form-group">
            <label><i className="fa-regular fa-calendar"></i> Deadline (Days)</label>
            <input 
              type="number" 
              value={proposalData.deadline} 
              onChange={(e) => setProposalData({...proposalData, deadline: e.target.value})} 
              placeholder="Enter deadline" 
            />
          </div>
          <div className="form-group">
            <label><i className="fa-solid fa-file-lines"></i> Work Details</label>
            <textarea 
              rows="4" 
              value={proposalData.details} 
              onChange={(e) => setProposalData({...proposalData, details: e.target.value})} 
              placeholder="Describe your work..." 
            />
          </div>
        </div>
        <div className="modal-footer">
          <button className="btn-cancel-modal" onClick={onClose}>Cancel</button>
          <button className="btn-send-proposal" onClick={onSend}>Send Proposal</button>
        </div>
      </div>
    </div>
  );
};

export default ProposalModal;  // ✅ default export
