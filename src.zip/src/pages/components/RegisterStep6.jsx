// import React from 'react';
// import { VerificationStatusBadge } from './VerificationStatusBadge';
// import { VerificationProgress } from './VerificationProgress';
// import { VerificationWaitingScreen } from './VerificationWaitingScreen';

// export const RegisterStep6 = ({ 
//   anyVerify, docUploaded, faceVerified, loading, uploadingDocs,
//   onComplete, userData, verificationStatus, progress, timeRemaining,
//   onBrowse
// }) => {
//   const isVerified = verificationStatus?.id === 'verified';
//   const isPending = verificationStatus?.id === 'pending';
//   const needsMoreInfo = verificationStatus?.id === 'need_more_info';
//   const isRejected = verificationStatus?.id === 'rejected';

//   // পেন্ডিং ভেরিফিকেশন
//   if (isPending) {
//     return (
//       <div className="step-panel active" id="step6">
//         <VerificationWaitingScreen 
//           timeRemaining={timeRemaining}
//           onBrowse={onBrowse}
//         />
//       </div>
//     );
//   }

//   // ভেরিফাইড
//   if (isVerified) {
//     return (
//       <div className="step-panel active" id="step6">
//         <div className="result-screen verified">
//           <div className="result-icon success-icon">🎉</div>
//           <div className="result-title">অভিনন্দন!</div>
//           <div className="result-sub">আপনার অ্যাকাউন্ট সম্পূর্ণ যাচাইকৃত।</div>
          
//           <VerificationStatusBadge status="verified" />
          
//           <div className="verified-features">
//             <h4>✅ এখন আপনি করতে পারবেন:</h4>
//             <ul>
//               <li>📝 কাজ পোস্ট করতে</li>
//               <li>💼 কাজ গ্রহণ করতে</li>
//               <li>💳 লেনদেন করতে</li>
//               <li>💬 সম্পূর্ণ চ্যাট করতে</li>
//               <li>⭐ রেটিং দিতে</li>
//             </ul>
//           </div>

//           <button className="btn btn-success" onClick={onBrowse}>
//             🚀 ড্যাশবোর্ডে যান
//           </button>
//         </div>
//       </div>
//     );
//   }

//   // নিড মোর ইনফো / রিজেক্টেড
//   if (needsMoreInfo || isRejected) {
//     return (
//       <div className="step-panel active" id="step6">
//         <div className="result-screen rejected">
//           <div className="result-icon error-icon">⚠️</div>
//           <div className="result-title">
//             {isRejected ? 'ডকুমেন্ট প্রত্যাখ্যাত' : 'অতিরিক্ত তথ্য প্রয়োজন'}
//           </div>
//           <div className="result-sub">
//             {isRejected 
//               ? 'আপনার ডকুমেন্ট গ্রহণযোগ্য নয়। বিস্তারিত জানতে ইমেইল চেক করুন।'
//               : 'আপনার ডকুমেন্টে কিছু সমস্যা হয়েছে। পুনরায় আপলোড করুন।'
//             }
//           </div>

//           <VerificationStatusBadge status={isRejected ? 'rejected' : 'need_more_info'} />

//           <div className="resubmit-section">
//             <h4>📤 পুনরায় ডকুমেন্ট আপলোড করুন</h4>
//             <p>নিচের নির্দেশনা অনুসরণ করুন:</p>
//             <ul>
//               <li>পরিষ্কার ছবি আপলোড করুন</li>
//               <li>সকল তথ্য সঠিকভাবে পূরণ করুন</li>
//               <li>মেয়াদ উত্তীর্ণ ডকুমেন্ট ব্যবহার করবেন না</li>
//             </ul>
//             <button className="btn btn-warning" onClick={onComplete}>
//               📤 পুনরায় সাবমিট করুন
//             </button>
//           </div>
//         </div>
//       </div>
//     );
//   }

//   // ডিফল্ট - যাচাই শুরু হয়নি
//   return (
//     <div className="step-panel active" id="step6">
//       <div className="result-screen">
//         {anyVerify ? (
//           <>
//             <div className="result-icon pending">⏳</div>
//             <div className="result-title">যাচাই প্রক্রিয়াধীন</div>
//             <div className="result-sub">অ্যাডমিন যাচাই করার পর অ্যাকাউন্ট সম্পূর্ণ সক্রিয় হবে।</div>
            
//             <VerificationProgress progress={progress} status={verificationStatus} />
            
//             <div className="timer-badge">⏱ সাধারণত ২৪–৪৮ ঘণ্টা লাগে</div>
//           </>
//         ) : (
//           <>
//             <div className="result-icon success-icon">🎉</div>
//             <div className="result-title">নিবন্ধন সম্পন্ন!</div>
//             <div className="result-sub">আপনার অ্যাকাউন্ট তৈরি হয়েছে।</div>
            
//             <VerificationStatusBadge status="incomplete" />
            
//             <div className="info-box warn">
//               <span className="info-icon">⚠️</span>
//               <div>লেনদেন করতে পরিচয় যাচাই করতে হবে।</div>
//             </div>
//           </>
//         )}

//         <div className="result-steps">
//           <div className="result-step"><div className="result-step-dot done" /> ✅ নিবন্ধন সম্পন্ন</div>
//           <div className="result-step"><div className="result-step-dot done" /> ✅ ফোন নম্বর যাচাই</div>
//           <div className="result-step">
//             <div className="result-step-dot" style={{ background: docUploaded ? '#f59e0b' : '#94a3b8' }} />
//             {docUploaded ? '📄 ডকুমেন্ট পর্যালোচনাধীন' : '⏭ ডকুমেন্ট এড়ানো হয়েছে'}
//           </div>
//           <div className="result-step">
//             <div className="result-step-dot" style={{ background: faceVerified ? '#f59e0b' : '#94a3b8' }} />
//             {faceVerified ? '📸 ফেস যাচাই সম্পন্ন ✅' : '⏭ ফেস যাচাই এড়ানো হয়েছে'}
//           </div>
//         </div>

//         <div className="btn-row">
//           <button 
//             className="btn btn-success" 
//             onClick={onComplete} 
//             disabled={loading || uploadingDocs}
//           >
//             {loading || uploadingDocs ? '⏳ প্রক্রিয়াধীন...' : '🚀 নিবন্ধন সম্পূর্ণ করুন'}
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// };