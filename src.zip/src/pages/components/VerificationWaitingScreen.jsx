// import React from 'react';

// export const VerificationWaitingScreen = ({ timeRemaining, onBrowse }) => {
//   return (
//     <div className="verification-waiting">
//       <div className="waiting-icon">⏳</div>
//       <h2>আপনার তথ্য যাচাই করা হচ্ছে</h2>
      
//       <div className="countdown-timer">
//         <span className="time-display">{timeRemaining || '২৩:৫৯:৫৯'}</span>
//         <span className="time-label">বাকি সময়</span>
//       </div>

//       <p className="waiting-message">
//         সর্বোচ্চ ২৪ ঘন্টার মধ্যে আপনার অ্যাকাউন্ট সক্রিয় করা হবে।
//       </p>

//       <div className="feature-status">
//         <div className="feature-item allowed">
//           <span>✅</span> পোস্ট দেখতে পারবেন
//         </div>
//         <div className="feature-item allowed">
//           <span>✅</span> প্রোফাইল এডিট করতে পারবেন
//         </div>
//         <div className="feature-item restricted">
//           <span>❌</span> লেনদেন করতে পারবেন না
//         </div>
//         <div className="feature-item restricted">
//           <span>❌</span> কাজ পোস্ট/গ্রহণ করতে পারবেন না
//         </div>
//       </div>

//       <button className="browse-btn" onClick={onBrowse}>
//         🔍 পোস্ট ব্রাউজ করুন
//       </button>
//     </div>
//   );
// };