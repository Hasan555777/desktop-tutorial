import React from 'react';

export const InboxModeSwitcher = ({ currentMode, handleModeChange, getUnreadCount, filteredChats }) => {
  const getModeCount = (mode) => {
    if (mode === 'all') return getUnreadCount();
    return filteredChats.filter(c => c.isUnread).length;
  };

  return (
    <div className="inbox-mode-switcher">
      <button 
        className={`mode-switch-btn ${currentMode === 'all' ? 'active' : ''}`}
        onClick={() => handleModeChange('all')}
      >
        <i className="fa-solid fa-list"></i> All
        {currentMode === 'all' && getModeCount('all') > 0 && (
          <span className="mode-badge-count">{getModeCount('all')}</span>
        )}
      </button>
      
      <button 
        className={`mode-switch-btn ${currentMode === 'buyer' ? 'active' : ''}`}
        onClick={() => handleModeChange('buyer')}
      >
        <i className="fa-solid fa-briefcase"></i> Buyer
        {currentMode === 'buyer' && getModeCount('buyer') > 0 && (
          <span className="mode-badge-count">{getModeCount('buyer')}</span>
        )}
      </button>
      
      <button 
        className={`mode-switch-btn ${currentMode === 'seller' ? 'active' : ''}`}
        onClick={() => handleModeChange('seller')}
      >
        <i className="fa-solid fa-laptop-code"></i> Seller
        {currentMode === 'seller' && getModeCount('seller') > 0 && (
          <span className="mode-badge-count">{getModeCount('seller')}</span>
        )}
      </button>
    </div>
  );
};