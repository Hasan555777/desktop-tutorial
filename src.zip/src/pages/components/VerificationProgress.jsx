// import React from 'react';
// import { VERIFICATION_STEPS } from '../registerHelpers';

// export const VerificationProgress = ({ progress, status }) => {
//   const { completed, total, percentage, steps } = progress;

//   return (
//     <div className="verification-progress">
//       <div className="progress-header">
//         <h4>🔐 যাচাই প্রক্রিয়া</h4>
//         <span className="progress-percentage">{percentage}%</span>
//       </div>
      
//       <div className="progress-bar-container">
//         <div className="progress-bar">
//           <div 
//             className="progress-fill" 
//             style={{ 
//               width: `${percentage}%`,
//               background: percentage === 100 ? '#2ecc71' : '#f39c12'
//             }} 
//           />
//         </div>
//       </div>

//       <div className="steps-list">
//         {VERIFICATION_STEPS.map((step, index) => {
//           const isDone = steps[index]?.value || false;
//           const isCurrent = !isDone && (index === 0 || steps[index - 1]?.value);
          
//           return (
//             <div key={step.id} className={`step-item ${isDone ? 'done' : isCurrent ? 'current' : ''}`}>
//               <div className="step-icon">
//                 {isDone ? '✅' : isCurrent ? '⏳' : '⬜'}
//               </div>
//               <div className="step-info">
//                 <span className="step-label">{step.label}</span>
//                 <span className="step-status">
//                   {isDone ? 'সম্পন্ন' : isCurrent ? 'চলমান' : 'বাকি'}
//                 </span>
//               </div>
//             </div>
//           );
//         })}
//       </div>
//     </div>
//   );
// };