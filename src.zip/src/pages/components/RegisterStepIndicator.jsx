// import React, { useEffect } from 'react';
// import { PROGRESS_MAP } from '../registerHelpers';

// export const RegisterStepIndicator = ({ currentStep, onStepClick }) => {
//   useEffect(() => {
//     const fill = document.getElementById('progressFill');
//     if (fill) fill.style.width = PROGRESS_MAP[currentStep] + '%';
    
//     for (let i = 1; i <= 6; i++) {
//       const dot = document.getElementById('dot' + i);
//       const lbl = document.getElementById('lbl' + i);
//       if (!dot) continue;
//       dot.classList.remove('active', 'done');
//       if (lbl) lbl.classList.remove('active');
//       if (i < currentStep) {
//         dot.classList.add('done');
//         dot.textContent = '✓';
//       } else if (i === currentStep) {
//         dot.classList.add('active');
//         dot.textContent = i < 6 ? String(i) : '✓';
//         if (lbl) lbl.classList.add('active');
//       } else {
//         dot.textContent = i < 6 ? String(i) : '✓';
//       }
//       const line = document.getElementById(`line${i}${i + 1}`);
//       if (line) line.classList.toggle('done', i < currentStep);
//     }
//   }, [currentStep]);

//   const steps = [
//     { n: 1, lbl: 'অ্যাকাউন্ট' },
//     { n: 2, lbl: 'ফোন OTP' },
//     { n: 3, lbl: 'যাচাই' },
//     { n: 4, lbl: 'ডকুমেন্ট' },
//     { n: 5, lbl: 'ফেস' },
//     { n: 6, lbl: 'সম্পন্ন' },
//   ];

//   return (
//     <>
//       <div className="progress-bar">
//         <div className="progress-fill" id="progressFill" style={{ width: '14%' }} />
//       </div>
//       <div className="step-indicator" id="stepIndicator">
//         {steps.map(({ n, lbl }, i, arr) => (
//           <React.Fragment key={n}>
//             <div className="step-dot-wrap" onClick={() => onStepClick(n)}>
//               <div className={`step-dot ${n === currentStep ? 'active' : n < currentStep ? 'done' : ''}`} id={`dot${n}`}>
//                 {n < currentStep ? '✓' : n < 6 ? n : '✓'}
//               </div>
//               <div className={`step-label ${n === currentStep ? 'active' : ''}`} id={`lbl${n}`}>{lbl}</div>
//             </div>
//             {i < arr.length - 1 && (
//               <div className={`step-line ${n < currentStep ? 'done' : ''}`} id={`line${n}${n + 1}`} />
//             )}
//           </React.Fragment>
//         ))}
//       </div>
//     </>
//   );
// };