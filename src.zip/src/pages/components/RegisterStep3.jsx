// import React from 'react';

// export const RegisterStep3 = ({ selectedVerify, setSelectedVerify, onNext, onBack, onSkip }) => {
//   const options = [
//     { type: 'nid', icon: '🪪', cls: 'vo-blue', title: 'জাতীয় পরিচয়পত্র (NID)', sub: 'উভয় পাশের ছবি আপলোড করুন' },
//     { type: 'birth', icon: '📄', cls: 'vo-green', title: 'জন্ম নিবন্ধন সনদ', sub: 'জন্ম নিবন্ধন সার্টিফিকেটের ছবি' },
//     { type: 'google', icon: '🔐', cls: 'vo-purple', title: 'Google অ্যাকাউন্ট', sub: 'Gmail যুক্ত করে যাচাই করুন' },
//   ];

//   return (
//     <div className={`step-panel ${true ? 'active' : ''}`} id="step3">
//       <div className="step-title">🪪 পরিচয় যাচাইয়ের উপায়</div>
//       <div className="step-subtitle">কোন পদ্ধতিতে যাচাই করতে চান?</div>

//       <div className="verify-options">
//         {options.map(({ type, icon, cls, title, sub }) => (
//           <label key={type}
//             className={`verify-option ${selectedVerify === type ? 'selected' : ''}`}
//             onClick={() => setSelectedVerify(type)}>
//             <input type="radio" name="verifyType" value={type} readOnly checked={selectedVerify === type} />
//             <div className={`vo-icon ${cls}`}>{icon}</div>
//             <div className="vo-body">
//               <div className="vo-title">{title}</div>
//               <div className="vo-sub">{sub}</div>
//             </div>
//             <div className="vo-check" />
//           </label>
//         ))}
//       </div>

//       <div className="info-box warn">
//         <span className="info-icon">⚠️</span>
//         <div>লেনদেন করতে হলে পরিচয় যাচাই <strong>বাধ্যতামূলক</strong>।</div>
//       </div>

//       <div className="btn-row">
//         <button className="btn btn-ghost" onClick={onBack}>← পিছনে</button>
//         <button className="btn btn-primary" onClick={onNext}>পরবর্তী →</button>
//       </div>
//       <div className="skip-link">
//         <button onClick={onSkip}>⏭ এখন এড়িয়ে যান</button>
//       </div>
//     </div>
//   );
// };