// import React from 'react';
// import { checkPasswordStrength } from '../registerHelpers';

// export const RegisterStep1 = ({ formData, updateField, loading, onNext, onGoogleSignUp }) => {
//   const togglePw = (id, btn) => {
//     const inp = document.getElementById(id);
//     if (!inp) return;
//     inp.type = inp.type === 'password' ? 'text' : 'password';
//     btn.textContent = inp.type === 'password' ? '👁️' : '🙈';
//   };

//   const strength = checkPasswordStrength(formData.password);

//   return (
//     <div className="step-panel active" id="step1">
//       <div className="step-title">📝 অ্যাকাউন্ট তৈরি করুন</div>
//       <div className="step-subtitle">ShopNest-এ স্বাগতম! প্রথমে আপনার তথ্য দিন।</div>

//       <div className="field-row">
//         <div className="field">
//           <label>নাম <span className="req">*</span></label>
//           <input type="text" placeholder="আপনার নাম" autoFocus
//             value={formData.firstName}
//             onChange={e => updateField('firstName', e.target.value)} />
//         </div>
//         <div className="field">
//           <label>পদবি</label>
//           <input type="text" placeholder="পদবি"
//             value={formData.lastName}
//             onChange={e => updateField('lastName', e.target.value)} />
//         </div>
//       </div>

//       <div className="field">
//         <label>ইমেইল <span className="req">*</span></label>
//         <input type="email" placeholder="example@email.com"
//           value={formData.email}
//           onChange={e => updateField('email', e.target.value)} />
//         <div className="field-error" id="emailErr">সঠিক ইমেইল দিন</div>
//       </div>

//       <div className="field">
//         <label>পাসওয়ার্ড <span className="req">*</span></label>
//         <div className="pw-wrap">
//           <input type="password" id="regPass" placeholder="কমপক্ষে ৬ অক্ষর"
//             value={formData.password}
//             onChange={e => updateField('password', e.target.value)} />
//           <button className="pw-toggle" onClick={e => togglePw('regPass', e.currentTarget)}>👁️</button>
//         </div>
//         <div className="pw-strength">
//           <div className="pw-strength-fill" id="pwFill" style={{ width: strength.width, background: strength.color }} />
//         </div>
//         <div className="field-hint" id="pwHint">🔒 {strength.label}</div>
//       </div>

//       <div className="field">
//         <label>পাসওয়ার্ড নিশ্চিত করুন <span className="req">*</span></label>
//         <div className="pw-wrap">
//           <input type="password" id="regPass2" placeholder="একই পাসওয়ার্ড পুনরায়"
//             value={formData.confirmPassword}
//             onChange={e => updateField('confirmPassword', e.target.value)} />
//           <button className="pw-toggle" onClick={e => togglePw('regPass2', e.currentTarget)}>👁️</button>
//         </div>
//         <div className="field-error" id="pass2Err">পাসওয়ার্ড মিলছে না</div>
//       </div>

//       <div className="field">
//         <label>জন্ম তারিখ <span className="req">*</span></label>
//         <input type="date" value={formData.dob}
//           onChange={e => updateField('dob', e.target.value)} />
//       </div>

//       <div className="field" style={{ marginTop: '1rem' }}>
//         <label>আপনি কি হিসেবে যোগ দিতে চান? <span className="req">*</span></label>
//         <div className="role-selector">
//           {['client', 'freelancer'].map(r => (
//             <label key={r} className={`role-option ${formData.role === r ? 'active' : ''}`}>
//               <input type="radio" value={r} checked={formData.role === r}
//                 onChange={() => updateField('role', r)} />
//               <i className={`fa-solid ${r === 'client' ? 'fa-briefcase' : 'fa-laptop-code'}`} />
//               <span>{r === 'client' ? 'ক্লায়েন্ট' : 'ফ্রিল্যান্সার'}</span>
//               <small>{r === 'client' ? 'ফ্রিল্যান্সার নিয়োগ করুন' : 'সার্ভিস অফার করুন'}</small>
//             </label>
//           ))}
//         </div>
//       </div>

//       <div className="divider"><span>অথবা</span></div>
//       <button className="social-btn" onClick={onGoogleSignUp} disabled={loading}>
//         <svg viewBox="0 0 24 24" width="20" height="20">
//           <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
//           <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
//           <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
//           <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
//         </svg>
//         Google দিয়ে নিবন্ধন করুন
//       </button>

//       <div className="btn-row" style={{ marginTop: '1.25rem' }}>
//         <button className="btn btn-primary" onClick={onNext} disabled={loading}>পরবর্তী ধাপ →</button>
//       </div>
//     </div>
//   );
// };