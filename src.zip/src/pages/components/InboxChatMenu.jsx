import React, { useRef, useEffect } from 'react';

export const InboxChatMenu = ({ 
  chat, 
  isOpen, 
  onClose, 
  onDelete, 
  onBlock, 
  onUnblock,
  menuRef,
  dotBtnRef 
}) => {
  if (!isOpen) return null;

  return (
    <div 
      className="chat-menu-dropdown" 
      ref={menuRef}
      onClick={(e) => e.stopPropagation()}
      style={{ display: 'block' }}
    >
      <button 
        className={`chat-menu-item delete ${chat.isActiveDeal ? 'disabled' : ''}`}
        onClick={(e) => {
          e.stopPropagation();
          e.preventDefault();
          onDelete(chat);
        }}
        disabled={chat.isActiveDeal}
      >
        <i className="fa-solid fa-trash"></i>
        <span>{chat.isActiveDeal ? 'Cannot Delete (Active Deal)' : 'Delete Conversation'}</span>
      </button>
      
      {chat.isBlocked ? (
        <button 
          className="chat-menu-item unblock"
          onClick={(e) => {
            e.stopPropagation();
            e.preventDefault();
            onUnblock(chat);
          }}
        >
          <i className="fa-solid fa-unlock"></i>
          <span>Unblock User</span>
        </button>
      ) : (
        <button 
          className="chat-menu-item block"
          onClick={(e) => {
            e.stopPropagation();
            e.preventDefault();
            onBlock(chat);
          }}
        >
          <i className="fa-solid fa-ban"></i>
          <span>Block User</span>
        </button>
      )}
    </div>
  );
};