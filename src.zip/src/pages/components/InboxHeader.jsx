import React from 'react';

export const InboxHeader = ({ currentMode, handleModeChange, getUnreadCount, filteredChats }) => {
  return (
    <div className="w-header">
      <div className="w-header-top">
        <h2 className="inbox-title">
          <i className="fa-solid fa-envelope"></i> Inbox
        </h2>
        <span className="inbox-count">{getUnreadCount()} unread</span>
      </div>
    </div>
  );
};