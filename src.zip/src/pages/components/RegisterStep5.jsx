// import React from 'react';

// export const RegisterStep5 = ({ 
//   cameraActive, videoRef, canvasRef, faceVerified, faceStatusMsg,
//   livenessState, currentLivIdx, livenessComplete, livenessMessage,
//   livenessProgress, getDoneCount,
//   onStartCamera, onStopCamera, onSkip, onBack
// }) => {
//   return (
//     <div className={`step-panel ${true ? 'active' : ''}`} id="step5">
//       <div className="step-title">📸 মুখমণ্ডল যাচাই</div>
//       <div className="step-subtitle">নিচের নির্দেশনা অনুসরণ করুন। কোনো AI দরকার নেই! 😊</div>

//       <div className="liveness-instructions">
//         {livenessState.map((step, idx) => (
//           <div key={step.id}
//             className={`instruction-step ${step.done ? 'done' : idx === currentLivIdx && cameraActive ? 'active' : ''}`}>
//             <div className="inst-icon">{step.emoji || '📌'}</div>
//             <div className="inst-text">{step.label}</div>
//             <div className="inst-status">
//               {step.done ? '✅' : idx === currentLivIdx && cameraActive ? '⏳' : '⬜'}
//             </div>
//           </div>
//         ))}
//       </div>

//       <div className={`camera-box ${cameraActive ? 'camera-active' : ''}`} style={{ position: 'relative' }}>
//         <video ref={videoRef} autoPlay muted playsInline
//           style={{ display: cameraActive ? 'block' : 'none', width: '100%', borderRadius: '8px' }} />
//         <canvas ref={canvasRef} style={{ display: 'none' }} />
//         {!cameraActive && (
//           <div className="camera-placeholder"><span>📷</span><div>ক্যামেরা চালু করুন</div></div>
//         )}
//         {cameraActive && !livenessComplete && (
//           <div style={{
//             position: 'absolute', bottom: '10px', left: '50%', transform: 'translateX(-50%)',
//             background: 'rgba(0,0,0,0.8)', color: '#fff',
//             padding: '8px 18px', borderRadius: '20px', fontSize: '0.9rem',
//             fontWeight: 600, whiteSpace: 'nowrap', maxWidth: '90%', textAlign: 'center'
//           }}>
//             {livenessMessage}
//           </div>
//         )}
//         {livenessComplete && (
//           <div style={{
//             position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
//             background: 'rgba(0,0,0,0.8)', color: '#4ade80',
//             padding: '20px 30px', borderRadius: '12px', fontSize: '1.2rem',
//             fontWeight: 700, textAlign: 'center'
//           }}>
//             🎉 সব সম্পন্ন!
//           </div>
//         )}
//       </div>

//       <div className="liveness-progress">
//         <div className="progress-text" id="livenessProgressText">
//           {getDoneCount()}/{livenessState.length} সম্পন্ন
//         </div>
//         <div className="progress-bar-small">
//           <div className="progress-fill-small"
//             id="livenessProgressFill"
//             style={{ width: `${livenessProgress}%`, transition: 'width 0.4s ease' }} />
//         </div>
//       </div>

//       {faceStatusMsg === 'captured' && (
//         <div className="info-box success">
//           <span className="info-icon">✅</span>
//           <div>মুখমণ্ডলের ছবি সফলভাবে ক্যাপচার হয়েছে!</div>
//         </div>
//       )}

//       <div className="btn-row">
//         {!cameraActive && !faceVerified && (
//           <button className="btn btn-primary" onClick={onStartCamera}>📷 ক্যামেরা চালু</button>
//         )}
//         {cameraActive && !livenessComplete && !faceVerified && (
//           <button className="btn btn-danger" onClick={onStopCamera}>⏹ বাতিল</button>
//         )}
//       </div>

//       <div style={{ marginTop: '.75rem' }}>
//         <button className="btn btn-ghost" onClick={onBack}>← পিছনে</button>
//       </div>

//       <div className="info-box info" style={{ marginTop: '1rem' }}>
//         <span className="info-icon">ℹ️</span>
//         <div>
//           <strong>লাইভনেস চেক কীভাবে কাজ করে?</strong><br />
//           ১. ক্যামেরা চালু করুন<br />
//           ২. প্রতি ২.২ সেকেন্ডে একটি নির্দেশনা দেখাবে<br />
//           ৩. নির্দেশনা অনুসরণ করুন (চোখ খোলা/বন্ধ, মুখ খোলা/বন্ধ, মাথা ডানে/বামে)<br />
//           ৪. সব ধাপ শেষ হলে ছবি তোলা হবে
//         </div>
//       </div>

//       <div className="skip-link">
//         <button onClick={onSkip}>⏭ এখন এড়িয়ে যান</button>
//       </div>
//     </div>
//   );
// };