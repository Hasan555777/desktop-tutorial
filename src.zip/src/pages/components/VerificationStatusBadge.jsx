// import React from 'react';
// import { VERIFICATION_STATUS } from '../registerHelpers';

// export const VerificationStatusBadge = ({ status, showTooltip = true }) => {
//   const statusData = VERIFICATION_STATUS[status?.toUpperCase()] || VERIFICATION_STATUS.INCOMPLETE;

//   return (
//     <div className="verification-badge" style={{ backgroundColor: statusData.color + '20', borderColor: statusData.color }}>
//       <span className="badge-icon">{statusData.badge}</span>
//       <span className="badge-label" style={{ color: statusData.color }}>
//         {statusData.label}
//       </span>
//       {showTooltip && (
//         <span className="badge-tooltip">{statusData.description}</span>
//       )}
//     </div>
//   );
// };