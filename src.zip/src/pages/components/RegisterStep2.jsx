// import React from 'react';

// export const RegisterStep2 = ({ 
//   formData, updateField, otpSent, otpTimer, 
//   onSendOTP, onResendOTP, onBack, onOtpInput 
// }) => {
//   return (
//     <div className={`step-panel ${true ? 'active' : ''}`} id="step2">
//       <div className="step-title">📱 ফোন নম্বর যাচাই</div>
//       <div className="step-subtitle">আপনার মোবাইলে একটি OTP পাঠানো হবে।</div>

//       <div className="field">
//         <label>মোবাইল নম্বর <span className="req">*</span></label>
//         <div className="phone-row">
//           <select value={formData.countryCode}
//             onChange={e => updateField('countryCode', e.target.value)}>
//             <option value="+880">🇧🇩 +880</option>
//             <option value="+91">🇮🇳 +91</option>
//             <option value="+1">🇺🇸 +1</option>
//             <option value="+44">🇬🇧 +44</option>
//             <option value="+61">🇦🇺 +61</option>
//           </select>
//           <input type="tel" placeholder="01XXXXXXXXX" maxLength="11"
//             value={formData.phone}
//             onChange={e => updateField('phone', e.target.value)} />
//         </div>
//         <div className="field-error" id="phoneErr">সঠিক নম্বর দিন</div>
//       </div>

//       {otpSent && (
//         <div>
//           <div className="info-box info"><span className="info-icon">📱</span><span>OTP পাঠানো হয়েছে।</span></div>
//           <div style={{ marginTop: '1rem' }}>
//             <label style={{ textAlign: 'center', display: 'block', marginBottom: '.75rem' }}>OTP কোড লিখুন</label>
//             <div className="otp-row">
//               {[0,1,2,3,4,5].map(idx => (
//                 <input key={idx} className="otp-box" maxLength="1" type="text" inputMode="numeric"
//                   value={formData.otp[idx] || ''}
//                   onChange={e => onOtpInput(idx, e.target.value)} />
//               ))}
//             </div>
//           </div>
//           <div className="resend-row">
//             কোড পাননি?{' '}
//             <button className="resend-btn" onClick={onResendOTP} disabled={otpTimer > 0}>
//               পুনরায় পাঠান {otpTimer > 0 && <span>({otpTimer}s)</span>}
//             </button>
//           </div>
//         </div>
//       )}

//       <div className="btn-row">
//         <button className="btn btn-ghost" onClick={onBack}>← পিছনে</button>
//         <button className="btn btn-primary" onClick={onSendOTP}>📨 OTP পাঠান</button>
//       </div>
//     </div>
//   );
// };