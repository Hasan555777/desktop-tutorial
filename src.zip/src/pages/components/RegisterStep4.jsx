// import React, { useRef } from 'react';

// export const RegisterStep4 = ({ 
//   selectedVerify, onNext, onBack, onSkip, uploadingDocs,
//   onFileUpload, onRemoveFile 
// }) => {
//   const nidFrontRef = useRef(null);
//   const nidBackRef = useRef(null);
//   const birthRef = useRef(null);

//   const previewFile = (file, areaId, previewId, removeBtnId) => {
//     if (!file) return;
//     const area = document.getElementById(areaId);
//     const preview = document.getElementById(previewId);
//     const removeBtn = document.getElementById(removeBtnId);
//     if (file.type.startsWith('image/')) {
//       const reader = new FileReader();
//       reader.onload = e => {
//         if (preview) preview.src = e.target.result;
//         area?.classList.add('has-file');
//         if (removeBtn) removeBtn.style.display = 'block';
//       };
//       reader.readAsDataURL(file);
//     } else {
//       area?.classList.add('has-file');
//       if (removeBtn) removeBtn.style.display = 'block';
//     }
//   };

//   const removeFile = (inputRef, areaId, previewId, removeBtnId) => {
//     if (inputRef.current) inputRef.current.value = '';
//     const preview = document.getElementById(previewId);
//     if (preview) preview.src = '';
//     document.getElementById(areaId)?.classList.remove('has-file');
//     const rb = document.getElementById(removeBtnId);
//     if (rb) rb.style.display = 'none';
//   };

//   return (
//     <div className={`step-panel ${true ? 'active' : ''}`} id="step4">
//       <div className="step-title">
//         {selectedVerify === 'birth' ? '📄 জন্ম নিবন্ধন আপলোড' :
//          selectedVerify === 'google' ? '🔐 Google যাচাই' : '🪪 NID কার্ড আপলোড'}
//       </div>
//       <div className="step-subtitle">
//         {selectedVerify === 'birth' ? 'জন্ম নিবন্ধন সনদের পরিষ্কার ছবি তুলুন।' :
//          selectedVerify === 'google' ? 'Google অ্যাকাউন্ট যুক্ত করে যাচাই করুন।' :
//          'কার্ডের সামনে ও পিছনের পরিষ্কার ছবি তুলুন।'}
//       </div>

//       {selectedVerify === 'nid' && (
//         <div className="upload-row">
//           {[
//             { ref: nidFrontRef, id: 'nidFront', areaId: 'nidFrontArea', previewId: 'nidFrontPreview', removeId: 'nidFrontRemove', label: 'সামনের পাশ', icon: '🪪' },
//             { ref: nidBackRef, id: 'nidBack', areaId: 'nidBackArea', previewId: 'nidBackPreview', removeId: 'nidBackRemove', label: 'পিছনের পাশ', icon: '🔄' },
//           ].map(({ ref, id, areaId, previewId, removeId, label, icon }) => (
//             <div className="field" key={id}>
//               <label>{label} <span className="req">*</span></label>
//               <div className="upload-area" id={areaId} onClick={() => ref.current?.click()}>
//                 <input type="file" accept="image/*" ref={ref}
//                   onChange={e => { previewFile(e.target.files[0], areaId, previewId, removeId); onFileUpload(id, e.target.files[0]); }} />
//                 <div className="upload-default">
//                   <div className="upload-icon">{icon}</div>
//                   <div className="upload-label">{label}</div>
//                   <div className="upload-sub">JPG, PNG, HEIC</div>
//                 </div>
//                 <img id={previewId} className="upload-preview" alt="" />
//                 <button className="upload-remove-btn" id={removeId} style={{ display: 'none' }}
//                   onClick={ev => { ev.stopPropagation(); removeFile(ref, areaId, previewId, removeId); onRemoveFile(id); }}>
//                   ✕ সরান
//                 </button>
//               </div>
//             </div>
//           ))}
//         </div>
//       )}

//       {selectedVerify === 'birth' && (
//         <div className="field">
//           <label>জন্ম নিবন্ধন সনদ <span className="req">*</span></label>
//           <div className="upload-area" id="birthArea" onClick={() => birthRef.current?.click()}>
//             <input type="file" accept="image/*,application/pdf" ref={birthRef}
//               onChange={e => { previewFile(e.target.files[0], 'birthArea', 'birthPreview', 'birthRemove'); onFileUpload('birth', e.target.files[0]); }} />
//             <div className="upload-default">
//               <div className="upload-icon">📄</div>
//               <div className="upload-label">সনদের ছবি বা PDF</div>
//               <div className="upload-sub">JPG, PNG, PDF</div>
//             </div>
//             <img id="birthPreview" className="upload-preview" alt="" />
//             <button className="upload-remove-btn" id="birthRemove" style={{ display: 'none' }}
//               onClick={ev => { ev.stopPropagation(); removeFile(birthRef, 'birthArea', 'birthPreview', 'birthRemove'); onRemoveFile('birth'); }}>
//               ✕ সরান
//             </button>
//           </div>
//         </div>
//       )}

//       {selectedVerify === 'google' && (
//         <button className="social-btn" onClick={() => {}}>
//           <svg viewBox="0 0 24 24" width="20" height="20">
//             <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
//             <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
//             <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
//             <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
//           </svg>
//           Google অ্যাকাউন্ট যুক্ত করুন
//         </button>
//       )}

//       <div className="info-box info" style={{ marginTop: '1rem' }}>
//         <span className="info-icon">🔒</span>
//         <div>আপনার ডকুমেন্ট নিরাপদ। Cloudinary-এ এনক্রিপ্টেড থাকবে।</div>
//       </div>

//       <div className="btn-row">
//         <button className="btn btn-ghost" onClick={onBack}>← পিছনে</button>
//         <button className="btn btn-primary" onClick={onNext} disabled={uploadingDocs}>পরবর্তী →</button>
//       </div>
//       <div className="skip-link">
//         <button onClick={onSkip}>⏭ এই ধাপ এড়িয়ে যান</button>
//       </div>
//     </div>
//   );
// };