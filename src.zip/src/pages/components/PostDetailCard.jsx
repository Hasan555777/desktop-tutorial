import React from 'react';

export const PostDetailCard = ({ 
  postData, onViewPost, canSendOffer, onSendOffer, 
  canApproveDeal, onApproveDeal, onRejectDeal, onReopenDeal,
  existingDeal, getPendingBadgeText 
}) => {
  return (
    <div className="post-detail-card">
      <img src={postData.image} alt="Post" className="post-img" />
      <div className="post-info">
        <div className="post-title">{postData.title}</div>
        <div className="post-desc">{postData.description?.substring(0, 80)}...</div>
        
        <div className="action-buttons">
          <button className="btn-view" onClick={onViewPost}>
            <i className="fa-regular fa-eye"></i> View Post
          </button>

          {canSendOffer && (
            <button className="btn-offer" onClick={onSendOffer}>
              <i className="fa-solid fa-paper-plane"></i> Send Offer
            </button>
          )}

          {canApproveDeal && (
            <>
              <button className="btn-approve" onClick={onApproveDeal}>
                <i className="fa-solid fa-check-circle"></i> Confirm Deal
              </button>
              <button className="btn-reject" onClick={onRejectDeal}>
                <i className="fa-solid fa-times-circle"></i> Reject Offer
              </button>
            </>
          )}

          {existingDeal?.status === 'active' && (
            <span className="deal-active-badge">
              <i className="fa-solid fa-check-double"></i> ⚡ Deal Active
            </span>
          )}

          {existingDeal?.status === 'pending' && !canApproveDeal && (
            <span className="deal-pending-badge">
              <i className="fa-solid fa-clock"></i> {getPendingBadgeText()}
            </span>
          )}

          {existingDeal?.status === 'rejected' && (
            <span className="deal-rejected-badge">
              <i className="fa-solid fa-ban"></i> ❌ Offer Rejected
            </span>
          )}

          {existingDeal?.status === 'cancelled' && (
            <div className="cancelled-deal-actions">
              <span className="deal-cancelled-badge">
                <i className="fa-solid fa-ban"></i> ❌ Deal Cancelled
              </span>
              <button className="btn-reopen-deal" onClick={onReopenDeal}>
                <i className="fa-solid fa-rotate-right"></i> Re-open Deal
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PostDetailCard;  // ✅ default export
