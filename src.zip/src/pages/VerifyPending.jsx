// src/pages/VerifyPending.jsx
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useAccessControl } from './hooks/useAccessControl';
import './VerifyPending.css';

const VerifyPending = () => {
  const navigate = useNavigate();
  const { logout } = useAuth();
  const { 
    statusMessage, 
    isRejected, 
    isBlocked,
    isFullyVerified,
    isPending,
    isComplete,
    accessLevel,
    accessLabel,
    needsVerification
  } = useAccessControl();

  // ── যদি ভেরিফাইড হয়ে থাকে তাহলে ড্যাশবোর্ডে পাঠান ──
  if (isFullyVerified) {
    navigate('/');
    return null;
  }

  // ── লোডিং ──
  if (!statusMessage) {
    return (
      <div className="verify-pending-container">
        <div className="verify-card">
          <div className="verify-icon info">ℹ️</div>
          <h2>লোড হচ্ছে...</h2>
          <p>দয়া করে অপেক্ষা করুন...</p>
        </div>
      </div>
    );
  }

  // ── আইকন নির্ধারণ ──
  const getIcon = () => {
    if (isBlocked) return '🚫';
    if (isRejected) return '❌';
    if (isPending) return '⏳';
    if (!isComplete) return '📝';
    if (isFullyVerified) return '✅';
    return 'ℹ️';
  };

  // ── টাইপ নির্ধারণ ──
  const getType = () => {
    if (isBlocked || isRejected) return 'error';
    if (isPending) return 'pending';
    if (!isComplete) return 'incomplete';
    if (isFullyVerified) return 'success';
    return 'info';
  };

  // ── টাইটেল নির্ধারণ ──
  const getTitle = () => {
    if (isBlocked) return '🚫 অ্যাকাউন্ট ব্লক করা হয়েছে';
    if (isRejected) return '❌ যাচাই প্রত্যাখ্যাত';
    if (isPending) return '⏳ যাচাই প্রক্রিয়াধীন';
    if (!isComplete) return '📝 প্রোফাইল সম্পূর্ণ করুন';
    if (isFullyVerified) return '✅ যাচাই সম্পন্ন!';
    return 'ℹ️ তথ্য';
  };

  // ── মেসেজ নির্ধারণ ──
  const getMessage = () => {
    if (isBlocked) {
      return 'আপনার অ্যাকাউন্ট অ্যাডমিন দ্বারা ব্লক করা হয়েছে। অনুগ্রহ করে সাপোর্ট টিমের সাথে যোগাযোগ করুন।';
    }
    if (isRejected) {
      return 'আপনার জমা দেওয়া ডকুমেন্ট যাচাই প্রত্যাখ্যাত হয়েছে। সঠিক ও স্পষ্ট ডকুমেন্ট পুনরায় আপলোড করুন।';
    }
    if (isPending) {
      return 'আপনার ডকুমেন্ট ২৪-৪৮ ঘণ্টার মধ্যে পর্যালোচনা করা হবে। আপনি নোটিফিকেশন পাবেন।';
    }
    if (!isComplete) {
      return 'লেনদেন করার জন্য আপনার প্রোফাইল সম্পূর্ণ করুন। সেটিংসে গিয়ে বাকি তথ্য দিন।';
    }
    if (isFullyVerified) {
      return 'আপনার অ্যাকাউন্ট সম্পূর্ণ যাচাই করা হয়েছে। এখন সব সুবিধা পাবেন।';
    }
    return 'দয়া করে অপেক্ষা করুন...';
  };

  // ── সাব-টেক্সট নির্ধারণ ──
  const getSubText = () => {
    if (isBlocked) {
      return 'আপনি কোনো লেনদেন করতে পারবেন না।';
    }
    if (isRejected) {
      return 'পুনরায় আপলোড করার আগে ডকুমেন্ট সঠিক কিনা যাচাই করে নিন।';
    }
    if (isPending) {
      return 'এ সময় আপনি শুধু ব্রাউজ করতে পারবেন।';
    }
    if (!isComplete) {
      return `বর্তমান প্রগ্রেস: ${statusMessage.progress || 0}% সম্পন্ন।`;
    }
    return '';
  };

  const type = getType();
  const icon = getIcon();
  const title = getTitle();
  const message = getMessage();
  const subText = getSubText();

  return (
    <div className="verify-pending-container">
      <div className="verify-card">
        <div className={`verify-icon ${type}`}>
          {icon}
        </div>
        
        <h2>{title}</h2>
        <p className="verify-message">{message}</p>
        
        {subText && (
          <p className="verify-sub-text">{subText}</p>
        )}

        {/* ── অ্যাকশন বাটন ── */}
        <div className="verify-actions">
          {isBlocked && (
            <button 
              className="btn-support" 
              onClick={() => window.location.href = 'mailto:support@workhub.com'}
            >
              📧 সাপোর্টে ইমেইল করুন
            </button>
          )}
          
          {isRejected && (
            <button 
              className="btn-retry" 
              onClick={() => navigate('/settings')}
            >
              📄 পুনরায় ডকুমেন্ট আপলোড করুন
            </button>
          )}
          
          {!isComplete && !isBlocked && !isRejected && (
            <button 
              className="btn-continue" 
              onClick={() => navigate('/settings')}
            >
              ⚙️ প্রোফাইল সম্পূর্ণ করুন
            </button>
          )}
          
          {isPending && (
            <button 
              className="btn-refresh" 
              onClick={() => window.location.reload()}
            >
              🔄 স্ট্যাটাস চেক করুন
            </button>
          )}
          
          {isFullyVerified && (
            <button 
              className="btn-dashboard" 
              onClick={() => navigate('/')}
            >
              🏠 ড্যাশবোর্ডে যান
            </button>
          )}
        </div>

        {/* ── প্রগ্রেস বার (শুধু পেন্ডিং বা অসম্পূর্ণ) ── */}
        {(isPending || !isComplete) && (
          <div className="verify-progress">
            <div className="progress-bar">
              <div 
                className={`progress-fill ${type}`}
                style={{ 
                  width: isPending ? '60%' : `${statusMessage?.progress || 0}%` 
                }}
              />
            </div>
            <span className="progress-label">
              {isPending ? 'যাচাই চলছে...' : `${statusMessage?.progress || 0}% সম্পন্ন`}
            </span>
          </div>
        )}

        {/* ── লগআউট বাটন ── */}
        <div className="verify-footer">
          <button className="btn-logout" onClick={logout}>
            🔓 লগ আউট করুন
          </button>
        </div>
      </div>
    </div>
  );
};

export default VerifyPending;