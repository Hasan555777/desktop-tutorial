// src/pages/Admin/AdminDashboard.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  doc, getDoc, getDocs, updateDoc, deleteDoc, 
  collection, query, where, orderBy, limit, 
  serverTimestamp, onSnapshot, setDoc, addDoc,
  increment, arrayUnion, arrayRemove, getCountFromServer,  writeBatch  
} from "firebase/firestore";
import { auth, db } from '../firebase';
import toast, { Toaster } from 'react-hot-toast';
import { deleteUser as deleteFirebaseUser } from "firebase/auth";
import './AdminDashboard.css';

// Cloudinary কনফিগারেশন
const CLOUD_NAME = "drwex6tmf";

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('dashboard');
  
  // ── Search State ──
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  
  // ── Stats ──
  const [stats, setStats] = useState({
    totalUsers: 0,
    verifiedUsers: 0,
    pendingUsers: 0,
    blockedUsers: 0,
    totalPosts: 0,
    totalDeals: 0,
    totalTransactions: 0,
    totalRevenue: 0,
    pendingWithdrawals: 0
  });
  
  // ── Data States ──
  const [users, setUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [posts, setPosts] = useState([]);
  const [deals, setDeals] = useState([]);
  const [withdrawals, setWithdrawals] = useState([]);
  
  // ── Filter States ──
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterType, setFilterType] = useState('all');
  
  // ── Notification States ──
  const [notificationMessage, setNotificationMessage] = useState('');
  const [notificationType, setNotificationType] = useState('info');
  const [notifications, setNotifications] = useState([]);
  const [sendingNotification, setSendingNotification] = useState(false);
  const [selectedUsersForNotify, setSelectedUsersForNotify] = useState([]);

  // ============================================================
  // ✅ অ্যাডমিন অ্যাক্সেস চেক
  // ============================================================
// AdminDashboard.jsx
useEffect(() => {
  const checkAdmin = async () => {
    const user = auth.currentUser;
    console.log("🔍 AdminDashboard - Current user:", user?.email);
    
    if (!user) {
      console.log("❌ No user, redirecting to login");
      navigate('/login');
      return;
    }
    
    try {
      const userDoc = await getDoc(doc(db, 'users', user.uid));
      
      if (!userDoc.exists()) {
        console.log("❌ User document not found!");
        toast.error('❌ ইউজার ডেটা পাওয়া যায়নি!');
        navigate('/');
        return;
      }
      
      const data = userDoc.data();
      console.log("📊 User data:", {
        email: data.email,
        role: data.role,
        isAdmin: data.role === 'admin'
      });
      
      // ✅ অ্যাডমিন ইমেইল লিস্ট
      const adminEmails = [
        'hammanmusa362@gmail.com',
        'hasanmahmudmd362@gmail.com',
      ];
      
      // ✅ রোল অথবা ইমেইল চেক
      if (data.role !== 'admin' && !adminEmails.includes(user.email)) {
        console.log(`❌ Access denied! Role: ${data.role}, Email: ${user.email}`);
        toast.error('❌ আপনার অ্যাডমিন অ্যাক্সেস নেই!');
        navigate('/');
        return;
      }
      
      console.log("✅ Admin access granted!");
      loadAllData();
      
    } catch (error) {
      console.error('❌ Admin check error:', error);
      navigate('/');
    }
  };
  
  checkAdmin();
}, [navigate]);

  // ============================================================
  // ✅ সব ডাটা লোড
  // ============================================================
  const loadAllData = async () => {
    setLoading(true);
    
    try {
      await Promise.all([
        loadUsers(),
        loadPosts(),
        loadDeals(),
        loadWithdrawals(),
        loadStats(),
        loadNotifications()
      ]);
      
    } catch (error) {
      console.error("Error loading data:", error);
      toast.error('ডেটা লোড করতে সমস্যা হয়েছে');
    } finally {
      setLoading(false);
    }
  };

  // ── Load Users ──
  const loadUsers = async () => {
    try {
      const usersRef = collection(db, 'users');
      const q = query(usersRef, orderBy('createdAt', 'desc'));
      const querySnap = await getDocs(q);
      
      const usersList = [];
      querySnap.forEach((doc) => {
        const data = doc.data();
        if (data.role !== 'admin') {
          usersList.push({
            id: doc.id,
            ...data,
            documents: data.documents || {},
            isComplete: data.isComplete || false,
            isVerified: data.isVerified || false,
            isBanned: data.isBanned || false,
            isBlocked: data.isBlocked || data.isBanned || false,
            createdAt: data.createdAt?.toDate?.() || new Date(),
            lastLogin: data.lastLogin?.toDate?.() || null
          });
        }
      });
      
      setUsers(usersList);
      setFilteredUsers(usersList);
    } catch (error) {
      console.error('Load users error:', error);
    }
  };

  // ── Load Posts ──
  const loadPosts = async () => {
    try {
      const postsRef = collection(db, 'posts');
      const q = query(postsRef, orderBy('createdAt', 'desc'), limit(100));
      const querySnap = await getDocs(q);
      
      const postsList = [];
      querySnap.forEach((doc) => {
        postsList.push({
          id: doc.id,
          ...doc.data(),
          createdAt: doc.data().createdAt?.toDate?.() || new Date()
        });
      });
      
      setPosts(postsList);
    } catch (error) {
      console.error('Load posts error:', error);
    }
  };

  // ── Load Deals ──
  const loadDeals = async () => {
    try {
      const dealsRef = collection(db, 'deals');
      const q = query(dealsRef, orderBy('createdAt', 'desc'), limit(100));
      const querySnap = await getDocs(q);
      
      const dealsList = [];
      querySnap.forEach((doc) => {
        dealsList.push({
          id: doc.id,
          ...doc.data(),
          createdAt: doc.data().createdAt?.toDate?.() || new Date()
        });
      });
      
      setDeals(dealsList);
    } catch (error) {
      console.error('Load deals error:', error);
    }
  };

  // ── Load Withdrawals ──
  const loadWithdrawals = async () => {
    try {
      const withdrawalsRef = collection(db, 'withdrawals');
      const q = query(withdrawalsRef, orderBy('requestedAt', 'desc'), limit(100));
      const querySnap = await getDocs(q);
      
      const withdrawalsList = [];
      querySnap.forEach((doc) => {
        withdrawalsList.push({
          id: doc.id,
          ...doc.data(),
          requestedAt: doc.data().requestedAt?.toDate?.() || new Date()
        });
      });
      
      setWithdrawals(withdrawalsList);
    } catch (error) {
      console.error('Load withdrawals error:', error);
    }
  };

  // ── Load Stats ──
  const loadStats = async () => {
    try {
      const usersRef = collection(db, 'users');
      const usersSnap = await getCountFromServer(usersRef);
      
      const postsRef = collection(db, 'posts');
      const postsSnap = await getCountFromServer(postsRef);
      
      const dealsRef = collection(db, 'deals');
      const dealsSnap = await getCountFromServer(dealsRef);
      
      const transactionsRef = collection(db, 'transactions');
      const transactionsSnap = await getCountFromServer(transactionsRef);
      
      const withdrawalsRef = collection(db, 'withdrawals');
      const pendingWithdrawalsQuery = query(withdrawalsRef, where('status', '==', 'pending'));
      const pendingWithdrawalsSnap = await getCountFromServer(pendingWithdrawalsQuery);
      
      const verifiedQuery = query(usersRef, where('isVerified', '==', true));
      const verifiedSnap = await getCountFromServer(verifiedQuery);
      
      const blockedQuery = query(usersRef, where('isBanned', '==', true));
      const blockedSnap = await getCountFromServer(blockedQuery);
      
      const totalUsers = usersSnap.data().count;
      const verifiedUsers = verifiedSnap.data().count;
      const blockedUsers = blockedSnap.data().count;
      
      setStats({
        totalUsers: totalUsers,
        verifiedUsers: verifiedUsers,
        pendingUsers: totalUsers - verifiedUsers - blockedUsers,
        blockedUsers: blockedUsers,
        totalPosts: postsSnap.data().count,
        totalDeals: dealsSnap.data().count,
        totalTransactions: transactionsSnap.data().count,
        totalRevenue: 125000,
        pendingWithdrawals: pendingWithdrawalsSnap.data().count
      });
      
    } catch (error) {
      console.error('Load stats error:', error);
    }
  };

  // ── Load Notifications ──
  const loadNotifications = async () => {
    try {
      const notifRef = collection(db, 'admin_notifications');
      const q = query(notifRef, orderBy('createdAt', 'desc'), limit(50));
      const querySnap = await getDocs(q);
      
      const notifList = [];
      querySnap.forEach((doc) => {
        notifList.push({
          id: doc.id,
          ...doc.data(),
          createdAt: doc.data().createdAt?.toDate?.() || new Date()
        });
      });
      
      setNotifications(notifList);
    } catch (error) {
      console.error('Load notifications error:', error);
    }
  };

  // ============================================================
  // ✅ ফিল্টারিং (ফিক্সড)
  // ============================================================
// useEffect-এ ফিল্টারিং অংশ আপডেট করুন
useEffect(() => {
  let filtered = [...users];
  
  // Search filter
  if (searchTerm) {
    filtered = filtered.filter(user => 
      user.displayName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.uniqueId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.firstName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.lastName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.phone?.includes(searchTerm)
    );
  }
  
  // ✅ Status filter (আপডেটেড)
  if (filterStatus === 'verified') {
    filtered = filtered.filter(user => user.isVerified === true);
  } else if (filterStatus === 'pending') {
    filtered = filtered.filter(user => user.isComplete && user.verificationStatus === 'pending' && !user.isVerified);
  } else if (filterStatus === 'pending_verification') {
    filtered = filtered.filter(user => user.isComplete && !user.isVerified && user.verificationStatus !== 'pending');
  } else if (filterStatus === 'incomplete') {
    filtered = filtered.filter(user => !user.isComplete && !user.isVerified);
  } else if (filterStatus === 'blocked') {
    filtered = filtered.filter(user => user.isBanned || user.isBlocked);
  }
  
  setFilteredUsers(filtered);
}, [searchTerm, filterStatus, users]);

  // ============================================================
  // ✅ সার্চ ফাংশন
  // ============================================================
// ============================================================
// ✅ সার্চ ফাংশন (ফিক্সড)
// ============================================================
const handleGlobalSearch = async (query) => {
  setSearchQuery(query);
  
  if (!query || query.trim().length < 2) {
    setSearchResults([]);
    setIsSearching(false);
    return;
  }
  
  setIsSearching(true);
  const searchTerm = query.trim().toLowerCase();
  const results = [];
  
  try {
    // ── ইউজার সার্চ ──
    const userResults = users.filter(user => 
      user.displayName?.toLowerCase().includes(searchTerm) ||
      user.email?.toLowerCase().includes(searchTerm) ||
      user.uniqueId?.toLowerCase().includes(searchTerm) ||
      user.id?.toLowerCase().includes(searchTerm) ||
      user.firstName?.toLowerCase().includes(searchTerm) ||
      user.lastName?.toLowerCase().includes(searchTerm) ||
      user.phone?.includes(searchTerm)
    ).map(user => ({ 
      ...user, 
      type: 'user',
      displayTitle: user.displayName || user.email || 'Unknown User'
    }));
    
    results.push(...userResults);
    
    // ── পোস্ট সার্চ ──
    const postResults = posts.filter(post =>
      post.title?.toLowerCase().includes(searchTerm) ||
      post.id?.toLowerCase().includes(searchTerm) ||
      post.postId?.toLowerCase().includes(searchTerm) ||
      post.description?.toLowerCase().includes(searchTerm)
    ).map(post => ({ 
      ...post, 
      type: 'post',
      displayTitle: post.title || 'Untitled Post'
    }));
    
    results.push(...postResults);
    
    // ── ডিল সার্চ ──
    const dealResults = deals.filter(deal =>
      deal.postTitle?.toLowerCase().includes(searchTerm) ||
      deal.id?.toLowerCase().includes(searchTerm) ||
      deal.dealIdNumber?.toLowerCase().includes(searchTerm) ||
      deal.buyerId?.toLowerCase().includes(searchTerm) ||
      deal.sellerId?.toLowerCase().includes(searchTerm)
    ).map(deal => ({ 
      ...deal, 
      type: 'deal',
      displayTitle: deal.postTitle || 'Deal'
    }));
    
    results.push(...dealResults);
    
    // ── উইথড্র সার্চ ──
    const withdrawalResults = withdrawals.filter(w =>
      w.id?.toLowerCase().includes(searchTerm) ||
      w.mobileNumber?.includes(searchTerm) ||
      w.userId?.toLowerCase().includes(searchTerm) ||
      w.bankAccount?.includes(searchTerm) ||
      w.accountHolder?.toLowerCase().includes(searchTerm)
    ).map(w => ({ 
      ...w, 
      type: 'withdrawal',
      displayTitle: `Withdrawal: ${w.id?.slice(-8)}`
    }));
    
    results.push(...withdrawalResults);
    
    setSearchResults(results);
    
  } catch (error) {
    console.error("Search error:", error);
  } finally {
    setIsSearching(false);
  }
};

  // ============================================================
  // ✅ ইউজার অপারেশন
  // ============================================================
// src/pages/Admin/AdminDashboard.jsx

// ============================================================
// ✅ ইউজার যাচাই (অ্যাডমিন অ্যাকশন)
// ============================================================
const verifyUser = async (userId, verified = true) => {
  try {
    // ✅ ইউজার ডকুমেন্ট আপডেট
    await updateDoc(doc(db, 'users', userId), {
      isVerified: verified,
      isComplete: verified,
      verifiedAt: serverTimestamp(),
      verifiedBy: auth.currentUser?.uid || 'admin',
      // ✅ নতুন ফিল্ড
      verificationStatus: verified ? 'verified' : 'rejected',
      documentsUploaded: true,
      documentVerified: verified
    });
    
    // ✅ লোকাল স্টেট আপডেট
    setUsers(prev => prev.map(user => 
      user.id === userId ? { 
        ...user, 
        isVerified: verified, 
        isComplete: verified,
        verificationStatus: verified ? 'verified' : 'rejected',
        documentVerified: verified
      } : user
    ));
    
    // ✅ নোটিফিকেশন
    await createUserNotification(
      userId,
      verified ? '✅ আপনার অ্যাকাউন্ট যাচাই সম্পন্ন হয়েছে!' : '❌ আপনার অ্যাকাউন্ট যাচাই প্রত্যাখ্যান করা হয়েছে।',
      verified ? 'success' : 'error'
    );
    
    toast.success(verified ? '✅ ইউজার যাচাই সম্পন্ন!' : '❌ ইউজার যাচাই প্রত্যাখ্যান');
    loadStats();
    
  } catch (error) {
    console.error('Verify user error:', error);
    toast.error('যাচাই করতে সমস্যা হয়েছে');
  }
};

// AdminDashboard.jsx - toggleBlockUser ফাংশন
const toggleBlockUser = async (userId, block = true) => {
  try {
    const blockData = block ? {
      isBanned: true,
      isBlocked: true,
      bannedAt: serverTimestamp(),
      bannedBy: auth.currentUser?.uid || 'admin',
      banReason: 'অ্যাডমিন দ্বারা ব্লক করা হয়েছে',
      blockExpiry: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // ২৪ ঘণ্টা
      blockCountdown: 86400 // ২৪ ঘণ্টা = ৮৬৪০০ সেকেন্ড
    } : {
      isBanned: false,
      isBlocked: false,
      bannedAt: null,
      bannedBy: null,
      banReason: null,
      blockExpiry: null,
      blockCountdown: null
    };
    
    await updateDoc(doc(db, 'users', userId), blockData);
    
    setUsers(prev => prev.map(user => 
      user.id === userId ? { ...user, isBanned: block, isBlocked: block } : user
    ));
    
    await createUserNotification(
      userId,
      block ? '🚫 আপনার অ্যাকাউন্ট ব্লক করা হয়েছে। ২৪ ঘণ্টার মধ্যে আনব্লক না করলে ডিলিট হয়ে যাবে।' : '✅ আপনার অ্যাকাউন্ট আনব্লক করা হয়েছে।',
      block ? 'error' : 'success'
    );
    
    toast.success(block ? '🚫 ইউজার ব্লক করা হয়েছে' : '✅ ইউজার আনব্লক করা হয়েছে');
    loadStats();
    
  } catch (error) {
    console.error('Toggle block error:', error);
    toast.error('অপারেশন ব্যর্থ হয়েছে');
  }
};


const deleteUser = async (userId) => {
  if (!window.confirm('⚠️ আপনি কি এই ইউজারকে স্থায়ীভাবে ডিলিট করতে চান? এই কাজটি পূর্বাবস্থায় ফেরানো যাবে না!')) {
    return;
  }
  
  try {
    // ── ১. ডিলিট নোটিফিকেশন পাঠান ──
    await createUserNotification(
      userId,
      '❌ আপনার অ্যাকাউন্ট অ্যাডমিন দ্বারা স্থায়ীভাবে ডিলিট করা হয়েছে।',
      'error'
    );
    
    // ── ২. নোটিফিকেশন সেভ হওয়ার জন্য অপেক্ষা ──
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // ── ৩. Firebase Auth থেকে ইউজার ডিলিট ──
    try {
      // ইউজারের রিফ্রেশ টোকেন রিভোক করতে
      await deleteFirebaseUser(auth.currentUser); // অ্যাডমিন নিজে ডিলিট করছে
      console.log("✅ User deleted from Firebase Auth");
    } catch (authError) {
      console.warn("⚠️ Auth delete error (user may not exist in Auth):", authError);
      // Auth এ না থাকলে error ignore করবেন
    }
    
    // ── ৪. Firestore থেকে ইউজার ডকুমেন্ট ডিলিট ──
    await deleteDoc(doc(db, 'users', userId));
    console.log("✅ User document deleted from Firestore");
    
    // ── ৫. ওয়ালেট ডিলিট ──
    await deleteDoc(doc(db, 'wallets', userId));
    console.log("✅ Wallet deleted");
    
    // ── ৬. ইউজারের সব নোটিফিকেশন ডিলিট ──
    const notifQuery = query(
      collection(db, 'notifications'), 
      where('userId', '==', userId)
    );
    const notifSnap = await getDocs(notifQuery);
    
    if (!notifSnap.empty) {
      const batch = writeBatch(db);
      notifSnap.docs.forEach(doc => batch.delete(doc.ref));
      await batch.commit();
      console.log("✅ Notifications deleted");
    }
    
    // ── ৭. ইউজারের চ্যাট ডিলিট ──
    const chatQuery = query(
      collection(db, 'chats'),
      where('participants', 'array-contains', userId)
    );
    const chatSnap = await getDocs(chatQuery);
    
    if (!chatSnap.empty) {
      const batch = writeBatch(db);
      chatSnap.docs.forEach(doc => batch.delete(doc.ref));
      await batch.commit();
      console.log("✅ Chats deleted");
    }
    
    // ── ৮. ইউজারের ডিল ডিলিট ──
    const dealQuery = query(
      collection(db, 'deals'),
      where('participants', 'array-contains', userId)
    );
    const dealSnap = await getDocs(dealQuery);
    
    if (!dealSnap.empty) {
      const batch = writeBatch(db);
      dealSnap.docs.forEach(doc => batch.delete(doc.ref));
      await batch.commit();
      console.log("✅ Deals deleted");
    }
    
    // ── ৯. লোকাল স্টেট আপডেট ──
    setUsers(prev => prev.filter(user => user.id !== userId));
    
    // ── ১০. অ্যাডমিন লগ ──
    await addDoc(collection(db, 'admin_logs'), {
      type: 'user_deleted',
      userId: userId,
      deletedBy: auth.currentUser?.uid || 'admin',
      deletedByEmail: auth.currentUser?.email || 'admin',
      deletedAt: serverTimestamp()
    });
    
    toast.success('🗑️ ইউজার সম্পূর্ণ ডিলিট করা হয়েছে! (Auth + Firestore)');
    loadStats();
    
  } catch (error) {
    console.error('Delete user error:', error);
    toast.error('ডিলিট করতে সমস্যা হয়েছে: ' + error.message);
  }
};




  // ============================================================

  // অ্যাডমিন যখন নোটিফিকেশন পাঠাবে
const createUserNotification = async (userId, message, type = 'info') => {
  try {
    await addDoc(collection(db, 'notifications'), { // সব নোটিফিকেশন এই এক কালেকশনে যাবে
      userId: userId, // খুব গুরুত্বপূর্ণ
      message: message,
      type: type,
      isUnread: true,
      createdAt: serverTimestamp()
    });
  } catch (error) {
    console.error('Error:', error);
  }
};

  // ============================================================
  // ✅ পোস্ট অপারেশন
  // ============================================================
  const handleDeletePost = async (postId) => {
    if (!window.confirm('⚠️ আপনি কি এই পোস্ট ডিলিট করতে চান?')) return;
    
    try {
      await deleteDoc(doc(db, 'posts', postId));
      setPosts(posts.filter(p => p.id !== postId));
      toast.success('✅ পোস্ট ডিলিট করা হয়েছে!');
      loadStats();
      
    } catch (error) {
      console.error("Delete post error:", error);
      toast.error('পোস্ট ডিলিট করতে সমস্যা হয়েছে');
    }
  };

  // ============================================================
  // ✅ উইথড্র অপারেশন
  // ============================================================
  const handleApproveWithdrawal = async (withdrawalId, userId, amount) => {
    try {
      const withdrawalRef = doc(db, 'withdrawals', withdrawalId);
      await updateDoc(withdrawalRef, { 
        status: 'processing',
        processedAt: serverTimestamp(),
        processedBy: auth.currentUser?.uid || 'admin'
      });
      
      setWithdrawals(withdrawals.map(w => 
        w.id === withdrawalId ? { ...w, status: 'processing' } : w
      ));
      
      await createUserNotification(
        userId,
        `💳 আপনার ৳${amount} উইথড্র অনুমোদন করা হয়েছে এবং প্রক্রিয়াধীন।`,
        'info'
      );
      
      toast.success(`✅ ৳${amount} উইথড্র অনুমোদন করা হয়েছে!`);
      loadStats();
      
    } catch (error) {
      console.error("Approve withdrawal error:", error);
      toast.error('উইথড্র অনুমোদন করতে সমস্যা হয়েছে');
    }
  };

  const handleCompleteWithdrawal = async (withdrawalId, userId, amount) => {
    try {
      const withdrawalRef = doc(db, 'withdrawals', withdrawalId);
      await updateDoc(withdrawalRef, { 
        status: 'completed',
        completedAt: serverTimestamp(),
        completedBy: auth.currentUser?.uid || 'admin'
      });
      
      setWithdrawals(withdrawals.map(w => 
        w.id === withdrawalId ? { ...w, status: 'completed' } : w
      ));
      
      await createUserNotification(
        userId,
        `✅ আপনার ৳${amount} উইথড্র সম্পন্ন হয়েছে।`,
        'success'
      );
      
      toast.success(`✅ ৳${amount} উইথড্র সম্পন্ন!`);
      loadStats();
      
    } catch (error) {
      console.error("Complete withdrawal error:", error);
      toast.error('উইথড্র সম্পন্ন করতে সমস্যা হয়েছে');
    }
  };

  const handleRejectWithdrawal = async (withdrawalId, userId, amount) => {
    if (!window.confirm(`⚠️ ৳${amount} উইথড্র প্রত্যাখ্যান করবেন?`)) return;
    
    try {
      const withdrawalRef = doc(db, 'withdrawals', withdrawalId);
      await updateDoc(withdrawalRef, { 
        status: 'rejected',
        rejectedAt: serverTimestamp(),
        rejectedBy: auth.currentUser?.uid || 'admin'
      });
      
      setWithdrawals(withdrawals.map(w => 
        w.id === withdrawalId ? { ...w, status: 'rejected' } : w
      ));
      
      await createUserNotification(
        userId,
        `❌ আপনার ৳${amount} উইথড্র প্রত্যাখ্যান করা হয়েছে।`,
        'error'
      );
      
      toast.success(`❌ ৳${amount} উইথড্র প্রত্যাখ্যান করা হয়েছে!`);
      loadStats();
      
    } catch (error) {
      console.error("Reject withdrawal error:", error);
      toast.error('উইথড্র প্রত্যাখ্যান করতে সমস্যা হয়েছে');
    }
  };

  // ============================================================
  // ✅ বাল্ক নোটিফিকেশন (ফিক্সড)
  // ============================================================
  const sendBulkNotification = async () => {
    if (!notificationMessage.trim()) {
      toast.error('❌ মেসেজ লিখুন');
      return;
    }
    
    setSendingNotification(true);
    
    try {
      const targetUsers = selectedUsersForNotify.length > 0 
        ? selectedUsersForNotify 
        : users.map(u => u.id);
      
      // প্রতিটি ইউজারের জন্য নোটিফিকেশন তৈরি
      for (const userId of targetUsers) {
        await createUserNotification(userId, notificationMessage, notificationType);
      }
      
      // অ্যাডমিন নোটিফিকেশন লগ
      await addDoc(collection(db, 'admin_notifications'), {
        message: notificationMessage,
        type: notificationType,
        recipients: targetUsers,
        recipientCount: targetUsers.length,
        sentBy: auth.currentUser?.uid || 'admin',
        sentByEmail: auth.currentUser?.email || 'admin',
        createdAt: serverTimestamp()
      });
      
      toast.success(`✅ ${targetUsers.length} জন ইউজারকে নোটিফিকেশন পাঠানো হয়েছে!`);
      
      // ✅ ফিক্স ২: ক্লিয়ার
      setNotificationMessage('');
      setSelectedUsersForNotify([]);
      loadNotifications();
      
    } catch (error) {
      console.error('Send notification error:', error);
      toast.error('নোটিফিকেশন পাঠাতে সমস্যা হয়েছে');
    } finally {
      setSendingNotification(false);
    }
  };

  const toggleSelectAllUsers = () => {
    if (selectedUsersForNotify.length === filteredUsers.length) {
      setSelectedUsersForNotify([]);
    } else {
      setSelectedUsersForNotify(filteredUsers.map(u => u.id));
    }
  };

  const toggleUserSelection = (userId) => {
    if (selectedUsersForNotify.includes(userId)) {
      setSelectedUsersForNotify(prev => prev.filter(id => id !== userId));
    } else {
      setSelectedUsersForNotify(prev => [...prev, userId]);
    }
  };

  // ============================================================
  // ✅ হেল্পার ফাংশন
  // ============================================================
  const formatDate = (date) => {
    if (!date) return 'N/A';
    return new Date(date).toLocaleDateString('bn-BD', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  const formatMoney = (amount) => {
    return new Intl.NumberFormat('bn-BD', {
      style: 'currency',
      currency: 'BDT',
      minimumFractionDigits: 0
    }).format(amount || 0);
  };

  const getStatusBadge = (status) => {
    const statusMap = {
      'active': 'active',
      'pending': 'pending',
      'processing': 'processing',
      'completed': 'completed',
      'rejected': 'rejected',
      'blocked': 'blocked',
      'verified': 'verified'
    };
    return statusMap[status] || 'pending';
  };

  // ============================================================
  // ✅ রেন্ডার ফাংশন
  // ============================================================
  const renderDashboard = () => (
    <div className="admin-dashboard">
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon blue">👥</div>
          <div className="stat-info">
            <h3>{stats.totalUsers}</h3>
            <p>মোট ইউজার</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon green">✅</div>
          <div className="stat-info">
            <h3>{stats.verifiedUsers}</h3>
            <p>যাচাইকৃত</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon yellow">⏳</div>
          <div className="stat-info">
            <h3>{stats.pendingUsers}</h3>
            <p>যাচাই বাকি</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon red">🚫</div>
          <div className="stat-info">
            <h3>{stats.blockedUsers}</h3>
            <p>ব্লককৃত</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon purple">📄</div>
          <div className="stat-info">
            <h3>{stats.totalPosts}</h3>
            <p>মোট পোস্ট</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon orange">🤝</div>
          <div className="stat-info">
            <h3>{stats.totalDeals}</h3>
            <p>মোট ডিল</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon teal">💳</div>
          <div className="stat-info">
            <h3>{stats.totalTransactions}</h3>
            <p>মোট লেনদেন</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon pink">⏳</div>
          <div className="stat-info">
            <h3>{stats.pendingWithdrawals}</h3>
            <p>অনুমোদন বাকি</p>
          </div>
        </div>
      </div>
      
      <div className="recent-activity">
        <h3>📋 সাম্প্রতিক নোটিফিকেশন</h3>
        <div className="notification-list">
          {notifications.slice(0, 10).map((notif) => (
            <div key={notif.id} className={`notification-item ${notif.type}`}>
              <div className="notif-message">{notif.message}</div>
              <div className="notif-meta">
                <span>{notif.recipientCount || 0} জন</span>
                <span>{formatDate(notif.createdAt)}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
const renderUsers = () => {
  // ✅ স্ট্যাটাস নির্ধারণ ফাংশন
  const getUserStatus = (user) => {
    if (user.isBanned || user.isBlocked) {
      return { label: '🚫 ব্লক', className: 'blocked' };
    }
    if (user.isVerified) {
      return { label: '✅ যাচাইকৃত', className: 'verified' };
    }
    if (user.isComplete && user.verificationStatus === 'pending') {
      return { label: '⏳ যাচাই প্রক্রিয়াধীন', className: 'pending' };
    }
    if (user.isComplete && !user.isVerified) {
      return { label: '🔄 যাচাই বাকি', className: 'pending_verification' };
    }
    return { label: '📝 অসম্পূর্ণ', className: 'incomplete' };
  };

  return (
    <div className="admin-users">
      <div className="users-header">
        <div className="users-search">
          <input 
            type="text" 
            placeholder="🔍 নাম, ইমেইল, আইডি, ফোন দিয়ে খুঁজুন..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <select 
            value={filterStatus} 
            onChange={(e) => setFilterStatus(e.target.value)}
          >
            <option value="all">📋 সব</option>
            <option value="verified">✅ যাচাইকৃত</option>
            <option value="pending">⏳ যাচাই প্রক্রিয়াধীন</option>
            <option value="pending_verification">🔄 যাচাই বাকি</option>
            <option value="incomplete">📝 অসম্পূর্ণ</option>
            <option value="blocked">🚫 ব্লক</option>
          </select>
        </div>
        <div className="users-actions">
          <button 
            className="btn btn-primary" 
            onClick={() => setActiveTab('notifications')}
          >
            📨 নোটিফিকেশন
          </button>
          <button className="btn btn-secondary" onClick={loadAllData}>
            🔄 রিফ্রেশ
          </button>
        </div>
      </div>
      
      <div className="users-table">
        <table>
          <thead>
            <tr>
              <th>আইডি</th>
              <th>নাম</th>
              <th>ইমেইল</th>
              <th>রোল</th>
              <th>ডকুমেন্ট</th>
              <th>ফেস</th>
              <th>স্ট্যাটাস</th>
              <th>অ্যাকশন</th>
            </tr>
          </thead>
          <tbody>
            {filteredUsers.map((user) => {
              const status = getUserStatus(user);
              
              return (
                <tr key={user.id} className={user.isBanned || user.isBlocked ? 'banned' : ''}>
                  <td><span className="user-id">{user.uniqueId || user.id?.slice(-8)}</span></td>
                  <td>
                    <div className="user-name">
                      {user.photoURL && <img src={user.photoURL} alt="" className="user-avatar" />}
                      <span>{user.displayName || `${user.firstName || ''} ${user.lastName || ''}` || 'N/A'}</span>
                    </div>
                  </td>
                  <td>{user.email}</td>
                  <td>
                    <span className={`role-badge ${user.role}`}>
                      {user.role === 'client' ? 'ক্লায়েন্ট' : 'ফ্রিল্যান্সার'}
                    </span>
                  </td>
                  <td>
                    <div className="doc-status">
                      {user.documents?.nidFront && <span className="doc-check">🪪</span>}
                      {user.documents?.nidBack && <span className="doc-check">🔄</span>}
                      {user.documents?.birthCert && <span className="doc-check">📄</span>}
                      {!user.documents?.nidFront && !user.documents?.birthCert && 
                        <span className="doc-missing">❌</span>
                      }
                    </div>
                  </td>
                  <td>
                    {user.facePhotoUrl ? '✅' : '❌'}
                  </td>
                  <td>
                    <span className={`status-badge ${status.className}`}>
                      {status.label}
                    </span>
                  </td>
                  <td>
                    <div className="action-buttons">
                      <button 
                        className="action-btn view" 
                        onClick={() => setSelectedUser(user)}
                        title="বিস্তারিত দেখুন"
                      >
                        👁️
                      </button>
                      
                      {/* ✅ যাচাই বাকি বা প্রক্রিয়াধীন ইউজারদের জন্য Verify বাটন */}
                      {(status.className === 'pending_verification' || status.className === 'pending' || status.className === 'incomplete') && !user.isBanned && !user.isBlocked && (
                        <button 
                          className="action-btn verify" 
                          onClick={() => verifyUser(user.id, true)}
                          title="যাচাই করুন"
                        >
                          ✅
                        </button>
                      )}
                      
                      {/* ✅ যাচাইকৃত ইউজারদের জন্য Unverify বাটন */}
                      {status.className === 'verified' && !user.isBanned && !user.isBlocked && (
                        <button 
                          className="action-btn unverify" 
                          onClick={() => verifyUser(user.id, false)}
                          title="যাচাই বাতিল করুন"
                        >
                          ❌
                        </button>
                      )}
                      
                      <button 
                        className={`action-btn ${user.isBanned || user.isBlocked ? 'unblock' : 'block'}`} 
                        onClick={() => toggleBlockUser(user.id, !(user.isBanned || user.isBlocked))}
                        title={user.isBanned || user.isBlocked ? 'আনব্লক করুন' : 'ব্লক করুন'}
                      >
                        {user.isBanned || user.isBlocked ? '🔓' : '🔒'}
                      </button>
                      <button 
                        className="action-btn delete" 
                        onClick={() => deleteUser(user.id)}
                        title="ডিলিট করুন"
                      >
                        🗑️
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

  const renderPosts = () => (
    <div className="data-table">
      <div className="table-header">
        <h3>📄 পোস্ট সমূহ</h3>
        <span className="table-count">{posts.length} টি পোস্ট</span>
      </div>
      <table>
        <thead>
          <tr>
            <th>আইডি</th>
            <th>শিরোনাম</th>
            <th>ধরন</th>
            <th>বাজেট</th>
            <th>পোস্ট করেছেন</th>
            <th>তারিখ</th>
            <th>অ্যাকশন</th>
          </tr>
        </thead>
        <tbody>
          {posts.map(post => (
            <tr key={post.id}>
              <td>{post.id?.slice(-8)}</td>
              <td>{post.title?.substring(0, 40)}...</td>
              <td>
                <span className={`type-badge ${post.type || 'service'}`}>
                  {post.type === 'hire' ? '💼 চাকরি' : '🛠️ সার্ভিস'}
                </span>
              </td>
              <td>{formatMoney(post.budget || post.price)}</td>
              <td>{post.clientName || post.userName || 'অজানা'}</td>
              <td>{formatDate(post.createdAt)}</td>
              <td>
                <button 
                  className="action-btn delete"
                  onClick={() => handleDeletePost(post.id)}
                >
                  🗑️
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );

  const renderDeals = () => (
    <div className="data-table">
      <div className="table-header">
        <h3>🤝 ডিল সমূহ</h3>
        <span className="table-count">{deals.length} টি ডিল</span>
      </div>
      <table>
        <thead>
          <tr>
            <th>ডিল আইডি</th>
            <th>প্রজেক্ট</th>
            <th>বাজেট</th>
            <th>স্ট্যাটাস</th>
            <th>তারিখ</th>
          </tr>
        </thead>
        <tbody>
          {deals.map(deal => (
            <tr key={deal.id}>
              <td>
                <span className="deal-id-tag">
                  #{deal.dealIdNumber || deal.id?.slice(-8)}
                </span>
              </td>
              <td>{deal.postTitle?.substring(0, 40)}...</td>
              <td>{formatMoney(deal.budget)}</td>
              <td>
                <span className={`status-badge ${getStatusBadge(deal.status)}`}>
                  {deal.status || 'প্রক্রিয়াধীন'}
                </span>
              </td>
              <td>{formatDate(deal.createdAt)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );

  const renderWithdrawals = () => (
    <div className="data-table">
      <div className="table-header">
        <h3>💳 উইথড্র রিকোয়েস্ট</h3>
        <span className="table-count">{withdrawals.length} টি রিকোয়েস্ট</span>
      </div>
      <table>
        <thead>
          <tr>
            <th>আইডি</th>
            <th>পরিমাণ</th>
            <th>পদ্ধতি</th>
            <th>মোবাইল</th>
            <th>স্ট্যাটাস</th>
            <th>অ্যাকশন</th>
          </tr>
        </thead>
        <tbody>
          {withdrawals.map(withdrawal => (
            <tr key={withdrawal.id}>
              <td>{withdrawal.id?.slice(-8)}</td>
              <td>{formatMoney(withdrawal.amount)}</td>
              <td>{withdrawal.paymentMethod || 'ব্যাংক'}</td>
              <td>{withdrawal.mobileNumber || withdrawal.bankAccount}</td>
              <td>
                <span className={`status-badge ${getStatusBadge(withdrawal.status)}`}>
                  {withdrawal.status === 'pending' && '⏳ অপেক্ষমান'}
                  {withdrawal.status === 'processing' && '🔄 প্রক্রিয়াধীন'}
                  {withdrawal.status === 'completed' && '✅ সম্পন্ন'}
                  {withdrawal.status === 'rejected' && '❌ প্রত্যাখ্যাত'}
                </span>
              </td>
              <td>
                {withdrawal.status === 'pending' && (
                  <>
                    <button 
                      className="action-btn approve"
                      onClick={() => handleApproveWithdrawal(withdrawal.id, withdrawal.userId, withdrawal.amount)}
                    >
                      ✅
                    </button>
                    <button 
                      className="action-btn reject"
                      onClick={() => handleRejectWithdrawal(withdrawal.id, withdrawal.userId, withdrawal.amount)}
                    >
                      ❌
                    </button>
                  </>
                )}
                {withdrawal.status === 'processing' && (
                  <button 
                    className="action-btn complete"
                    onClick={() => handleCompleteWithdrawal(withdrawal.id, withdrawal.userId, withdrawal.amount)}
                  >
                    ✅ সম্পন্ন
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );

  const renderNotifications = () => (
    <div className="admin-notifications">
      <h3>📨 নোটিফিকেশন পাঠান</h3>
      
      <div className="notification-form">
        <div className="form-group">
          <label>নোটিফিকেশন টাইপ</label>
          <select 
            value={notificationType} 
            onChange={(e) => setNotificationType(e.target.value)}
          >
            <option value="info">ℹ️ তথ্য</option>
            <option value="success">✅ সফল</option>
            <option value="warning">⚠️ সতর্কতা</option>
            <option value="error">❌ ত্রুটি</option>
          </select>
        </div>
        
        <div className="form-group">
          <label>মেসেজ</label>
          <textarea 
            value={notificationMessage}
            onChange={(e) => setNotificationMessage(e.target.value)}
            placeholder="নোটিফিকেশন মেসেজ লিখুন..."
            rows="4"
          />
        </div>
        
        <div className="form-group">
          <label>প্রাপক নির্বাচন করুন</label>
          <div className="recipient-select">
            <div className="select-all">
              <label>
                <input 
                  type="checkbox" 
                  checked={selectedUsersForNotify.length === filteredUsers.length && filteredUsers.length > 0}
                  onChange={toggleSelectAllUsers}
                />
                সব নির্বাচন করুন ({filteredUsers.length})
              </label>
            </div>
            <div className="user-list">
              {filteredUsers.map((user) => (
                <label key={user.id} className="user-check">
                  <input 
                    type="checkbox" 
                    checked={selectedUsersForNotify.includes(user.id)}
                    onChange={() => toggleUserSelection(user.id)}
                  />
                  <span>{user.displayName || user.email}</span>
                </label>
              ))}
            </div>
          </div>
        </div>
        
        <button 
          className="btn btn-primary" 
          onClick={sendBulkNotification}
          disabled={sendingNotification || !notificationMessage.trim()}
        >
          {sendingNotification ? '⏳ পাঠানো হচ্ছে...' : '📨 নোটিফিকেশন পাঠান'}
        </button>
      </div>
      
      <div className="sent-notifications">
        <h4>পাঠানো নোটিফিকেশন</h4>
        <div className="notification-list">
          {notifications.map((notif) => (
            <div key={notif.id} className={`notification-item ${notif.type}`}>
              <div className="notif-message">{notif.message}</div>
              <div className="notif-meta">
                <span>{notif.recipientCount || 0} জন</span>
                <span>{formatDate(notif.createdAt)}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  // ============================================================
  // ✅ ইউজার ডিটেইল মোডাল
  // ============================================================
  const renderUserDetailModal = () => {
    if (!selectedUser) return null;
    
    const user = selectedUser;
    
    return (
      <div className="modal-overlay" onClick={() => setSelectedUser(null)}>
        <div className="modal-content" onClick={(e) => e.stopPropagation()}>
          <div className="modal-header">
            <h3>👤 ইউজার বিস্তারিত</h3>
            <button className="close-btn" onClick={() => setSelectedUser(null)}>✕</button>
          </div>
          
          <div className="modal-body">
            <div className="user-detail-row">
              <div className="detail-label">আইডি:</div>
              <div className="detail-value">{user.uniqueId || user.id?.slice(-8)}</div>
            </div>
            <div className="user-detail-row">
              <div className="detail-label">নাম:</div>
              <div className="detail-value">{user.displayName || `${user.firstName || ''} ${user.lastName || ''}` || 'N/A'}</div>
            </div>
            <div className="user-detail-row">
              <div className="detail-label">ইমেইল:</div>
              <div className="detail-value">{user.email}</div>
            </div>
            <div className="user-detail-row">
              <div className="detail-label">ফোন:</div>
              <div className="detail-value">{user.phone || 'N/A'}</div>
            </div>
            <div className="user-detail-row">
              <div className="detail-label">জন্ম তারিখ:</div>
              <div className="detail-value">{user.dob || 'N/A'}</div>
            </div>
            <div className="user-detail-row">
              <div className="detail-label">ঠিকানা:</div>
              <div className="detail-value">{user.address || 'N/A'}</div>
            </div>
            <div className="user-detail-row">
              <div className="detail-label">রোল:</div>
              <div className="detail-value">
                <span className={`role-badge ${user.role}`}>
                  {user.role === 'client' ? 'ক্লায়েন্ট' : 'ফ্রিল্যান্সার'}
                </span>
              </div>
            </div>
            <div className="user-detail-row">
              <div className="detail-label">যাচাই:</div>
              <div className="detail-value">
                {user.isVerified || user.isComplete ? '✅ যাচাইকৃত' : '⏳ যাচাই বাকি'}
              </div>
            </div>
            <div className="user-detail-row">
              <div className="detail-label">স্ট্যাটাস:</div>
              <div className="detail-value">
                {user.isBanned || user.isBlocked ? '🚫 ব্লককৃত' : '✅ সক্রিয়'}
              </div>
            </div>
            
<div className="user-detail-section">
  <h4>📄 ডকুমেন্ট</h4>
  <div className="documents-grid">
    {user.documents?.nidFront && (
      <div className="doc-item">
        <img 
          src={user.documents.nidFront.url} 
          alt="NID Front" 
          onError={(e) => {
            e.target.src = 'https://via.placeholder.com/150x100?text=No+Image';
          }}
        />
        <span>🪪 NID সামনে</span>
      </div>
    )}
    {user.documents?.nidBack && (
      <div className="doc-item">
        <img 
          src={user.documents.nidBack.url} 
          alt="NID Back"
          onError={(e) => {
            e.target.src = 'https://via.placeholder.com/150x100?text=No+Image';
          }}
        />
        <span>🔄 NID পিছনে</span>
      </div>
    )}
    {user.documents?.birthCert && (
      <div className="doc-item">
        <img 
          src={user.documents.birthCert.url} 
          alt="Birth Certificate"
          onError={(e) => {
            e.target.src = 'https://via.placeholder.com/150x100?text=No+Image';
          }}
        />
        <span>📄 জন্ম নিবন্ধন</span>
      </div>
    )}
    {!user.documents?.nidFront && !user.documents?.birthCert && (
      <p style={{ color: 'var(--text-mid)' }}>
        {user.documentsUploaded ? '⏳ ডকুমেন্ট পর্যালোচনাধীন' : '❌ কোন ডকুমেন্ট আপলোড করা হয়নি'}
      </p>
    )}
  </div>
</div>
            
            {user.facePhotoUrl && (
              <div className="user-detail-section">
                <h4>📸 ফেস ফটো</h4>
                <img src={user.facePhotoUrl} alt="Face" className="face-photo" />
              </div>
            )}
            
            <div className="user-detail-section">
              <h4>📊 পরিসংখ্যান</h4>
              <div className="status-grid">
                <div className={`status-item ${user.isVerified || user.isComplete ? 'success' : 'pending'}`}>
                  {user.isVerified || user.isComplete ? '✅ যাচাইকৃত' : '⏳ যাচাই বাকি'}
                </div>
                <div className={`status-item ${user.isBanned || user.isBlocked ? 'error' : 'success'}`}>
                  {user.isBanned || user.isBlocked ? '🚫 ব্লককৃত' : '✅ সক্রিয়'}
                </div>
                <div className="status-item info">
                  📅 {formatDate(user.createdAt)}
                </div>
              </div>
            </div>
          </div>
          
          <div className="modal-footer">
            <button className="btn btn-secondary" onClick={() => setSelectedUser(null)}>বন্ধ করুন</button>
            {!user.isVerified && !user.isBanned && !user.isBlocked && (
              <button className="btn btn-success" onClick={() => verifyUser(user.id, true)}>
                ✅ যাচাই করুন
              </button>
            )}
            <button 
              className={`btn ${user.isBanned || user.isBlocked ? 'btn-success' : 'btn-danger'}`}
              onClick={() => toggleBlockUser(user.id, !(user.isBanned || user.isBlocked))}
            >
              {user.isBanned || user.isBlocked ? '🔓 আনব্লক করুন' : '🔒 ব্লক করুন'}
            </button>
          </div>
        </div>
      </div>
    );
  };

  // ============================================================
  // ✅ লোডিং স্টেট
  // ============================================================
  if (loading) {
    return (
      <div className="admin-loading">
        <div className="loading-spinner">⏳ লোড হচ্ছে...</div>
      </div>
    );
  }

  // ============================================================
  // ✅ মেইন রেন্ডার
  // ============================================================
  return (
    <div className="admin-container">
      <Toaster position="top-center" />
      
      <div className="admin-wrapper">
        
        {/* ── হেডার ── */}
        <div className="admin-header">
          <h1><i className="fa-solid fa-shield-haltered"></i> অ্যাডমিন ড্যাশবোর্ড</h1>
          <div className="header-actions">
            <div className="search-bar-container">
  <input
    type="text"
    className="search-input"
    placeholder="🔍 আইডি, নাম, ইমেইল, ফোন দিয়ে খুঁজুন..."
    value={searchQuery}
    onChange={(e) => handleGlobalSearch(e.target.value)}
  />
  {isSearching && (
    <span className="search-loading">
      <i className="fa-solid fa-spinner fa-spin"></i>
    </span>
  )}
  {searchQuery && searchResults.length === 0 && !isSearching && (
    <span className="search-no-result">
      <i className="fa-solid fa-search"></i> কোন ফলাফল পাওয়া যায়নি
    </span>
  )}
  {searchQuery && searchResults.length > 0 && (
    <span className="search-result-count">
      {searchResults.length} টি ফলাফল
    </span>
  )}
</div>
            <button className="back-btn" onClick={() => navigate('/')}>
              <i className="fa-solid fa-home"></i> হোম
            </button>
            <button className="refresh-btn" onClick={loadAllData}>
              <i className="fa-solid fa-sync"></i>
            </button>
          </div>
        </div>

        {/* ── সার্চ রেজাল্ট ── */}
{searchResults.length > 0 && (
  <div className="search-results-dropdown">
    <div className="search-results-header">
      <span>পাওয়া গেছে {searchResults.length} টি ফলাফল</span>
      <button className="clear-search" onClick={() => {
        setSearchQuery('');
        setSearchResults([]);
      }}>
        <i className="fa-solid fa-times"></i>
      </button>
    </div>
    {searchResults.map((item, index) => (
      <div 
        key={`${item.type}-${item.id}-${index}`}
        className="search-result-item"
        onClick={() => {
          // ✅ ট্যাব পরিবর্তন
          if (item.type === 'user') {
            setActiveTab('users');
            // ✅ ইউজার ফিল্টার সেট করুন যাতে সার্চ করা ইউজার দেখা যায়
            setSearchTerm(item.displayName || item.email || '');
          } else if (item.type === 'post') {
            setActiveTab('posts');
          } else if (item.type === 'deal') {
            setActiveTab('deals');
          } else if (item.type === 'withdrawal') {
            setActiveTab('withdrawals');
          }
          // ✅ সার্চ ক্লিয়ার
          setSearchQuery('');
          setSearchResults([]);
        }}
      >
        <div className="result-icon">
          {item.type === 'user' && <i className="fa-solid fa-user"></i>}
          {item.type === 'post' && <i className="fa-solid fa-file-alt"></i>}
          {item.type === 'deal' && <i className="fa-solid fa-handshake"></i>}
          {item.type === 'withdrawal' && <i className="fa-solid fa-money-bill-transfer"></i>}
        </div>
        <div className="result-info">
          <h4>
            {item.displayTitle || item.displayName || 'Unnamed'}
            <span className={`result-type-badge ${item.type}`}>
              {item.type === 'user' && '👤 ইউজার'}
              {item.type === 'post' && '📄 পোস্ট'}
              {item.type === 'deal' && '🤝 ডিল'}
              {item.type === 'withdrawal' && '💳 উইথড্র'}
            </span>
          </h4>
          <p>
            {item.email && `📧 ${item.email}`}
            {item.uniqueId && ` | 🆔 ${item.uniqueId}`}
            {item.budget && ` | 💰 ${formatMoney(item.budget)}`}
            {item.amount && ` | 💰 ${formatMoney(item.amount)}`}
            {item.phone && ` | 📱 ${item.phone}`}
          </p>
          <small className="result-meta">
            {item.type === 'user' && `রোল: ${item.role === 'client' ? 'ক্লায়েন্ট' : 'ফ্রিল্যান্সার'}`}
            {item.type === 'post' && `তারিখ: ${formatDate(item.createdAt)}`}
            {item.type === 'deal' && `স্ট্যাটাস: ${item.status || 'প্রক্রিয়াধীন'}`}
            {item.type === 'withdrawal' && `স্ট্যাটাস: ${item.status || 'পেন্ডিং'}`}
          </small>
        </div>
      </div>
    ))}
  </div>
)}

        {/* ── ট্যাব নেভিগেশন ── */}
        <div className="admin-tabs">
          <button 
            className={`tab-btn ${activeTab === 'dashboard' ? 'active' : ''}`}
            onClick={() => setActiveTab('dashboard')}
          >
            <i className="fa-solid fa-chart-line"></i> ওভারভিউ
          </button>
          <button 
            className={`tab-btn ${activeTab === 'users' ? 'active' : ''}`}
            onClick={() => setActiveTab('users')}
          >
            <i className="fa-solid fa-users"></i> ইউজার ({users.length})
          </button>
          <button 
            className={`tab-btn ${activeTab === 'posts' ? 'active' : ''}`}
            onClick={() => setActiveTab('posts')}
          >
            <i className="fa-solid fa-file-alt"></i> পোস্ট ({posts.length})
          </button>
          <button 
            className={`tab-btn ${activeTab === 'deals' ? 'active' : ''}`}
            onClick={() => setActiveTab('deals')}
          >
            <i className="fa-solid fa-handshake"></i> ডিল ({deals.length})
          </button>
          <button 
            className={`tab-btn ${activeTab === 'withdrawals' ? 'active' : ''}`}
            onClick={() => setActiveTab('withdrawals')}
          >
            <i className="fa-solid fa-money-bill-transfer"></i> উইথড্র ({withdrawals.length})
          </button>
          <button 
            className={`tab-btn ${activeTab === 'notifications' ? 'active' : ''}`}
            onClick={() => setActiveTab('notifications')}
          >
            <i className="fa-solid fa-bell"></i> নোটিফিকেশন
          </button>
        </div>

        {/* ── ট্যাব কন্টেন্ট ── */}
        <div className="admin-content">
          {activeTab === 'dashboard' && renderDashboard()}
          {activeTab === 'users' && renderUsers()}
          {activeTab === 'posts' && renderPosts()}
          {activeTab === 'deals' && renderDeals()}
          {activeTab === 'withdrawals' && renderWithdrawals()}
          {activeTab === 'notifications' && renderNotifications()}
        </div>

      </div>
      
      {renderUserDetailModal()}
    </div>
  );
};

export default AdminDashboard;