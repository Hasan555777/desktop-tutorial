// src/pages/Referral.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth, db } from '../firebase';
import { doc, getDoc, updateDoc, increment, collection, query, where, getDocs } from 'firebase/firestore';
import './Referral.css';

const Referral = () => {
  const navigate = useNavigate();
  const user = auth.currentUser;
  
  const [loading, setLoading] = useState(true);
  const [referralCode, setReferralCode] = useState('');
  const [stats, setStats] = useState({
    totalReferrals: 0,
    totalEarned: 0,
    pendingBonus: 0
  });
  const [referrals, setReferrals] = useState([]);
  const [copied, setCopied] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  // ============================================================
  // ✅ রেফারেল কোড জেনারেট
  // ============================================================
  const generateReferralCode = (email) => {
    const prefix = email?.split('@')[0]?.slice(0, 4) || 'USER';
    const random = Math.random().toString(36).substring(2, 7).toUpperCase();
    return `${prefix}${random}`;
  };

  // ============================================================
  // ✅ রেফারেল ডেটা লোড
  // ============================================================
  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    const loadReferralData = async () => {
      try {
        const userRef = doc(db, 'users', user.uid);
        const userSnap = await getDoc(userRef);
        
        if (userSnap.exists()) {
          const data = userSnap.data();
          
          // রেফারেল কোড সেট করুন (যদি না থাকে)
          let code = data.referralCode;
          if (!code) {
            code = generateReferralCode(user.email);
            await updateDoc(userRef, { 
              referralCode: code,
              referralCount: 0,
              referralEarned: 0
            });
          }
          setReferralCode(code);
          
          // স্ট্যাটাস লোড
          setStats({
            totalReferrals: data.referralCount || 0,
            totalEarned: data.referralEarned || 0,
            pendingBonus: data.pendingBonus || 0
          });
          
          // রেফারেল লিস্ট লোড
          await loadReferrals();
        }
      } catch (error) {
        console.error("Error loading referral data:", error);
      } finally {
        setLoading(false);
      }
    };

    loadReferralData();
  }, [user, navigate]);

  // ============================================================
  // ✅ রেফারেল লিস্ট লোড
  // ============================================================
  const loadReferrals = async () => {
    try {
      const q = query(
        collection(db, 'users'),
        where('referredBy', '==', user.uid)
      );
      const snapshot = await getDocs(q);
      const referralList = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setReferrals(referralList);
    } catch (error) {
      console.error("Error loading referrals:", error);
    }
  };

  // ============================================================
  // ✅ কোড কপি
  // ============================================================
  const copyCode = () => {
    navigator.clipboard.writeText(referralCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // ============================================================
  // ✅ লিংক কপি
  // ============================================================
  const copyLink = () => {
    const link = `${window.location.origin}/register?ref=${referralCode}`;
    navigator.clipboard.writeText(link);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  // ============================================================
  // ✅ শেয়ার ফাংশন
  // ============================================================
  const shareReferral = async () => {
    const shareData = {
      title: 'Join WorkHub and earn!',
      text: `Use my referral code ${referralCode} to get ৳50 bonus on signup!`,
      url: `${window.location.origin}/register?ref=${referralCode}`
    };

    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        copyLink();
      }
    } catch (error) {
      console.error("Share error:", error);
    }
  };

  // ============================================================
  // ✅ ফরম্যাট টাকা
  // ============================================================
  const formatMoney = (amount) => {
    return new Intl.NumberFormat('bn-BD', {
      style: 'currency',
      currency: 'BDT',
      minimumFractionDigits: 0
    }).format(amount || 0);
  };

  // ============================================================
  // ✅ লোডিং স্টেট
  // ============================================================
  if (loading) {
    return (
      <div className="referral-loading">
        <div className="loading-spinner"></div>
        <p>Loading referral data...</p>
      </div>
    );
  }

  // ============================================================
  // ✅ রেন্ডার
  // ============================================================
  return (
    <div className="referral-container">
      <div className="referral-card">
        
        {/* হেডার */}
        <div className="referral-header">
          <button className="back-btn" onClick={() => navigate(-1)}>
            <i className="fa-solid fa-arrow-left"></i> Back
          </button>
          <h2>
            <i className="fa-solid fa-user-plus" style={{ color: '#fbbf24' }}></i> 
            Refer & Earn
          </h2>
        </div>

        <p className="referral-subtitle">
          Invite friends and earn bonuses together!
        </p>

        {/* স্ট্যাটাস */}
        <div className="referral-stats">
          <div className="stat-item">
            <span className="stat-label">Total Referrals</span>
            <strong className="stat-value">{stats.totalReferrals}</strong>
          </div>
          <div className="stat-divider"></div>
          <div className="stat-item">
            <span className="stat-label">Total Earned</span>
            <strong className="stat-value">{formatMoney(stats.totalEarned)}</strong>
          </div>
          <div className="stat-divider"></div>
          <div className="stat-item">
            <span className="stat-label">Pending Bonus</span>
            <strong className="stat-value">{formatMoney(stats.pendingBonus)}</strong>
          </div>
        </div>

        {/* রেফারেল কোড */}
        <div className="referral-code-section">
          <p className="section-label">
            <i className="fa-solid fa-key"></i> Your Referral Code
          </p>
          <div className="code-box">
            <span className="code-text">{referralCode}</span>
            <button className="copy-btn" onClick={copyCode}>
              {copied ? (
                <>
                  <i className="fa-solid fa-check"></i> Copied!
                </>
              ) : (
                <>
                  <i className="fa-regular fa-copy"></i> Copy
                </>
              )}
            </button>
          </div>
        </div>

        {/* রেফারেল লিংক */}
        <div className="referral-link-section">
          <p className="section-label">
            <i className="fa-solid fa-link"></i> Referral Link
          </p>
          <div className="link-box">
            <span className="link-text">
              {window.location.origin}/register?ref={referralCode}
            </span>
            <button className="copy-btn" onClick={copyLink}>
              {copiedLink ? (
                <>
                  <i className="fa-solid fa-check"></i> Copied!
                </>
              ) : (
                <>
                  <i className="fa-regular fa-copy"></i> Copy
                </>
              )}
            </button>
          </div>
        </div>

        {/* শেয়ার বাটন */}
        <button className="share-btn" onClick={shareReferral}>
          <i className="fa-solid fa-share-nodes"></i> Share with Friends
        </button>

        {/* ইনফো */}
        <div className="referral-info">
          <h4>
            <i className="fa-solid fa-circle-info"></i> How it works?
          </h4>
          <ul>
            <li>
              <i className="fa-solid fa-share"></i>
              Share your referral code with friends
            </li>
            <li>
              <i className="fa-solid fa-user-check"></i>
              They sign up using your code
            </li>
            <li>
              <i className="fa-solid fa-gift"></i>
              You get <strong>৳100</strong> bonus on their first deposit
            </li>
            <li>
              <i className="fa-solid fa-star"></i>
              They get <strong>৳50</strong> welcome bonus
            </li>
          </ul>
        </div>

        {/* রেফারেল লিস্ট (যদি থাকে) */}
        {referrals.length > 0 && (
          <div className="referral-list-section">
            <h4>
              <i className="fa-solid fa-users"></i> Your Referrals ({referrals.length})
            </h4>
            <div className="referral-list">
              {referrals.map((ref) => (
                <div key={ref.id} className="referral-item">
                  <div className="ref-avatar">
                    <i className="fa-solid fa-user"></i>
                  </div>
                  <div className="ref-info">
                    <span className="ref-name">{ref.displayName || 'User'}</span>
                    <span className="ref-date">
                      {ref.createdAt?.toDate?.()?.toLocaleDateString() || 'Recently'}
                    </span>
                  </div>
                  <span className="ref-status completed">
                    <i className="fa-solid fa-check-circle"></i> Active
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ফুটার */}
        <div className="referral-footer">
          <p>
            <i className="fa-solid fa-shield-check"></i> 
            Terms and conditions apply
          </p>
        </div>

      </div>
    </div>
  );
};

export default Referral;