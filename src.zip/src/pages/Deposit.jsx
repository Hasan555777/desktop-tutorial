// src/pages/Deposit.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth, db } from '../firebase';
import { doc, addDoc, collection, serverTimestamp } from 'firebase/firestore';
import './Deposit.css';

const Deposit = () => {
  const navigate = useNavigate();
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState('bKash');
  const [trxId, setTrxId] = useState('');
  const [senderNumber, setSenderNumber] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [status, setStatus] = useState('');

  const SERVER_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000';

  // ============================================================
  // ✅ ডিপোজিট হ্যান্ডলার (Two-Way Verification)
  // ============================================================
  const handleDeposit = async () => {
    // ভ্যালিডেশন
    if (!amount || Number(amount) < 100) {
      setError('Minimum deposit amount is 100 BDT');
      return;
    }

    if (Number(amount) > 50000) {
      setError('Maximum deposit amount is 50,000 BDT');
      return;
    }

    if (!trxId || trxId.trim().length < 10) {
      setError('Please enter a valid Transaction ID (minimum 10 characters)');
      return;
    }

    if (!senderNumber || senderNumber.trim().length < 11) {
      setError('Please enter a valid sender number');
      return;
    }

    if (!auth.currentUser) {
      setError('Please login first!');
      navigate('/login');
      return;
    }

    setLoading(true);
    setError('');
    setStatus('Submitting deposit request...');

    try {
      const userId = auth.currentUser.uid;
      const amountNum = Number(amount);
      const trxIdTrim = trxId.trim();
      const senderTrim = senderNumber.trim();

      // ১. Firestore এ ট্রানজেকশন সেভ করুন
      const transactionData = {
        userId: userId,
        userEmail: auth.currentUser.email,
        userName: auth.currentUser.displayName || 'User',
        amount: amountNum,
        method: method,
        trxId: trxIdTrim,
        senderNumber: senderTrim,
        status: 'pending',
        type: 'deposit',
        source: 'form',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };

      const docRef = await addDoc(collection(db, 'transactions'), transactionData);
      console.log('✅ Transaction saved with ID:', docRef.id);

      // ২. সার্ভারে পাঠান (Two-Way Verification)
      setStatus('Verifying payment with server...');
      
      try {
        const response = await fetch(`${SERVER_URL}/api/submit-payment`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId: userId,
            trxId: trxIdTrim,
            amount: amountNum,
            senderNumber: senderTrim,
            method: method
          })
        });

        const data = await response.json();
        console.log('📡 Server response:', data);

        if (data.success) {
          setStatus('✅ Payment submitted for verification!');
        } else {
          console.warn('⚠️ Server warning:', data.message);
        }
      } catch (serverError) {
        // সার্ভার অফলাইন থাকলেও ইউজারকে থামানো যাবে না
        console.warn('⚠️ Server not available, but transaction saved locally:', serverError);
        setStatus('✅ Transaction saved locally. Will be verified later.');
      }

      // ৩. ইউজারকে নোটিফিকেশন দিন
      alert(`✅ Deposit request submitted!\n\nAmount: ৳${amountNum}\nMethod: ${method}\nTransaction ID: ${trxIdTrim}\n\nPlease wait 5-10 minutes for verification.`);

      // ৪. ওয়ালেট পেজে রিডাইরেক্ট
      navigate('/wallet');

    } catch (error) {
      console.error('❌ Deposit error:', error);
      setError('Failed to submit deposit: ' + error.message);
      setStatus('❌ Submission failed');
    } finally {
      setLoading(false);
    }
  };

  // ============================================================
  // ✅ প্রি-সেট অ্যামাউন্ট
  // ============================================================
  const presetAmounts = [100, 200, 500, 1000, 2000, 5000];

  return (
    <div className="deposit-container">
      <div className="deposit-card">
        
        {/* Back Button */}
        <button className="back-btn" onClick={() => navigate(-1)}>
          <i className="fa-solid fa-arrow-left"></i> Back
        </button>

        {/* Header */}
        <div className="deposit-header">
          <h2><i className="fa-solid fa-circle-dollar"></i> Deposit Money</h2>
          <p>Add funds to your wallet</p>
        </div>

        {/* Status Message */}
        {status && (
          <div className={`status-message ${loading ? 'processing' : 'success'}`}>
            <i className={`fa-solid ${loading ? 'fa-spinner fa-spin' : 'fa-check-circle'}`}></i>
            {status}
          </div>
        )}

        {/* Error Message */}
        {error && (
          <div className="error-message">
            <i className="fa-solid fa-exclamation-circle"></i> {error}
          </div>
        )}

        {/* Amount Presets */}
        <div className="amount-presets">
          <label>Quick Amount</label>
          <div className="preset-buttons">
            {presetAmounts.map((preset) => (
              <button
                key={preset}
                className={`preset-btn ${Number(amount) === preset ? 'active' : ''}`}
                onClick={() => setAmount(String(preset))}
              >
                ৳{preset}
              </button>
            ))}
          </div>
        </div>

        {/* Amount Input */}
        <div className="input-group">
          <label>
            <i className="fa-solid fa-wallet"></i> Amount (BDT)
          </label>
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="Enter amount (min: 100 BDT)"
            min="100"
            max="50000"
          />
          <span className="input-hint">Minimum 100 BDT • Maximum 50,000 BDT</span>
        </div>

        {/* Sender Number */}
        <div className="input-group">
          <label>
            <i className="fa-solid fa-phone"></i> Sender Number
          </label>
          <input
            type="tel"
            value={senderNumber}
            onChange={(e) => setSenderNumber(e.target.value)}
            placeholder="Enter your bKash/Nagad number"
          />
          <span className="input-hint">The number you sent money from</span>
        </div>

        {/* Transaction ID */}
        <div className="input-group">
          <label>
            <i className="fa-solid fa-receipt"></i> Transaction ID (TrxID)
          </label>
          <input
            type="text"
            value={trxId}
            onChange={(e) => setTrxId(e.target.value)}
            placeholder="Enter transaction ID from bKash/Nagad"
          />
          <span className="input-hint">
            <i className="fa-solid fa-info-circle"></i> 
            Find TrxID in your bKash/Nagad app transaction history
          </span>
        </div>

        {/* Payment Method */}
        <div className="input-group">
          <label>
            <i className="fa-solid fa-credit-card"></i> Payment Method
          </label>
          <div className="method-options">
            {['bKash', 'Nagad', 'Rocket'].map((m) => (
              <label key={m} className={`method-label ${method === m ? 'active' : ''}`}>
                <input
                  type="radio"
                  value={m}
                  checked={method === m}
                  onChange={(e) => setMethod(e.target.value)}
                />
                {m === 'bKash' && <i className="fa-brands fa-btc"></i>}
                {m === 'Nagad' && <i className="fa-solid fa-n"></i>}
                {m === 'Rocket' && <i className="fa-solid fa-rocket"></i>}
                {m}
              </label>
            ))}
          </div>
        </div>

        {/* Payment Instructions */}
        <div className="payment-instructions">
          <h4><i className="fa-solid fa-info-circle"></i> How to deposit:</h4>
          <ol>
            <li>Send money to this number: <strong>018XXXXXXXX</strong></li>
            <li>Copy the <strong>Transaction ID (TrxID)</strong> from your app</li>
            <li>Paste the TrxID in the field above</li>
            <li>Click <strong>"Submit Deposit Request"</strong></li>
            <li>Wait 5-10 minutes for verification</li>
          </ol>
        </div>

        {/* Submit Button */}
        <button
          className={`deposit-btn ${loading ? 'loading' : ''}`}
          onClick={handleDeposit}
          disabled={loading}
        >
          {loading ? (
            <>
              <i className="fa-solid fa-spinner fa-spin"></i> Submitting...
            </>
          ) : (
            <>
              <i className="fa-solid fa-paper-plane"></i> Submit Deposit Request
            </>
          )}
        </button>

        {/* Footer */}
        <div className="deposit-footer">
          <p>
            <i className="fa-solid fa-shield-check"></i> 
            Your transaction is secure and encrypted
          </p>
        </div>

      </div>
    </div>
  );
};

export default Deposit;