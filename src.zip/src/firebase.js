import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyDE17xmN1l4kD-DPuNx3ls22I4T5prcWkc",
  authDomain: "upwork-clone-56910.firebaseapp.com",
  projectId: "upwork-clone-56910",
  storageBucket: "upwork-clone-56910.firebasestorage.app",
  messagingSenderId: "564891254913",
  appId: "1:564891254913:web:7b819cacf9b3269ead0d80"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);

export default app;