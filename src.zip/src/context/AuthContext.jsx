// src/context/AuthContext.jsx
import React, { createContext, useState, useContext, useEffect } from 'react';
import { 
  signInWithEmailAndPassword, 
  signInWithPopup, 
  signInWithRedirect,
  getRedirectResult,
  GoogleAuthProvider, 
  signOut, 
  sendPasswordResetEmail,
  onAuthStateChanged
} from 'firebase/auth';
import { 
  doc, 
  getDoc, 
  setDoc, 
  collection, 
  serverTimestamp,
  updateDoc,
  arrayUnion,
  arrayRemove,
  onSnapshot
} from 'firebase/firestore';
import { auth, db } from '../firebase';
import toast from 'react-hot-toast';

const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

// ============================================================
// ✅ ইউজার লেভেল ও এক্সেস কন্ট্রোল লজিক (ফিক্সড)
// ============================================================
const getAccessLevel = (userData) => {
  if (!userData) return { level: 0, label: 'Loading...' };
  
  // 🔥 1. ব্লক চেক
  if (userData.isBanned || userData.isBlocked) {
    return { level: 0, label: 'Blocked', isBlocked: true };
  }
  
  // 🔥 2. যাচাই প্রত্যাখ্যাত
  if (userData.verificationStatus === 'rejected' || userData.isRejected) {
    return { level: 4, label: 'Rejected', isRejected: true };
  }
  
  // 🔥 3. যাচাই প্রক্রিয়াধীন (ডকুমেন্ট জমা দিয়েছে কিন্তু যাচাই হয়নি)
  if (userData.verificationStatus === 'pending' && userData.isComplete === true) {
    return { level: 2, label: 'Pending', isPending: true, isComplete: true };
  }
  
  // 🔥 4. সম্পূর্ণ যাচাইকৃত (isVerified = true এবং isComplete = true)
  if (userData.isVerified === true && userData.isComplete === true) {
    return { level: 3, label: 'Verified', isVerified: true, isComplete: true };
  }
  
  // 🔥 5. প্রোফাইল সম্পন্ন কিন্তু যাচাই বাকি (নতুন ইউজার)
  if (userData.isComplete === true && userData.isVerified === false) {
    return { level: 1, label: 'Pending Verification', isPendingVerification: true, isComplete: true };
  }
  
  // 🔥 6. অসম্পূর্ণ প্রোফাইল (ডিফল্ট)
  return { level: 1, label: 'Incomplete', isIncomplete: true };
};

export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const [userData, setUserData] = useState(null);
  const [userRole, setUserRole] = useState(null);
  const [loading, setLoading] = useState(true);

  // ============================================================
  // ✅ ইউজার ডকুমেন্ট তৈরি/আপডেট হেলপার
  // ============================================================
  const ensureUserDocument = async (user) => {
    if (!user) return null;
    
    try {
      const userRef = doc(db, 'users', user.uid);
      const userSnap = await getDoc(userRef);
      
      if (userSnap.exists()) {
        await updateDoc(userRef, {
          isOnline: true,
          lastSeen: new Date().toISOString()
        });
        return userSnap.data();
      } else {
        // 🔥 নতুন ইউজার: সব ফিল্ড ডিফল্ট false
        const newUserData = {
          uid: user.uid,
          email: user.email || '',
          displayName: user.displayName || user.email?.split('@')[0] || 'User',
          photoURL: user.photoURL || null,
          role: 'client',
          createdAt: new Date().toISOString(),
          isOnline: true,
          lastSeen: new Date().toISOString(),
          savedPosts: [],
          totalReviews: 0,
          totalRating: 0,
          averageRating: 0,
          // 🔥 গুরুত্বপূর্ণ ফিল্ড (সব false)
          isComplete: false,
          isVerified: false,           // 🔥 সবসময় false (এডমিন যাচাই করবে)
          verificationStatus: 'incomplete', // 🔥 'incomplete', 'pending', 'verified', 'rejected'
          isBanned: false,
          isBlocked: false,
          documentsUploaded: false,
          faceVerified: false,
          verificationMethod: null,
          documentVerified: false,
          completionScore: 0
        };
        await setDoc(userRef, newUserData);
        return newUserData;
      }
    } catch (error) {
      console.error("Error ensuring user document:", error);
      return null;
    }
  };

  // ============================================================
  // ✅ ইউজার ডাটা লোড (রিয়েল-টাইম - ফিক্সড)
  // ============================================================
  const loadUserData = async (uid) => {
    if (!uid) return null;
    
    try {
      const userRef = doc(db, 'users', uid);
      const userSnap = await getDoc(userRef);
      
      if (!userSnap.exists()) {
        console.warn("⚠️ User document not found for uid:", uid);
        
        // 🔥 যদি currentUser থাকে কিন্তু ডকুমেন্ট না থাকে, তাহলে তৈরি করুন
        if (currentUser && currentUser.uid === uid) {
          console.log("🔄 Creating missing user document...");
          const newData = await ensureUserDocument(currentUser);
          if (newData) {
            setUserData(newData);
            setUserRole(newData.role || 'client');
            return newData;
          }
        }
        
        setUserData(null);
        setUserRole(null);
        return null;
      }
      
      const data = userSnap.data();
      
      // 🔥 isVerified ঠিকমতো সেট করুন (verificationStatus চেক করে)
      let isVerified = data.isVerified || false;
      let verificationStatus = data.verificationStatus || 'incomplete';
      
      // 🔥 যদি verificationStatus 'verified' হয়, তাহলে isVerified true সেট করুন
      if (verificationStatus === 'verified') {
        isVerified = true;
      }
      
      // 🔥 isComplete চেক
      let isComplete = data.isComplete || false;
      
      // 🔥 completionScore চেক
      let completionScore = data.completionScore || 0;
      
      // 🔥 যদি isComplete true হয় কিন্তু completionScore 100 না হয়, তাহলে আপডেট করুন
      if (isComplete && completionScore < 100) {
        completionScore = 100;
        await updateDoc(userRef, { completionScore: 100 });
      }
      
      // 🔥 ডেটা সেট করুন (সঠিক মান সহ)
      const updatedData = {
        ...data,
        isVerified: isVerified,
        isComplete: isComplete,
        verificationStatus: verificationStatus,
        completionScore: completionScore
      };
      
      setUserData(updatedData);
      setUserRole(data.role || 'client');
      
      // 🔥 ব্লক চেক
      if (data.isBanned || data.isBlocked) {
        console.log("🚫 User is blocked:", uid);
        toast.error('🚫 আপনার অ্যাকাউন্ট ব্লক করা হয়েছে।');
      }
      
      return updatedData;
      
    } catch (error) {
      console.error("Error loading user data:", error);
      return null;
    }
  };

  // ============================================================
  // ✅ Auth State Listener (রিয়েল-টাইম)
  // ============================================================
  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, async (user) => {
      if (user) {
        console.log("🔥 Auth state changed - User logged in:", user.uid);
        setCurrentUser(user);
        
        // 🔥 ইউজার ডেটা লোড
        const userDoc = await loadUserData(user.uid);
        
        if (userDoc) {
          setUserData(userDoc);
          setUserRole(userDoc.role || 'client');
          setLoading(false);
          
          // 🔥 রিয়েল-টাইম লিসনার সেটআপ (ডকুমেন্ট আপডেট শুনতে)
          const userRef = doc(db, 'users', user.uid);
          const unsubscribeSnapshot = onSnapshot(userRef, (docSnap) => {
            if (docSnap.exists()) {
              const data = docSnap.data();
              console.log("🔄 User document updated in real-time:", data);
              
              // 🔥 isVerified এবং verificationStatus চেক
              let isVerified = data.isVerified || false;
              let verificationStatus = data.verificationStatus || 'incomplete';
              
              if (verificationStatus === 'verified') {
                isVerified = true;
              }
              
              setUserData({
                ...data,
                isVerified: isVerified,
                verificationStatus: verificationStatus
              });
              setUserRole(data.role || 'client');
            }
          });
          
          // Cleanup
          return () => {
            unsubscribeSnapshot();
          };
        } else {
          // 🔥 ডকুমেন্ট না পেলে লোডিং থাকবে
          console.log("⏳ Waiting for user document to be created...");
          setLoading(true);
        }
        
      } else {
        console.log("🔥 Auth state changed - User logged out");
        setCurrentUser(null);
        setUserData(null);
        setUserRole(null);
        setLoading(false);
      }
    });
    
    return () => unsubscribeAuth();
  }, []);

  // ============================================================
  // ✅ গুগল লগইন
  // ============================================================
  const googleLogin = async () => {
    const provider = new GoogleAuthProvider();
    
    try {
      const result = await signInWithPopup(auth, provider);
      const user = result.user;
      
      const userDoc = await ensureUserDocument(user);
      if (userDoc) {
        setUserData(userDoc);
        setUserRole(userDoc.role || 'client');
      }
      
      toast.success('✅ Google login successful!');
      return { success: true, user };
      
    } catch (error) {
      if (error.code === 'auth/popup-blocked') {
        toast.loading('Popup blocked. Redirecting to Google...');
        await signInWithRedirect(auth, provider);
        return { success: true, message: 'Redirecting to Google...' };
      }
      
      toast.error('Google login failed: ' + error.message);
      return { success: false, error: error.message };
    }
  };

  // ============================================================
  // ✅ Redirect Result হ্যান্ডলার
  // ============================================================
  useEffect(() => {
    const handleRedirectResult = async () => {
      try {
        const result = await getRedirectResult(auth);
        if (result) {
          const user = result.user;
          const userDoc = await ensureUserDocument(user);
          if (userDoc) {
            setUserData(userDoc);
            setUserRole(userDoc.role || 'client');
          }
          toast.success('✅ Google login successful!');
        }
      } catch (error) {
        console.error("Redirect login error:", error);
        toast.error('Google login failed: ' + error.message);
      }
    };
    
    handleRedirectResult();
  }, []);

  // ============================================================
  // ✅ লগইন ফাংশন
  // ============================================================
  const login = async (email, password, rememberMe = false) => {
    try {
      const result = await signInWithEmailAndPassword(auth, email, password);
      const user = result.user;
      
      if (rememberMe) {
        localStorage.setItem('rememberMe', 'true');
        localStorage.setItem('userEmail', email);
      } else {
        localStorage.removeItem('rememberMe');
        localStorage.removeItem('userEmail');
      }
      
      const userDoc = await ensureUserDocument(user);
      if (userDoc) {
        setUserData(userDoc);
        setUserRole(userDoc.role || 'client');
      }
      
      toast.success('✅ Login successful!');
      return { success: true, user };
    } catch (error) {
      let errorMessage = 'Login failed!';
      switch (error.code) {
        case 'auth/invalid-credential':
          errorMessage = 'Invalid email or password!';
          break;
        case 'auth/user-not-found':
          errorMessage = 'User not found!';
          break;
        case 'auth/wrong-password':
          errorMessage = 'Wrong password!';
          break;
        default:
          errorMessage = error.message;
      }
      toast.error(errorMessage);
      return { success: false, error: errorMessage };
    }
  };

  // ============================================================
  // ✅ createNewChat ফাংশন
  // ============================================================
  const createNewChat = async (post) => {
    if (!currentUser || !userData) {
      toast.error('Please login to start a chat!');
      return { success: false, error: 'User not logged in' };
    }

    const isServicePost = post?.type === 'service';
    const postId = post?.id || post?.postId;
    
    if (!postId) {
      toast.error('Invalid post data!');
      return { success: false, error: 'Invalid post' };
    }

    const buyerId = isServicePost ? currentUser.uid : post.userId;
    const sellerId = isServicePost ? post.userId : currentUser.uid;

    const buyerName = isServicePost ? userData.displayName : post.clientName;
    const buyerPhoto = isServicePost ? userData.photoURL : post.clientPhoto;
    const sellerName = isServicePost ? post.clientName : userData.displayName;
    const sellerPhoto = isServicePost ? post.clientPhoto : userData.photoURL;

    const chatId = `${buyerId}_${sellerId}_${postId}`;
    const chatRef = doc(db, 'chats', chatId);
    const postTitle = post?.title || post?.postTitle || 'Untitled Post';

    const chatData = {
      chatId: chatId,
      participants: [buyerId, sellerId],
      buyerId: buyerId,
      sellerId: sellerId,
      buyerName: buyerName || 'Buyer',
      buyerPhoto: buyerPhoto || null,
      sellerName: sellerName || 'Seller',
      sellerPhoto: sellerPhoto || null,
      postId: postId,
      postTitle: postTitle,
      postType: isServicePost ? 'service' : 'hire',
      status: 'pending',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      lastMessage: 'Start conversation',
      unreadCount: {
        [buyerId]: 0,
        [sellerId]: 1
      },
      isBlocked: false,
      blockedBy: null
    };

    try {
      await setDoc(chatRef, chatData, { merge: true });
      console.log("✅ Chat created successfully!", { chatId, buyerId, sellerId });
      
      return { 
        success: true, 
        chatId: chatId, 
        chatData: chatData,
        otherPartyId: isServicePost ? sellerId : buyerId,
        otherPartyName: isServicePost ? sellerName : buyerName,
        otherPartyPhoto: isServicePost ? sellerPhoto : buyerPhoto
      };
      
    } catch (error) {
      console.error("❌ Error creating chat:", error);
      toast.error('Failed to start chat. Please try again.');
      return { success: false, error: error.message };
    }
  };

  // ============================================================
  // ✅ getOrCreateChat
  // ============================================================
  const getOrCreateChat = async (post) => {
    if (!currentUser || !userData) {
      return { success: false, error: 'User not logged in' };
    }

    const postId = post?.id || post?.postId;
    if (!postId) {
      return { success: false, error: 'Invalid post' };
    }

    const isServicePost = post?.type === 'service';
    const buyerId = isServicePost ? currentUser.uid : post.userId;
    const sellerId = isServicePost ? post.userId : currentUser.uid;
    const chatId = `${buyerId}_${sellerId}_${postId}`;

    const chatRef = doc(db, 'chats', chatId);
    const chatSnap = await getDoc(chatRef);

    if (chatSnap.exists()) {
      const data = chatSnap.data();
      const otherPartyId = isServicePost ? sellerId : buyerId;
      const otherPartyName = isServicePost ? data.sellerName : data.buyerName;
      const otherPartyPhoto = isServicePost ? data.sellerPhoto : data.buyerPhoto;
      
      return {
        success: true,
        chatId: chatId,
        chatData: data,
        exists: true,
        otherPartyId,
        otherPartyName,
        otherPartyPhoto
      };
    } else {
      return await createNewChat(post);
    }
  };

  // ============================================================
  // ✅ লগআউট
  // ============================================================
  const logout = async () => {
    try {
      if (currentUser) {
        try {
          const userRef = doc(db, 'users', currentUser.uid);
          await updateDoc(userRef, {
            isOnline: false,
            lastSeen: new Date().toISOString()
          });
        } catch (error) {
          console.log("User document not found, skipping status update");
        }
      }
      
      await signOut(auth);
      setCurrentUser(null);
      setUserData(null);
      setUserRole(null);
      localStorage.removeItem('rememberMe');
      localStorage.removeItem('userEmail');
      toast.success('✅ Logged out successfully!');
      return { success: true };
    } catch (error) {
      toast.error('Logout failed: ' + error.message);
      return { success: false };
    }
  };

  // ============================================================
  // ✅ পাসওয়ার্ড রিসেট
  // ============================================================
  const resetPassword = async (email) => {
    try {
      await sendPasswordResetEmail(auth, email);
      toast.success('📧 Password reset email sent! Check your inbox.');
      return { success: true };
    } catch (error) {
      let errorMessage = 'Failed to send reset email!';
      if (error.code === 'auth/user-not-found') {
        errorMessage = 'No account found with this email!';
      }
      toast.error(errorMessage);
      return { success: false, error: errorMessage };
    }
  };

  // ============================================================
  // ✅ রিমেম্বার মি চেক
  // ============================================================
  const getRememberedEmail = () => {
    const rememberMe = localStorage.getItem('rememberMe');
    const userEmail = localStorage.getItem('userEmail');
    if (rememberMe === 'true' && userEmail) {
      return userEmail;
    }
    return '';
  };

  // ============================================================
  // ✅ ইউজারের রোল অনুযায়ী রিডাইরেক্ট
  // ============================================================
  const getDashboardPath = () => {
    switch (userRole) {
      case 'admin':
        return '/admin';
      case 'worker':
        return '/worker';
      case 'seller':
        return '/seller';
      default:
        return '/';
    }
  };

  // ============================================================
  // ✅ প্রোফাইল প্রগ্রেস ক্যালকুলেটর
  // ============================================================
  const getProfileProgress = (userData) => {
    if (!userData) return 0;
    
    let progress = 0;
    
    if (userData.displayName || userData.firstName) progress += 10;
    if (userData.email) progress += 5;
    if (userData.phone) progress += 5;
    if (userData.documentsUploaded) progress += 40;
    if (userData.faceVerified) progress += 40;
    if (userData.isComplete) progress = 100;
    
    return Math.min(progress, 100);
  };

  // ============================================================
  // ✅ অ্যাক্সেস লেভেল ক্যালকুলেট করুন (ফিক্সড)
  // ============================================================
  const accessLevel = getAccessLevel(userData);

  // ============================================================
  // ✅ পারমিশন ফ্ল্যাগ (ফিক্সড)
  // ============================================================
  const canSendOffer = accessLevel.level >= 3 && !accessLevel.isBlocked;
  const canTransact = accessLevel.level >= 3 && !accessLevel.isBlocked;
  const canCreatePost = accessLevel.level >= 3 && !accessLevel.isBlocked;
  const canAccessDashboard = accessLevel.level >= 3 && !accessLevel.isBlocked;

  // ============================================================
  // ✅ Value অবজেক্ট
  // ============================================================
  const value = {
    // ── ইউজার ডেটা ──
    currentUser,
    userData,
    userRole,
    loading,
    
    // ── অথেনটিকেশন ফাংশন ──
    login,
    googleLogin,
    logout,
    resetPassword,
    getRememberedEmail,
    getDashboardPath,
    createNewChat,
    getOrCreateChat,
    
    // ── প্রোফাইল প্রগ্রেস ──
    progress: getProfileProgress(userData),
    completionScore: getProfileProgress(userData),
    
    // ── অ্যাক্সেস লেভেল ──
    accessLevel: accessLevel.level,
    accessLabel: accessLevel.label,
    
    // ── স্ট্যাটাস ফ্ল্যাগ (সঠিক মান) ──
    isVerified: userData?.isVerified || false,
    isComplete: userData?.isComplete || false,
    isPending: userData?.verificationStatus === 'pending' || false,
    isRejected: userData?.verificationStatus === 'rejected' || false,
    isBlocked: userData?.isBanned || userData?.isBlocked || false,
    
    // ── রোল ফ্ল্যাগ ──
    isAdmin: userRole === 'admin',
    isWorker: userRole === 'worker',
    isClient: userRole === 'client' || userRole === 'seller',
    isSeller: userRole === 'seller' || userRole === 'freelancer',
    isBuyer: userRole === 'client' || userRole === 'buyer',
    
    // ── পারমিশন ফ্ল্যাগ (ফিক্সড) ──
    canViewPosts: true,
    canChat: !(userData?.isBanned || userData?.isBlocked),
    canSendOffer: canSendOffer,
    canTransact: canTransact,
    canCreatePost: canCreatePost,
    canAccessDashboard: canAccessDashboard,
    canAccessDeals: canAccessDashboard,
    canAccessPayments: canAccessDashboard,
    canCreatePosts: canCreatePost,
    
    // ── হেল্পার (ফিক্সড) ──
    needsVerification: userData?.isComplete && !userData?.isVerified && !(userData?.isBanned || userData?.isBlocked),
    isFullyVerified: userData?.isVerified && userData?.isComplete && !(userData?.isBanned || userData?.isBlocked),
    hasFullAccess: userData?.isVerified && userData?.isComplete && !(userData?.isBanned || userData?.isBlocked),
    verificationStatus: userData?.verificationStatus || 'incomplete',
    isBanned: userData?.isBanned || false
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthContext;