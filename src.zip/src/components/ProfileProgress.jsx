// src/components/ProfileProgress.jsx
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import './ProfileProgress.css';

const ProfileProgress = () => {
  const navigate = useNavigate();
  const { 
    userData,
    isVerified,
    isComplete,
    isPending,
    isRejected,
    isBlocked,
    accessLevel,
    accessLabel,
    canTransact,
    canSendOffer,
    canCreatePost,
    needsVerification,
    isFullyVerified,
    completionScore = 0
  } = useAuth();

  // ── ১. ব্লকড ──
  if (isBlocked) {
    return (
      <div className="status-banner error">
        <div className="banner-icon">🚫</div>
        <div className="banner-content">
          <strong>🚫 অ্যাকাউন্ট ব্লক করা হয়েছে</strong>
          <p>আপনার অ্যাকাউন্ট অ্যাডমিন দ্বারা ব্লক করা হয়েছে।</p>
          <p className="sub-text">সাপোর্ট টিমের সাথে যোগাযোগ করুন: support@workhub.com</p>
          <button 
            className="btn-support" 
            onClick={() => window.location.href = 'mailto:support@workhub.com'}
          >
            📧 সাপোর্টে ইমেইল করুন
          </button>
        </div>
      </div>
    );
  }

  // ── ২. রিজেক্টেড ──
  if (isRejected) {
    return (
      <div className="status-banner error">
        <div className="banner-icon">❌</div>
        <div className="banner-content">
          <strong>❌ যাচাই প্রত্যাখ্যাত</strong>
          <p>আপনার ডকুমেন্ট যাচাই প্রত্যাখ্যাত হয়েছে।</p>
          <p className="sub-text">সঠিক ও স্পষ্ট ডকুমেন্ট আপলোড করুন।</p>
          <button 
            className="btn-continue" 
            onClick={() => navigate('/settings')}
          >
            📄 পুনরায় ডকুমেন্ট আপলোড করুন
          </button>
        </div>
      </div>
    );
  }

  // ── ৩. সম্পূর্ণ ভেরিফাইড ──
  if (isVerified && isComplete) {
    return (
      <div className="status-banner success">
        <div className="banner-icon">✅</div>
        <div className="banner-content">
          <strong>🎉 প্রোফাইল যাচাই সম্পন্ন!</strong>
          <p>আপনার অ্যাকাউন্ট পুরোপুরি সক্রিয়। এখন সম্পূর্ণ সুবিধা পাবেন।</p>
          <div className="access-badges">
            <span className="badge verified">✅ সম্পূর্ণ অ্যাক্সেস</span>
            <span className="badge success">💰 লেনদেন সক্রিয়</span>
            <span className="badge success">📨 অফার পাঠাতে পারবেন</span>
          </div>
        </div>
      </div>
    );
  }

  // ── ৪. পেন্ডিং ──
  if (isPending) {
    return (
      <div className="status-banner pending">
        <div className="banner-icon">⏳</div>
        <div className="banner-content">
          <strong>⏳ যাচাই প্রক্রিয়াধীন</strong>
          <p>আপনার ডকুমেন্ট ২৪-৪৮ ঘণ্টার মধ্যে পর্যালোচনা করা হবে।</p>
          <div className="progress-bar-small">
            <div className="progress-fill-small" style={{ width: '60%' }} />
          </div>
          <span className="progress-label">যাচাই চলছে...</span>
          <div className="access-badges">
            <span className="badge pending">⏳ সীমিত অ্যাক্সেস</span>
            <span className="badge info">📌 লেনদেন অক্ষম</span>
          </div>
        </div>
      </div>
    );
  }

  // ── ৫. অসম্পূর্ণ ──
  if (!isComplete) {
    const progress = completionScore || 0;
    
    // প্রগ্রেস স্টেপ নির্ধারণ
    const getStepStatus = (stepProgress) => {
      if (progress >= stepProgress) return 'done';
      if (progress >= stepProgress - 10) return 'active';
      return '';
    };
    
    return (
      <div className="profile-progress-wrapper">
        <div className="progress-header">
          <span className="progress-title">📊 প্রোফাইল সম্পন্ন</span>
          <span className="progress-percent">{progress}%</span>
        </div>
        
        <div className="progress-bar">
          <div 
            className="progress-fill" 
            style={{ width: `${progress}%` }}
          />
        </div>
        
        <div className="progress-steps">
          <div className={`step ${getStepStatus(20)}`}>
            <span className="step-icon">📝</span>
            <span className="step-label">বেসিক তথ্য</span>
            <span className="step-check">{progress >= 20 ? '✅' : '⬜'}</span>
          </div>
          <div className={`step ${getStepStatus(60)}`}>
            <span className="step-icon">📄</span>
            <span className="step-label">ডকুমেন্ট</span>
            <span className="step-check">{progress >= 60 ? '✅' : '⬜'}</span>
          </div>
          <div className={`step ${getStepStatus(100)}`}>
            <span className="step-icon">📸</span>
            <span className="step-label">ফেস যাচাই</span>
            <span className="step-check">{progress === 100 ? '✅' : '⬜'}</span>
          </div>
        </div>
        
        <div className="progress-hint">
          <span className="hint-icon">💡</span>
          <p>
            {progress < 20 && 'প্রথমে আপনার প্রোফাইল তথ্য দিন।'}
            {progress >= 20 && progress < 60 && 'এখন ডকুমেন্ট আপলোড করুন।'}
            {progress >= 60 && progress < 100 && 'শেষ ধাপ: ফেস যাচাই করুন।'}
            {progress === 100 && '🎉 সব সম্পন্ন! অ্যাডমিন যাচাই অপেক্ষমাণ।'}
          </p>
        </div>
        
        <div className="progress-actions">
          <button 
            className="btn-continue" 
            onClick={() => navigate('/settings')}
          >
            ⚙️ সেটিংসে যান ও প্রোফাইল সম্পূর্ণ করুন →
          </button>
        </div>
      </div>
    );
  }

  // ── ৬. লোডিং ──
  return (
    <div className="status-banner info">
      <div className="banner-icon">ℹ️</div>
      <div className="banner-content">
        <strong>📊 প্রোফাইল লোড হচ্ছে...</strong>
        <p>দয়া করে অপেক্ষা করুন...</p>
      </div>
    </div>
  );
};

export default ProfileProgress;