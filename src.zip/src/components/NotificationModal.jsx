import React from 'react';
import './NotificationModal.css'; // সুন্দর ডিজাইনের জন্য CSS করুন

const NotificationModal = ({ notification, onClose }) => {
  if (!notification) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h3>{notification.title}</h3>
          <button className="close-btn" onClick={onClose}>✕</button>
        </div>
        <div className="modal-body">
          <p>{notification.message}</p>
          <small>পাঠানো হয়েছে: {notification.time}</small>
        </div>
        <div className="modal-footer">
          <button className="btn btn-primary" onClick={onClose}>ঠিক আছে</button>
        </div>
      </div>
    </div>
  );
};

export default NotificationModal;