import React, { useState, useEffect, useCallback } from 'react';
import { Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import { signOut, onAuthStateChanged } from 'firebase/auth';
import { auth, db } from './firebase';
import { collection, query, orderBy, onSnapshot, addDoc, where, getDocs, writeBatch } from 'firebase/firestore';
import { initOnlineStatus } from './pages/userStatusHelper';

// পেজসমূহ
import UserProfilePage from './pages/UserProfilePage';
import VerifyEmail from './pages/VerifyEmail';

import PrivateRoute from './components/PrivateRoute';
import VerifyPending from './pages/VerifyPending';
import VerifyRejected from './pages/VerifyRejected'; // ✅ নতুন যোগ
import BlockedPage from './pages/BlockedPage'; // ✅ নতুন যোগ


import SavedJobsPage from './pages/SavedJobsPage';
import Settings from './pages/Settings';
import { PostProvider } from './pages/PostContext'; 
import AdminDashboard from './pages/AdminDashboard';
import Login from './pages/Login';
import Register from './pages/Register';
import Home from './pages/Home';
import Navbar from "./pages/Navbar";
import Inbox from './pages/Inbox';
import Notifications from './pages/Notifications';
import DealManager from './pages/DealManager';
import Profile from './pages/Profile';
import Withdraw from './pages/Withdraw';
import Transactions from './pages/Transactions';
import PaymentGateway from './pages/PaymentGateway';
import Wallet from './pages/Wallet';
import Deposit from './pages/Deposit';
import QRCode from './pages/QRCode';
import SendMoney from './pages/SendMoney';
import BankAccount from './pages/BankAccount';
import PaymentHistory from './pages/PaymentHistory';
import Referral from './pages/Referral';
import './App.css';

function App() {
  const navigate = useNavigate();
  
  // ========== 🎯 থিম স্টেট ==========
  const [isDark, setIsDark] = useState(() => {
    const savedTheme = localStorage.getItem('theme');
    return savedTheme !== 'light';
  });

  const [deals, setDeals] = useState([]);
  const [pendingDealsCount, setPendingDealsCount] = useState(0); // ✅ আলাদা স্টেট

  // ========== 🎯 থিম টগল ফাংশন ==========
  const toggleTheme = () => {
    const newMode = !isDark;
    setIsDark(newMode);
    
    if (!newMode) {
      document.documentElement.classList.add('light-mode');
      document.documentElement.classList.remove('dark-mode');
      localStorage.setItem('theme', 'light');
    } else {
      document.documentElement.classList.add('dark-mode');
      document.documentElement.classList.remove('light-mode');
      localStorage.setItem('theme', 'dark');
    }
  };

  // স্টেট ডিফাইনেশন
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [currentMode, setCurrentMode] = useState(() => {
    return localStorage.getItem('currentMode') || 'buyer';
  });
  const [activeTab, setActiveTab] = useState(() => {
    return localStorage.getItem('activeTab') || 'dashboard';
  });
  const [posts, setPosts] = useState([]);
  const [isCreatingUser, setIsCreatingUser] = useState(false);
  const [postsLoading, setPostsLoading] = useState(true);
  
  // সার্চের জন্য স্টেট
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredPosts, setFilteredPosts] = useState([]);

  // chats স্টেট
  const [chats, setChats] = useState([]);

  // নোটিফিকেশন স্টেট
  const [notifications, setNotifications] = useState([]);
  const [unreadNotificationsCount, setUnreadNotificationsCount] = useState(0);

  const [activeChatContext, setActiveChatContext] = useState(() => {
    const savedChat = localStorage.getItem('activeChat');
    if (savedChat) {
      try {
        const parsed = JSON.parse(savedChat);
        return parsed.fullData || parsed;
      } catch (e) {
        return null;
      }
    }
    return null;
  });

  const handleUnreadCountChange = useCallback((count) => {
    setUnreadNotificationsCount(count);
    console.log("📊 Notification count updated from child:", count);
  }, []);

  // ========== 🎯 handleModeChange ফাংশন ==========
  const handleModeChange = (mode) => {
    console.log("🔄 Mode changing to:", mode);
    setCurrentMode(mode);
    localStorage.setItem('currentMode', mode);
  };

  // totalUnread ক্যালকুলেশন
  const totalUnread = chats.reduce((total, chat) => {
    if (!currentUser?.uid) return total;
    
    if (chat.unreadCount && typeof chat.unreadCount === 'object') {
      const userUnread = chat.unreadCount[currentUser.uid] || 0;
      return total + userUnread;
    }
    if (typeof chat.unreadCount === 'number') {
      return total + chat.unreadCount;
    }
    return total;
  }, 0);

  // গ্লোবাল সার্চ ফাংশন
  const handleGlobalSearch = (query) => {
    setSearchQuery(query);
    if (!query || query.trim() === '') {
      setFilteredPosts(posts);
    } else {
      const lowerQuery = query.toLowerCase();
      const filtered = posts.filter(post => 
        post.title?.toLowerCase().includes(lowerQuery) ||
        post.description?.toLowerCase().includes(lowerQuery) ||
        post.clientName?.toLowerCase().includes(lowerQuery)
      );
      setFilteredPosts(filtered);
    }
  };

  // Firebase Auth লিসেনার
  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, async (user) => {
      if (!isCreatingUser) {
        setCurrentUser(user);
        if (user?.uid) {
          initOnlineStatus(user.uid);
        }
      }
      setLoading(false);
    });
    return () => unsubscribeAuth();
  }, [isCreatingUser]);

  // ========== 🎯 থিম ইফেক্ট ==========
useEffect(() => {
  const html = document.documentElement;
  if (isDark) {
    html.classList.add('dark-mode');
    html.classList.remove('light-mode');
  } else {
    html.classList.add('light-mode');
    html.classList.remove('dark-mode');
  }
  localStorage.setItem('theme', isDark ? 'dark' : 'light');
}, [isDark]);

  // ============================================================
  // ✅ ডিলস ফেচিং - ফিক্সড (শুধু পেন্ডিং কাউন্টের জন্য)
  // ============================================================
  useEffect(() => {
    if (!currentUser?.uid) {
      setPendingDealsCount(0);
      return;
    }
    
    // ✅ শুধুমাত্র pending ডিলস কাউন্ট (যে কোনো মোডে)
    const q = query(
      collection(db, 'deals'),
      where('status', '==', 'pending')
    );
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      // বর্তমান ইউজারের সাথে সম্পর্কিত pending ডিলস ফিল্টার
      const pendingDeals = snapshot.docs.filter(doc => {
        const data = doc.data();
        return data.buyerId === currentUser.uid || data.sellerId === currentUser.uid;
      });
      
      setPendingDealsCount(pendingDeals.length);
      console.log("📊 Pending deals count:", pendingDeals.length);
    }, (error) => {
      console.error("Error fetching pending deals:", error);
      setPendingDealsCount(0);
    });
    
    return () => unsubscribe();
  }, [currentUser?.uid]);

  // ============================================================
  // ✅ সব ডিলস ফেচিং (DealManager এর জন্য)
  // ============================================================
  useEffect(() => {
    if (!currentUser?.uid) {
      setDeals([]);
      return;
    }
    
    const q = query(
      collection(db, 'deals'),
      where('participants', 'array-contains', currentUser.uid)
    );
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedDeals = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setDeals(fetchedDeals);
      console.log("📊 Total deals:", fetchedDeals.length);
    }, (error) => {
      console.error("Error fetching deals:", error);
      setDeals([]);
    });
    
    return () => unsubscribe();
  }, [currentUser?.uid]);

  // Firebase পোস্ট ফেচিং
  useEffect(() => {
    if (!currentUser) {
      console.log("No user, skipping posts listener");
      setPostsLoading(false);
      return;
    }

    console.log("🔥 Setting up posts listener for user:", currentUser.uid);
    
    const q = query(collection(db, 'posts'), orderBy('createdAt', 'desc'));
    
    const unsubscribe = onSnapshot(q, 
      (snapshot) => {
        console.log("🔔 SNAPSHOT TRIGGERED! Docs:", snapshot.docs.length);
        
        const uniqueMap = new Map();
        snapshot.docs.forEach(doc => {
          if (!uniqueMap.has(doc.id)) {
            uniqueMap.set(doc.id, {
              id: doc.id,
              ...doc.data()
            });
          }
        });
        
        const fetchedPosts = Array.from(uniqueMap.values());
        console.log("📊 Unique posts from snapshot:", fetchedPosts.length);
        
        setPosts(fetchedPosts);
        setFilteredPosts(fetchedPosts);
        setPostsLoading(false);
      }, 
      (error) => {
        console.error("Firebase Error:", error.message);
        setPostsLoading(false);
      }
    );

    return () => unsubscribe();
  }, [currentUser]);

  // ============================================================
  // 🔥 নোটিফিকেশন আনরিড কাউন্ট
  // ============================================================
  useEffect(() => {
    if (!currentUser?.uid) {
      setUnreadNotificationsCount(0);
      return;
    }

    const q = query(
      collection(db, 'notifications'),
      where('userId', '==', currentUser.uid),
      where('isUnread', '==', true) 
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      setUnreadNotificationsCount(snapshot.size); 
      console.log("🔔 Unread count updated in App.js:", snapshot.size);
    }, (error) => {
      console.error("Error fetching unread count:", error);
    });

    return () => unsubscribe();
  }, [currentUser?.uid]);

  // চ্যাট ফেচিং
  useEffect(() => {
    if (!currentUser?.uid) {
      console.log("No current user, skipping chat fetch");
      return;
    }

    console.log("🔥 Fetching chats for user:", currentUser.uid);

    const chatsRef = collection(db, 'chats');
    const q = query(
      chatsRef,
      where('participants', 'array-contains', currentUser.uid)
    );

    const unsubscribe = onSnapshot(q, 
      (snapshot) => {
        console.log("📊 Total chats from Firestore:", snapshot.docs.length);
        
        const fetchedChats = snapshot.docs.map(doc => {
          const data = doc.data();
          
          let userUnread = 0;
          if (data.unreadCount && typeof data.unreadCount === 'object') {
            userUnread = data.unreadCount[currentUser.uid] || 0;
          } else if (typeof data.unreadCount === 'number') {
            userUnread = data.unreadCount;
          }
          
          return {
            id: doc.id,
            ...data,
            userUnreadCount: userUnread,
            unreadCount: data.unreadCount || 0
          };
        });
        
        console.log("📊 Processed chats with unread counts:", fetchedChats.length);
        setChats(fetchedChats);
      }, 
      (error) => {
        console.error("Error loading chats for unread:", error.message);
      }
    );

    return () => unsubscribe();
  }, [currentUser?.uid]);

  // localStorage সেভ
  useEffect(() => {
    localStorage.setItem('currentMode', currentMode);
  }, [currentMode]);

  useEffect(() => {
    localStorage.setItem('activeTab', activeTab);
  }, [activeTab]);

  useEffect(() => {
    if (activeChatContext) {
      localStorage.setItem('activeChat', JSON.stringify(activeChatContext));
    } else {
      localStorage.removeItem('activeChat');
    }
  }, [activeChatContext]);

  const handleAddNewPost = async (newPostData) => {
    try {
      await addDoc(collection(db, 'posts'), {
        ...newPostData,
        escrowSystem: true,
        targetCountry: 'BD',
        currency: 'BDT',
        createdAt: new Date().toISOString(),
        userId: currentUser?.uid
      });
      setActiveTab('dashboard');
    } catch (error) {
      console.error("পোস্ট সেভ করতে সমস্যা হয়েছে: ", error);
    }
  };

  const handleInitiateBidAndChat = (postData) => {
    console.log("Initiating chat for:", postData);
    setActiveChatContext(postData);
    navigate('/inbox');
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      localStorage.clear();
      navigate('/login');
    } catch (error) {
      console.error("লগআউট এরর:", error);
    }
  };

  // লোডিং স্ক্রিন
  if (loading) {
    return (
      <div style={{ 
        display: 'flex', 
        justifyContent: 'center', 
        alignItems: 'center', 
        height: '100vh', 
        background: '#090d16', 
        color: '#14b8a6' 
      }}>
        <h2>Loading WorkHub...</h2>
      </div>
    );
  }

 return (
    <PostProvider>
      <div className="main-app">
        {currentUser ? (
          <Navbar 
            totalUnread={totalUnread}
            totalDeals={pendingDealsCount}
            currentMode={currentMode} 
            setCurrentMode={handleModeChange}
            onLogout={handleLogout}
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            onSilentPost={handleAddNewPost}
            currentUser={currentUser}
            onSearch={handleGlobalSearch}
            searchQuery={searchQuery}
            unreadNotifications={unreadNotificationsCount}
            searchResults={searchQuery ? [] : []}
          >
            <Routes>
              {/* ── পাবলিক রাউট (সবাই দেখতে পারে) ── */}
              <Route path="/" element={
                <Home 
                  currentMode={currentMode}
                  currentUser={currentUser}
                  searchTerm={searchQuery}
                  onBidAndChatClick={handleInitiateBidAndChat}
                />
              } />

              <Route path="/post/:postId" element={
                <Home 
                  currentMode={currentMode}
                  currentUser={currentUser}
                  searchTerm={searchQuery}
                  onBidAndChatClick={handleInitiateBidAndChat}
                />
              } />
              
              <Route path="/home" element={
                <Home 
                  currentMode={currentMode}
                  currentUser={currentUser}
                  searchTerm={searchQuery}
                  onBidAndChatClick={handleInitiateBidAndChat}
                />
              } />

              {/* ── শুধু লগইন দরকার ── */}
              <Route path="/inbox" element={
                <Inbox 
                  chatContext={activeChatContext || null}
                  currentUser={currentUser}
                />
              } />

              <Route path="/profile" element={<Profile />} />
              
              <Route path="/profile/:userId" element={<UserProfilePage />} />
              
              <Route path="/saved-jobs" element={<SavedJobsPage />} />

              {/* ── ✅ কমপ্লিট প্রোফাইল দরকার ── */}
              <Route path="/settings" element={
                <Settings isDark={isDark} toggleTheme={toggleTheme} />
              } />

              {/* ── ✅ ভেরিফাইড দরকার (লেনদেন, ডিল, পেমেন্ট) ── */}
              <Route path="/deal-manager" element={
                <PrivateRoute requireVerified>
                  <DealManager />
                </PrivateRoute>
              } />

              <Route path="/wallet" element={
                <PrivateRoute requireVerified>
                  <Wallet />
                </PrivateRoute>
              } />

              <Route path="/transactions" element={
                <PrivateRoute requireVerified>
                  <Transactions />
                </PrivateRoute>
              } />

              <Route path="/withdraw" element={
                <PrivateRoute requireVerified>
                  <Withdraw />
                </PrivateRoute>
              } />

              <Route path="/deposit" element={
                <PrivateRoute requireVerified>
                  <Deposit />
                </PrivateRoute>
              } />

              <Route path="/payment/:dealId/:milestoneId" element={
                <PrivateRoute requireVerified>
                  <PaymentGateway />
                </PrivateRoute>
              } />

              <Route path="/send-money" element={
                <PrivateRoute requireVerified>
                  <SendMoney />
                </PrivateRoute>
              } />

              <Route path="/bank-account" element={
                <PrivateRoute requireVerified>
                  <BankAccount />
                </PrivateRoute>
              } />

              <Route path="/payment-history" element={
                <PrivateRoute requireVerified>
                  <PaymentHistory />
                </PrivateRoute>
              } />

              <Route path="/qr-code" element={
                <PrivateRoute requireVerified>
                  <QRCode />
                </PrivateRoute>
              } />

              <Route path="/referral" element={
                <PrivateRoute requireVerified>
                  <Referral />
                </PrivateRoute>
              } />

              {/* ── ✅ অ্যাডমিন রাউট ── */}
              <Route path="/admin" element={
                <PrivateRoute requireAdmin>
                  <AdminDashboard />
                </PrivateRoute>
              } />

              {/* ── নোটিফিকেশন (সবাই দেখতে পারে) ── */}
              <Route path="/notifications" element={
                <Notifications 
                  currentUser={currentUser}
                  currentMode={currentMode}
                  onUnreadCountChange={handleUnreadCountChange}
                />
              } />

              {/* ── ✅ ভেরিফিকেশন পেন্ডিং পেজ ── */}
              <Route path="/verify-pending" element={<VerifyPending />} />
              <Route path="/verify-rejected" element={<VerifyRejected />} />
              <Route path="/blocked" element={<BlockedPage />} />

              {/* ── ৪০৪ ── */}
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </Navbar>
        ) : (
          <div style={{ 
            display: 'flex', 
            justifyContent: 'center', 
            alignItems: 'center', 
            minHeight: '100vh', 
            width: '100vw',
            background: '#090d16' 
          }}>
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register setIsCreatingUser={setIsCreatingUser} />} />
              <Route path="/verify-email" element={<VerifyEmail />} />
              <Route path="*" element={<Navigate to="/login" replace />} />
            </Routes>
          </div>
        )}
      </div>
    </PostProvider>
  );
}

export default App;